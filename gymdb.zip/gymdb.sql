-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2024 at 06:51 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gymdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `billing_details`
--

CREATE TABLE `billing_details` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cf_name` text NOT NULL,
  `cf_company_name` text NOT NULL,
  `cf_country` text NOT NULL,
  `cf_street_address` varchar(200) NOT NULL,
  `cf_apartment_address` varchar(200) NOT NULL,
  `cf_town_city` text NOT NULL,
  `cf_state_region` text NOT NULL,
  `cf_zip` int(6) NOT NULL,
  `cf_phone` int(11) NOT NULL,
  `cf_email` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `billing_details`
--

INSERT INTO `billing_details` (`id`, `user_id`, `cf_name`, `cf_company_name`, `cf_country`, `cf_street_address`, `cf_apartment_address`, `cf_town_city`, `cf_state_region`, `cf_zip`, `cf_phone`, `cf_email`) VALUES
(1, 2, 'sparks', 'sparks', 'india', '45', 'thaltej', 'ahmedabad', 'gujrat', 302015, 2147483647, 'xyz@gmail.com'),
(2, 1, 'jack', 'sparks', 'india', '45', 'thaltej', 'ahmedabad', 'gujrat', 300545, 212457956, 'jack123@gmail.com'),
(3, 1, '', '', '', '', '', '', '', 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `product_id`, `quantity`, `price`, `total`, `time`) VALUES
(3, 26, 38, 1, 45, 45, '2024-04-16 17:13:03');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Fitness Ball'),
(2, 'Water Bottle'),
(3, 'Workout Tank'),
(4, 'Skipping Rope'),
(5, 'Ab Roller'),
(10, 'Zumba Class');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `id` int(11) NOT NULL,
  `class_name` text NOT NULL,
  `class_img` varchar(200) NOT NULL,
  `class_duration` int(11) NOT NULL,
  `Description` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`id`, `class_name`, `class_img`, `class_duration`, `Description`) VALUES
(2, ' FITNESS CLASS', '2.jpg', 45, '<div class=\"content\" style=\"color: rgb(37, 37, 37); font-family: Roboto, sans-serif; font-size: 16px;\"><p style=\"margin-bottom: 17px;\">Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which some great pleasure</p><p style=\"margin-bottom: 17px;\">Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter</p><div class=\"class-details-info\"><h2 class=\"title\" style=\"margin-top: 31px; margin-bottom: 21px; font-family: Oswald, sans-serif; font-weight: 700; line-height: 1.333; color: rgb(37, 37, 37); font-size: 32px;\">Class details</h2><p style=\"margin-bottom: 35px;\">Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which some great pleasure more than enough to make your body fit with this class, but you need to continure your class regularly and timely</p></div></div><div class=\"class-info-list-area\" style=\"color: rgb(37, 37, 37); font-family: Roboto, sans-serif; font-size: 16px;\"><h2 class=\"title\" style=\"margin-top: 33px; margin-bottom: 22px; font-family: Oswald, sans-serif; font-weight: 700; color: rgb(37, 37, 37); font-size: 2rem;\">What to bring with you</h2><p style=\"margin-bottom: 30px;\">Gym is very important to maintain our health</p></div> '),
(10, ' CROSSFIT CLASS ', '6.jpg', 30, '<div class=\"content\" style=\"color: rgb(37, 37, 37); font-family: Roboto, sans-serif; font-size: 16px;\"><p style=\"margin-bottom: 17px;\">Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which some great pleasure</p><p style=\"margin-bottom: 17px;\">Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter</p><div class=\"class-details-info\"><h2 class=\"title\" style=\"margin-top: 31px; margin-bottom: 21px; font-family: Oswald, sans-serif; font-weight: 700; line-height: 1.333; color: rgb(37, 37, 37); font-size: 32px;\">Class details</h2><p style=\"margin-bottom: 35px;\">Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which some great pleasure more than enough to make your body fit with this class, but you need to continure your class regularly and timely</p></div></div><div class=\"class-info-list-area\" style=\"color: rgb(37, 37, 37); font-family: Roboto, sans-serif; font-size: 16px;\"><h2 class=\"title\" style=\"margin-top: 33px; margin-bottom: 22px; font-family: Oswald, sans-serif; font-weight: 700; color: rgb(37, 37, 37); font-size: 2rem;\">What to bring with you</h2><p style=\"margin-bottom: 30px;\">Gym is very important to maintain our health</p></div> '),
(12, 'BODY BUILDING CLASS ', '5.jpg', 20, '<div class=\"content\" style=\"color: rgb(37, 37, 37); font-family: Roboto, sans-serif; font-size: 16px;\"><p style=\"margin-bottom: 17px;\">Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which some great pleasure</p><p style=\"margin-bottom: 17px;\">Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter</p><div class=\"class-details-info\"><h2 class=\"title\" style=\"margin-top: 31px; margin-bottom: 21px; font-family: Oswald, sans-serif; font-weight: 700; line-height: 1.333; color: rgb(37, 37, 37); font-size: 32px;\">Class details</h2><p style=\"margin-bottom: 35px;\">Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which some great pleasure more than enough to make your body fit with this class, but you need to continure your class regularly and timely</p></div></div><div class=\"class-info-list-area\" style=\"color: rgb(37, 37, 37); font-family: Roboto, sans-serif; font-size: 16px;\"><h2 class=\"title\" style=\"margin-top: 33px; margin-bottom: 22px; font-family: Oswald, sans-serif; font-weight: 700; color: rgb(37, 37, 37); font-size: 2rem;\">What to bring with you</h2><p style=\"margin-bottom: 30px;\">Gym is very important to maintain our health</p></div> '),
(13, ' FITNESS CLASS', '3.jpg', 45, '<div class=\"content\" style=\"color: rgb(37, 37, 37); font-family: Roboto, sans-serif; font-size: 16px;\"><p style=\"margin-bottom: 17px;\">Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which some great pleasure</p><p style=\"margin-bottom: 17px;\">Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter</p><div class=\"class-details-info\"><h2 class=\"title\" style=\"margin-top: 31px; margin-bottom: 21px; font-family: Oswald, sans-serif; font-weight: 700; line-height: 1.333; color: rgb(37, 37, 37); font-size: 32px;\">Class details</h2><p style=\"margin-bottom: 35px;\">Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which some great pleasure more than enough to make your body fit with this class, but you need to continure your class regularly and timely</p></div></div><div class=\"class-info-list-area\" style=\"color: rgb(37, 37, 37); font-family: Roboto, sans-serif; font-size: 16px;\"><h2 class=\"title\" style=\"margin-top: 33px; margin-bottom: 22px; font-family: Oswald, sans-serif; font-weight: 700; color: rgb(37, 37, 37); font-size: 2rem;\">What to bring with you</h2><p style=\"margin-bottom: 30px;\">Gym is very important to maintain our health</p></div> '),
(14, 'gsfdgdfg', '6.jpg', 34, '<div class=\"content\" style=\"color: rgb(37, 37, 37); font-family: Roboto, sans-serif; font-size: 16px;\"><p style=\"margin-bottom: 17px;\">Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which some great pleasure</p><p style=\"margin-bottom: 17px;\">Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter</p><div class=\"class-details-info\"><h2 class=\"title\" style=\"margin-top: 31px; margin-bottom: 21px; font-weight: 700; line-height: 1.333; font-size: 32px; color: rgb(37, 37, 37); font-family: Oswald, sans-serif;\">Class details</h2><p style=\"margin-bottom: 35px;\">Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which some great pleasure more than enough to make your body fit with this class, but you need to continure your class regularly and timely</p></div></div><div class=\"class-info-list-area\" style=\"color: rgb(37, 37, 37); font-family: Roboto, sans-serif; font-size: 16px;\"><h2 class=\"title\" style=\"margin-top: 33px; margin-bottom: 22px; font-weight: 700; line-height: 1.2; font-size: 2rem; color: rgb(37, 37, 37); font-family: Oswald, sans-serif;\">What to bring with you</h2><p style=\"margin-bottom: 30px;\">Gym is very important to maintain our health');

-- --------------------------------------------------------

--
-- Table structure for table `class_category`
--

CREATE TABLE `class_category` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class_category`
--

INSERT INTO `class_category` (`id`, `name`) VALUES
(1, 'Fitness Class'),
(2, 'Crossfit Class'),
(3, 'Body Building Class'),
(4, 'Yoga Class'),
(5, 'Martial Art Class ');

-- --------------------------------------------------------

--
-- Table structure for table `class_schedule`
--

CREATE TABLE `class_schedule` (
  `id` int(11) NOT NULL,
  `day` varchar(200) NOT NULL,
  `time` varchar(110) NOT NULL,
  `Instructor` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class_schedule`
--

INSERT INTO `class_schedule` (`id`, `day`, `time`, `Instructor`) VALUES
(1, 'Sunday	', '9.00 am to 10.30 am', 'Nikolus Smith'),
(2, 'Monday', '9.00 am to 10.30 am', 'Nikolus Smith'),
(3, 'Wednesday', '3.00 pm to 4.30 pm', 'Robert Cristopher'),
(4, 'Thursday', '3.00 pm to 4.30 pm', 'Robert Cristopher');

-- --------------------------------------------------------

--
-- Table structure for table `gymadmin`
--

CREATE TABLE `gymadmin` (
  `id` int(11) NOT NULL,
  `username` varchar(211) NOT NULL,
  `gmail` varchar(211) NOT NULL,
  `password` varchar(244) NOT NULL,
  `number` int(12) NOT NULL,
  `firstname` varchar(211) NOT NULL,
  `lastname` varchar(122) NOT NULL,
  `address` varchar(244) NOT NULL,
  `city` varchar(210) NOT NULL,
  `country` varchar(211) NOT NULL,
  `code` int(6) NOT NULL,
  `pimage` varchar(122) NOT NULL,
  `cimage` text NOT NULL,
  `verify_token` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gymadmin`
--

INSERT INTO `gymadmin` (`id`, `username`, `gmail`, `password`, `number`, `firstname`, `lastname`, `address`, `city`, `country`, `code`, `pimage`, `cimage`, `verify_token`) VALUES
(1, 'admin', 'lakhanpadgil225@gmail.com', '12345', 45645, 'Richard', 'Marshall', 'riojgieqroi 0t0wrut0 eirp9iesrf', 'Ahmedabad', 'india', 656056, '7.jpg', 'pexels-pixabay-248747.jpg', '4715ea4ef88f440af3762add80a83792');

-- --------------------------------------------------------

--
-- Table structure for table `gymcontact`
--

CREATE TABLE `gymcontact` (
  `id` int(11) NOT NULL,
  `con_name` text NOT NULL,
  `con_email` varchar(211) NOT NULL,
  `con_message` varchar(244) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gymcontact`
--

INSERT INTO `gymcontact` (`id`, `con_name`, `con_email`, `con_message`) VALUES
(10, 'lakhan', 'lakhan@gmaill.com', '123'),
(11, 'hitu', 'hituthakor@gmail.com', '12345'),
(12, '', '', ''),
(13, '', '', ''),
(14, 'lakhan', 'lakhan@gmaill.com', '4545'),
(15, 'lakhan', 'lakhan@gmaill.com', '4545'),
(16, 'hitu', 'lakhan@gmaill.com', 'dtjfytfuj'),
(17, 'lakhan', 'hituthakor@gmail.com', 'hlhio');

-- --------------------------------------------------------

--
-- Table structure for table `gymregister`
--

CREATE TABLE `gymregister` (
  `id` int(11) NOT NULL,
  `username` varchar(211) NOT NULL,
  `number` int(11) NOT NULL,
  `gmail` varchar(244) NOT NULL,
  `password` varchar(233) NOT NULL,
  `gender` varchar(120) NOT NULL,
  `image` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gymregister`
--

INSERT INTO `gymregister` (`id`, `username`, `number`, `gmail`, `password`, `gender`, `image`) VALUES
(1, 'xyz', 1234575, 'xyz22@gmail.com', '123', 'male', '6.jpg'),
(2, 'deep', 452125, 'deep@gmail.com', '1234', 'male', '3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `inquiry`
--

CREATE TABLE `inquiry` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(2000) NOT NULL,
  `message` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inquiry`
--

INSERT INTO `inquiry` (`id`, `name`, `email`, `message`) VALUES
(1, 'Martial Art Class', 'lakhanpadgil225@gmail.com', 'Halbert Bourn is very professional and expert trainer. In his carier, he done\r\ngreat job. He never compromise maintain our very professional'),
(2, 'Martial Art Class', 'lakhanpadgil225@gmail.com', 'Halbert Bourn is very professional and expert trainer. In his carier, he done\r\ngreat job. He never compromise maintain our very professional'),
(3, 'Martial Art Class', 'lakhanpadgil225@gmail.com', 'Halbert Bourn is very professional and expert trainer. In his carier, he done\r\ngreat job. He never compromise maintain our very professional'),
(4, 'Martial Art Class', 'lakhanpadgil225@gmail.com', 'Halbert Bourn is very professional and expert trainer. In his carier, he done\r\ngreat job. He never compromise maintain our very professional'),
(5, 'Martial Art Class', 'lakhanpadgil225@gmail.com', 'Halbert Bourn is very professional and expert trainer. In his carier, he done\r\ngreat job. He never compromise maintain our very professional'),
(6, 'Martial Art Class', 'lakhanpadgil225@gmail.com', 'Halbert Bourn is very professional and expert trainer. In his carier, he done\r\ngreat job. He never compromise maintain our very professional'),
(7, 'Martial Art Class', 'lakhanpadgil225@gmail.com', 'sdfsdz'),
(8, 'Zumba Class', 'fgs@gmail.com', 'sd');

-- --------------------------------------------------------

--
-- Table structure for table `membership`
--

CREATE TABLE `membership` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `number` int(11) NOT NULL,
  `city` text NOT NULL,
  `country` text NOT NULL,
  `code` int(11) NOT NULL,
  `address` varchar(200) NOT NULL,
  `pimage` varchar(200) NOT NULL,
  `membership` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `membership`
--

INSERT INTO `membership` (`id`, `userid`, `firstname`, `lastname`, `email`, `password`, `number`, `city`, `country`, `code`, `address`, `pimage`, `membership`) VALUES
(1, 26, 'rtsertg', 'dfgsdf', 'lakhanpadgil225@gmail.com', '1223', 51212, 'gdsfgsdf', 'india', 433343, 'ghhhjghgyu ug iuhuhiuhjnkj', '6.jpg', 'Gold'),
(4, 1, 'xyz', 'xyz', 'xyz22@gmail.com', '123', 12454578, 'Ahmedabad', 'india', 302445, 'thaltej', '6.jpg', 'Gold');

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE `newsletter` (
  `id` int(11) NOT NULL,
  `email` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`id`, `email`) VALUES
(4, 'lakhanpadgil225@gmail.com'),
(5, 'xyz22@gmail.com'),
(7, 'fgs@gmail.com'),
(8, 'admin123@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `order_product`
--

CREATE TABLE `order_product` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_image` varchar(2000) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `order_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_product`
--

INSERT INTO `order_product` (`id`, `user_id`, `product_id`, `product_image`, `product_name`, `quantity`, `price`, `total`, `order_id`) VALUES
(1, 2, 38, '4.jpg', 'Water Bottle', 1, 45, 45, 1),
(2, 2, 45, '12.jpg', 'Mind Reader Kettlebell', 2, 45, 90, 1),
(3, 1, 39, '7.jpg', 'Water Bottle', 2, 45, 90, 2),
(4, 1, 38, '4.jpg', 'Water Bottle', 3, 45, 135, 2),
(5, 1, 45, '12.jpg', 'Mind Reader Kettlebell', 1, 45, 45, 2),
(6, 1, 39, '7.jpg', 'Water Bottle', 1, 45, 45, 3),
(7, 1, 42, '5.jpg', 'Fitness Slam Ball', 1, 34, 34, 3);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `product_name` text NOT NULL,
  `product_price` int(11) NOT NULL,
  `description` text NOT NULL,
  `product_image` varchar(233) NOT NULL,
  `category_id` int(11) NOT NULL,
  `main_description` varchar(2000) NOT NULL,
  `Shopping_Returns` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_name`, `product_price`, `description`, `product_image`, `category_id`, `main_description`, `Shopping_Returns`) VALUES
(38, 'Water Bottle', 45, 'hgftr trt54', '4.jpg', 2, '', ''),
(39, 'Water Bottle', 45, 'ghghyy78ti', '7.jpg', 4, '', ''),
(40, 'Mind Reader Kettlebell', 343, 'wera wfaewf rfe', '9.jpg', 5, '', ''),
(42, 'Fitness Slam Ball', 34, ' ergg rgreg ergfre g', '5.jpg', 4, 'g wrgrgfvdxcv v \r\nb s\r\ndfb\r\ndvbfdv\r\ndfv\r\nbv v v \r\nv fdv\r\ndgbdgbgf\r\nb\r\nb\r\n', 'gbdfbfdvb\r\nb\r\ndgb\r\ngfb\r\nfg\r\nb'),
(45, 'Mind Reader Kettlebell', 45, 'vzsds', '12.jpg', 3, 'faSFC ', 'czxc z xc');

-- --------------------------------------------------------

--
-- Table structure for table `social_media`
--

CREATE TABLE `social_media` (
  `id` int(11) NOT NULL,
  `facebook` varchar(2000) NOT NULL,
  `instagram` varchar(2000) NOT NULL,
  `twitter` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `social_media`
--

INSERT INTO `social_media` (`id`, `facebook`, `instagram`, `twitter`) VALUES
(1, 'https://www.facebook.com/', 'https://www.instagram.com/', 'https://twitter.com/i/flow/login');

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `id` int(11) NOT NULL,
  `subname` text NOT NULL,
  `category_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`id`, `subname`, `category_name`) VALUES
(37, 'dsvx', '2');

-- --------------------------------------------------------

--
-- Table structure for table `trainer`
--

CREATE TABLE `trainer` (
  `id` int(11) NOT NULL,
  `tainer_name` text NOT NULL,
  `profession` varchar(200) NOT NULL,
  `trainer_image` varchar(200) NOT NULL,
  `biography` varchar(2000) NOT NULL,
  `achivement` varchar(2000) NOT NULL,
  `contact_info` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trainer`
--

INSERT INTO `trainer` (`id`, `tainer_name`, `profession`, `trainer_image`, `biography`, `achivement`, `contact_info`) VALUES
(1, 'Robert Cristopher ', 'Bodybuilding Trainer', '1.jpg', '  ', '  ', ''),
(3, 'Oliviea Williams', ' Fitness Trainer', '2.jpg', '', '', ''),
(5, 'Jenifer Parker ', 'Aerobics Instructor', '4.jpg', '', '', ''),
(6, 'Alvin Santiago ', 'Aerobics Trainer', '5.jpg', '', '', ''),
(7, 'Halbert Bourn', ' Cardio Trainer', '7.jpg', '<span style=\"color: rgb(37, 37, 37); font-family: Roboto, sans-serif; font-size: 16px;\">Halbert Bourn is very professional and expert trainer. In his carier, he done great job. He never compromise about his work to maintain our health luptas sit fugit, sed cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter onsequences that are extremely very professional</span>   ', '<ul class=\"achivement-info\" style=\"padding: 0px; margin-right: 0px; margin-bottom: 30px; margin-left: 0px; color: rgb(37, 37, 37); font-family: Roboto, sans-serif; font-size: 16px;\"><li style=\"list-style: none; font-size: 18px; margin-bottom: 17px;\">Two times National Champion of Bodibuilding - 2017 & 2018</li><li style=\"list-style: none; font-size: 18px; margin-bottom: 17px;\">Best Bodybuilding Trainer - 2019</li><li style=\"list-style: none; font-size: 18px; margin-bottom: 17px;\">Best National Trainer - 2019</li></ul>   ', '<ul class=\"contact-info\" style=\"padding: 0px; margin-right: 0px; margin-bottom: 30px; margin-left: 0px; line-height: 1; color: rgb(37, 37, 37); font-family: Roboto, sans-serif; font-size: 16px;\"><li style=\"list-style: none; line-height: 1; margin-bottom: 23px;\"><span class=\"title\" style=\"font-size: 18px; margin-bottom: 14px; color: rgb(229, 186, 3); display: block;\">Getsphae Gym</span>256B, South City, Main Road, New York, USA</li><li style=\"list-style: none; line-height: 1; margin-bottom: 23px;\"><span class=\"title\" style=\"font-size: 18px; margin-bottom: 14px; color: rgb(229, 186, 3); display: block;\">Phone</span><a href=\"http://localhost/lakhangym/team-details.php?id=7#/\" style=\"color: rgb(37, 37, 37); transition: all 0.3s ease 0s;\">09 (236) 654 879 </a>or <a href=\"http://localhost/lakhangym/team-details.php?id=7#/\" style=\"color: rgb(37, 37, 37); transition: all 0.3s ease 0s;\">09 (587) 654 123</a></li><li style=\"list-style: none; line-height: 1; margin-bottom: 23px;\"><span class=\"title\" style=\"font-size: 18px; margin-bottom: 14px; color: rgb(229, 186, 3); display: block;\">Email</span><a href=\"http://localhost/lakhangym/team-details.php?id=7#/\" style=\"color: rgb(37, 37, 37); transition: all 0.3s ease 0s;\">info@example,com </a>or <a href=\"http://localhost/lakhangym/team-details.php?id=7#/\" style=\"color: rgb(37, 37, 37); transition: all 0.3s ease 0s;\">info@getshape.com</a></li></ul>');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `billing_details`
--
ALTER TABLE `billing_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `class_category`
--
ALTER TABLE `class_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `class_schedule`
--
ALTER TABLE `class_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gymadmin`
--
ALTER TABLE `gymadmin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gymcontact`
--
ALTER TABLE `gymcontact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gymregister`
--
ALTER TABLE `gymregister`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inquiry`
--
ALTER TABLE `inquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `membership`
--
ALTER TABLE `membership`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsletter`
--
ALTER TABLE `newsletter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_product`
--
ALTER TABLE `order_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `social_media`
--
ALTER TABLE `social_media`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trainer`
--
ALTER TABLE `trainer`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `billing_details`
--
ALTER TABLE `billing_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `class_category`
--
ALTER TABLE `class_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `class_schedule`
--
ALTER TABLE `class_schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `gymadmin`
--
ALTER TABLE `gymadmin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `gymcontact`
--
ALTER TABLE `gymcontact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `gymregister`
--
ALTER TABLE `gymregister`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `inquiry`
--
ALTER TABLE `inquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `membership`
--
ALTER TABLE `membership`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `newsletter`
--
ALTER TABLE `newsletter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `order_product`
--
ALTER TABLE `order_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `social_media`
--
ALTER TABLE `social_media`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `trainer`
--
ALTER TABLE `trainer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
