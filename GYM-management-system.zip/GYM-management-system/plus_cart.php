
<?php include "dbcon.php";?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>cart-update</title>
</head>
<body>
    <?php
        include "dbcon.php";
        $cart_id = $_GET['id']; // id get thai 
        $select = mysqli_query($con,"SELECT * FROM `cart` where id = $cart_id"); //cart select kryu
        $row = mysqli_fetch_array($select); // cart fetch kryu
        $uty = $row['quantity'] + '1';

        $pid = $row['product_id'];
        $productselect = mysqli_query($con," SELECT * FROM `product` WHERE id = $pid");
        $productrow = mysqli_fetch_array($productselect);
        $total = $productrow['product_price'] + $row['total'];
        $update = mysqli_query($con,"UPDATE `cart` SET `quantity`='$uty',`total`='$total' where id = $cart_id ");
        if($update){
            echo "<script>window.location.href = 'shop-cart.php';</script>";
        }else{
            echo "Fail";
        }
    ?>
</body>
</html>