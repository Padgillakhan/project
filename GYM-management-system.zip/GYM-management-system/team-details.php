<?php include "header.php"?>   
  <main class="main-content">
    <!--== Start Page Title Area ==-->
    <section class="page-title-area bg-img" data-bg-img="assets/img/photos/bg-page2.jpg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page-title-content">
              <h2 class="title"><span>INSTRUCTOR </span><br>PROFILE</h2>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Page Title Area ==-->

    <!--== Start Team Details Area ==-->
    <section class="team-area team-details-area">
      <div class="container">
        <div class="row">

          <?php 
            include("dbcon.php");
            $id = $_GET['id'];
            $teamselect = mysqli_query($con,"SELECT * FROM `trainer`WHERE id='$id'");
            $teamrow = mysqli_fetch_array($teamselect);
          ?>

          <div class="col-md-6">
            <div class="section-title">
              <h2 class="title"><?php echo $teamrow['tainer_name'];?> </h2>
              <div class="subtitle"><?php echo $teamrow['profession'];?></div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="btn-play-box">
              <a class="btn-play play-video-popup" href="https://www.youtube.com/watch?v=MLpWrANjFbI"><img src="assets/img/icons/play-btn1.png" alt="Image">VIEW TRAINING</a>
            </div>
          </div>
        </div>
        <div class="row team-details-item">
          <div class="col-md-6">
            <div class="thumb">
              <img src="admin/trainer/<?php echo $teamrow['trainer_image'];?>" alt="image">
              <div class="social-icons">
                <a href="#"><i class="fa fa-facebook icon"></i></a>
                <a href="#"><i class="fa fa-phone icon"></i></a>
                <a href="#"><i class="fa fa-instagram icon"></i></a>
                <a href="#"><i class="fa fa-twitter icon"></i></a>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="content">
              <h4 class="title">Biography</h4>
              <?php echo $teamrow['biography'];?>
              <h4 class="title">Achivement</h4>
              <ul class="achivement-info">
                <?php echo $teamrow['achivement'];?>
              </ul>
              <h4 class="title">Contact info</h4>
              <ul class="contact-info">
                <?php echo $teamrow['contact_info'];?>
              </ul>
            </div>
          </div>
        </div>
        <div class="row team-details-info">
          <div class="col-md-6">
            <div class="section-title">
              <h2 class="title">Professional Skill</h2>
              <div class="desc">
                <p>Halbert Bourn is very professional and expert trainer. In his carier, he done <br>great job. He never compromise maintain our very professional</p>
              </div>
            </div>
            <div class="progress-content">
              <!-- Start Progress Item -->
              <div class="progress-item">
                <div class="progress-info">
                  <span class="title">Bodybuilding Training</span>
                  <span class="percent"></span>
                </div>
                <div class="progress-line">
                  <div class="progress-bar-line" data-percent="95%"></div>
                </div>
              </div>
              <!-- Start Progress Item -->
              <div class="progress-item">
                <div class="progress-info">
                  <span class="title">Cardio Training</span>
                  <span class="percent"></span>
                </div>
                <div class="progress-line">
                  <div class="progress-bar-line" data-percent="80%"></div>
                </div>
              </div>
              <!-- Start Progress Item -->
              <div class="progress-item">
                <div class="progress-info">
                  <span class="title">Fitness Training</span>
                  <span class="percent"></span>
                </div>
                <div class="progress-line">
                  <div class="progress-bar-line" data-percent="90%"></div>
                </div>
              </div>
              <!-- Start Progress Item -->
              <div class="progress-item">
                <div class="progress-info">
                  <span class="title">Aerobics Training</span>
                  <span class="percent"></span>
                </div>
                <div class="progress-line">
                  <div class="progress-bar-line" data-percent="65%"></div>
                </div>
              </div>
            </div>
            <div class="team-rating"> 
              <h2 class="title">Rating</h2>
              <div class="ratting-icons">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="section-title">
              <h2 class="title">Send Message</h2>
              <div class="desc">
                <p>If you need any information, feel free to send me message I will try to answer your and give you proper tips about your message</p>
              </div>
            </div>
            <div class="comment-form-wrap">
              <div class="clearfix"></div>
              <?php
                include "dbcon.php";
                if(isset($_POST["send"])){
                  $name = $_POST['name'];
                  $email   = $_POST['email'];
                  $message = $_POST['message'];

                  $insert = mysqli_query($con,"INSERT INTO  `inquiry` (`name`,`email`,`message`) VALUES('$name','$email','$message')");
                  if($insert){
                    echo "success";
                  }else{
                    echo "fail";
                  }
                }
              ?>
              <form action="#" method="post">
                <div class="comment-form-content">
                  <div class="row row-gutter-13">
                    <div class="col-md-6">
                      <div class="form-group">
                        <input class="form-control" name="name" type="text" placeholder="Name" required="">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <input class="form-control" name="email" type="email" placeholder="Email" required="">
                      </div>
                    </div>
                    <div class="col-md-12">
                      <div class="form-group">
                        <textarea class="form-control" name="message" id="comment" cols="45" rows="7" placeholder="Write message here" required=""></textarea>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group m-0">
                        <button class="btn btn-theme" name="send" type="submit">SEND MESSAGE</button>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Team Area ==-->

    <!--== Start Testimonial Area ==-->
    <section class="testimonial-area testimonial-inner-style2">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="section-title stitle-style2 text-center">
              <div class="subtitle">TESTIMONIALS</div>
              <h2 class="title">THAT’S <span>WHAT MY<br>CLIENT </span>SAYS</h2>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="testimonial-content" data-aos="fade-up" data-aos-duration="1100">
              <div class="testimonial-slider-content">
                <div class="swiper-container testimonial-slider2-container">
                  <div class="swiper-wrapper testimonial-slider">
                    <div class="swiper-slide testimonial-single">
                      <div class="client-content">
                        <p>“Getshape is very smart and technical sound gym, which maintain professional trainer as well as modern equipments. to maintain our health luptas sit fugit, sed quia cuuntur mag dolores eos qui rat ione volupta pleasure rationally”</p>
                        <img class="quote-icon" src="assets/img/icons/quote-icon.jpg" alt="Icon">
                      </div>
                      <div class="client-info">
                        <h4 class="name">Stephen Fleming</h4>
                        <h6 class="designation">Mariland, USA</h6>
                      </div>
                    </div>
                    <div class="swiper-slide testimonial-single">
                      <div class="client-content">
                        <p>“Getshape is very smart and technical sound gym, which maintain professional trainer as well as modern equipments. to maintain our health luptas sit fugit, sed quia cuuntur mag dolores eos qui rat ione volupta pleasure rationally”</p>
                        <img class="quote-icon" src="assets/img/icons/quote-icon.jpg" alt="Icon">
                      </div>
                      <div class="client-info">
                        <h4 class="name">Morgan Williams</h4>
                        <h6 class="designation">New Jersey, USA</h6>
                      </div>
                    </div>
                  </div>
                  <!-- Add Arrows -->
                  <div class="swiper-btn-wrap">
                    <div class="swiper-btn-prev"><i class="fa fa-angle-left"></i></div>
                    <div class="swiper-btn-next"><i class="fa fa-angle-right"></i></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Testimonial Area ==-->
  </main>
  <?php include "footer.php"?> 