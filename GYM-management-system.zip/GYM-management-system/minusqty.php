<?php
include "dbcon.php";

// Get the cart ID from the URL parameter
$cart_id = $_GET['id'];

// Fetch the cart item from the database
$select = mysqli_query($con, "SELECT * FROM `cart` WHERE id = $cart_id");
$row = mysqli_fetch_array($select);

// Check if the cart item exists
if ($row) {
    // Retrieve the current quantity and subtract 1 from it
    $current_quantity = $row['quantity'];
    $updated_quantity = $current_quantity - 1;
   
    $pid = $row['product_id'];
    $productselect = mysqli_query($con," SELECT * FROM `product` WHERE id = $pid");
    $productrow = mysqli_fetch_array($productselect);
    $total =   $row['total'] - $productrow['product_price'];

    // Check if the updated quantity is not negative
    if ($updated_quantity >= 1) {
        // Update the cart item with the new quantity
        $update = mysqli_query($con, "UPDATE `cart` SET `quantity`='$updated_quantity',`total`='$total' WHERE id = $cart_id");

        // Check if the update was successful
        if ($update) {
            echo "<script>window.location.href = 'shop-cart.php';</script>";
        } else {
            echo "Failed to update quantity.";
        }
    } else {
        echo "Quantity cannot be negative.";
    }
} else {
    echo "Cart item not found.";
}
?>
</body>
</html>