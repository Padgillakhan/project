<?php include "header.php"?>    
  <main class="main-content">
    <!--== Start Page Title Area ==-->
    <section class="page-title-area bg-img" data-bg-img="assets/img/photos/bg-page2.jpg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page-title-content content-style2">
              <h2 class="title"><span>OUR </span>PRODUCTS CATEGORY</h2>
              <div class="desc">
                <p class="ml-0">We have very professional and exprt Instructor and they can very important to maintain<br>our health luptas sit fugit, sed quia cuuntur magni dolores some products</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Page Title Area ==-->

    <!--== Start Shop Area Wrapper ==-->
    <section class="product-area product-grid-area">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-9 order-0 order-lg-1">
            <div class="product-content-area">
              <div class="row">
                    <?php
                        include("dbcon.php");
                        $id = $_GET['id'];
                        $productselect =mysqli_query($con,"SELECT * FROM `product` WHERE category_id='$id' ");
                        $productrow = mysqli_fetch_array($productselect);
                      ?>
                <div class="col-sm-6 col-md-4">
                  <!-- Start Product Item -->
                  <div class="product-item">
                    <div class="product-thumb">
                        <a href="product-details.php?id=<?php echo $productrow['id'];?>">
                          <img src="admin/product_image/<?php echo $productrow['product_image'];?>" alt="image">
                        </a>
                        <div class="product-action">
                          <a class="btn-theme" href="cart.php?id=<?php echo $productrow['id']; ?>">Add to Cart</a>
                        </div>
                    </div>
                    <div class="product-info">
                      <h4 class="title"><a href="product-details?id=<?php echo $productrow['id'];?>"><?php echo $productrow['product_name'];?></a></h4>
                      <div class="prices">
                        <span class="price">$<?php echo $productrow['product_price'];?></span>
                      </div>
                    </div>
                 
                  </div>
                  <!-- End Product Item -->
                </div>
                <div class="col-sm-6 col-md-4">
                  <!-- Start Product Item -->
                 
                  <!-- End Product Item -->
                </div>
              
          
              </div>
            
            </div>
          </div>
          <div class="col-md-12 col-lg-3 order-1 order-lg-0">
            <div class="sidebar-area shop-sidebar-area mt-md-90">
              <div class="widget-item">
                <div class="widget-title">
                  <h3 class="title">SEARCH</h3>
                </div>
                <div class="widget-body">
                  <div class="widget-search-box">
                    <form action="#" method="post">
                      <div class="form-input-item">
                        <label for="search2" class="sr-only">Keywords here</label>
                        <input type="text" id="search2" placeholder="Keywords here">
                        <button type="submit" class="btn-src">
                          <i class="fa fa-search"></i>
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
              <div class="widget-item">
                <div class="widget-title">
                  <h3 class="title">CATEGORIES</h3>
                </div>
                <div class="widget-body widget-categorie-body">
                  <div class="widget-categories">
                    <ul>
                    <?php
                      include("dbcon.php");
                        $no=0;  
                        $select =mysqli_query($con,"SELECT * FROM `category`");
                        while ($row = mysqli_fetch_array($select)) { 
                        $no++;
                    ?>
                      <li><a href="shop-category.php?id=<?php echo $row['id']; ?>">  <?php echo $row['name'];?></a></li>
                      <?php } ?>
                    </ul>
               
                  </div>
                </div>
              </div>
  
              <div class="widget-item mb-md-0">
                <div class="widget-content-ads">
                  <div class="ads-thumb">
                    <a href="shop.php"><img src="assets/img/shop/s1.jpg" alt="Image"></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Shop Area Wrapper ==-->
  </main>
  <?php include "footer.php"?>  