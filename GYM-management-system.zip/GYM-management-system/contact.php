<?php include "header.php"?>
  
  <main class="main-content">
    <!--== Start Page Title Area ==-->
    <section class="page-title-area bg-img" data-bg-img="assets/img/photos/bg-page2.jpg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page-title-content content-style2">
              <h2 class="title"><span>CONTACT </span>US</h2>
              <div class="desc">
                <p>We have very professional and exprt Instructor and they can very important to maintain<br>our health luptas sit fugit, sed quia cuuntur magni dolores some products</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Page Title Area ==-->

    <!--== Start Contact Area ==-->
    <section class="contact-area position-relative">
      <div class="contact-page-wrap">
        <div class="container">
          <div class="row">
            <div class="row">
              <div class="col-lg-12">
                <div class="section-title text-center">
                  <h2 class="title">GET IN <span>TOUCH</span></h2>
                  <div class="desc">
                    <p>Contact us if you neeed information</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="contact-info-content">
                <div class="contact-info-item">
                  <div class="icon">
                    <img class="icon-img" src="assets/img/icons/c1.png" alt="Icon">
                  </div>
                  <div class="content">
                    <p>252B, Central Street Main road<br>Belix Tower, New York, USA</p>
                  </div>
                </div>
                <div class="contact-info-item">
                  <div class="icon">
                    <img class="icon-img" src="assets/img/icons/c2.png" alt="Icon">
                  </div>
                  <div class="content">
                    <a href="tel://09(123)456789">09 (123) 456 789</a>
                    <a href="tel://09(987)654321">09 (987) 654 321</a>
                  </div>
                </div>
                <div class="contact-info-item">
                  <div class="icon">
                    <img class="icon-img" src="assets/img/icons/c3.png" alt="Icon">
                  </div>
                  <div class="content">
                    <a href="mailto://info@example.com">info@example.com</a>
                    <a href="index.php">www.example.com</a>
                  </div>
                </div>
              </div>
            </div>
          </div>

        <!--  php code Start -->
              <?php
                include "dbcon.php";
                if(isset($_POST["submit"])){
                  $con_name = $_POST['con_name'];
                  $con_email = $_POST['con_email'];
                  $con_message = $_POST['con_message'];

                  $insert = mysqli_query($con,"INSERT INTO  `gymcontact` (`con_name`,`con_email`,`con_message`) VALUES('$con_name','$con_email','$con_message')");
                  if($insert){
                    echo "success";
                  }else{
                    echo "fail";
                  }
                }
              ?>
        <!-- End code -->
               
          <div class="row">
            <div class="col-lg-6">
              <div class="contact-form mb-md-90">
                <form class="contact-form-wrapper"  method="post"> <!-- id="contact-form" -->
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="section-title">
                        <h2 class="title">Send Message</h2>
                        <div class="desc">
                          <p>If you need any information, feel free to send me message I will try to answer your and give you proper tips about your message</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="row row-gutter-12">
                        <div class="col-md-6">
                          <div class="form-group">
                            <input class="form-control"  type="text" name="con_name" placeholder="Name">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <input class="form-control" type="email" name="con_email" placeholder="Email">
                          </div>
                        </div>
                        <div class="col-md-12">
                          <div class="form-group mb-0">
                            <textarea name="con_message" placeholder="Write message here"></textarea>
                          </div>
                        </div>
                        <div class="col-md-12">
                          <div class="form-group mb-0">
                            <button class="btn btn-theme" name="submit" type="submit">SEND MESSAGE</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
              <!-- Message Notification -->
              <div class="form-message"></div>
            </div>
            <div class="col-lg-6">
              <div class="contact-map-area">              
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.8402891185374!2d144.95373631590425!3d-37.81720974201477!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad65d4c2b349649%3A0xb6899234e561db11!2sEnvato!5e0!3m2!1sen!2ssg!4v1607294780661!5m2!1sen!2ssg"></iframe>
              </div>
            </div>
          </div>
        </div>
        <div class="shape-group">
          <div class="shape-img5">
            <img src="assets/img/photos/shape1.png" alt="Image">
          </div>
        </div>
      </div>
    </section>
    <!--== End Contact Area ==-->
  </main>
<?php include "footer.php"?>