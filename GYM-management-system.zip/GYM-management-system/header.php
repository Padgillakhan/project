
<!-- <?php session_start(); ?> -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title> </title>

    <!--== Favicon ==-->
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon" />

    <!--== Google Fonts ==-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,500i,700,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Oswald:200,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Exo:400" rel="stylesheet">

    <!--== Bootstrap CSS ==-->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>
    <!--== Font-awesome Icons CSS ==-->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet"/>
    <!--== Pe Icon 7 Min Icons CSS ==-->
    <link href="assets/css/pe-icon-7-stroke.min.css" rel="stylesheet"/>
    <!--== Animate CSS ==-->
    <link href="assets/css/animate.css" rel="stylesheet"/>
    <!--== Aos CSS ==-->
    <link href="assets/css/aos.css" rel="stylesheet"/>
    <!--== FancyBox CSS ==-->
    <link href="assets/css/jquery.fancybox.min.css" rel="stylesheet"/>
    <!--== Slicknav CSS ==-->
    <link href="assets/css/slicknav.css" rel="stylesheet"/>
    <!--== Swiper CSS ==-->
    <link href="assets/css/swiper.min.css" rel="stylesheet"/>
    <!--== Slick CSS ==-->
    <link href="assets/css/slick.css" rel="stylesheet"/>
    <!--== Main Style CSS ==-->
    <link href="assets/css/style.css" rel="stylesheet" />

</head>

<body>

<!--wrapper start-->
<div class="wrapper page-blog-wrapper">

  <!-- == Start Preloader Content == -->
  <div class="preloader-wrap">
    <div class="preloader">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
  <!--== End Preloader Content ==-->
  <!--== Start PHP code area ==-->

  <!--== End PHP code area ==-->
  <!--== Start Header Wrapper ==-->
  <header class="header-area header-default header-transparent header-style sticky-header">
    <div class="container">
      <div class="row row-gutter-0 align-items-center">
        <div class="col-4 col-xs-3 col-sm-3 col-md-3 col-xl-3">
          <div class="header-logo-area">
            <a href="index.php">
            
            <h4 class="text-warning">gym world</h4>  
            
            </a>
          </div>
        </div>
        <div class="col-8 col-sm-9 col-xl-9">
          <div class="header-align">
            <div class="header-navigation-area d-none d-xl-block">
              <ul class="main-menu nav position-relative">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <!-- <li class="has-submenu"><a href="login-register.php">Login/Register</a></li> -->
                <li class="has-submenu"><a href="classes.php">Classes</a> </li>
                <li class="has-submenu"><a href="shop.php">Shop</a></li>
                <li class="has-submenu"><a href="team.php">Trainers</a></li>
                <!-- <li class="has-submenu"><a href="blog-left-sidebar.php">Blog</a> -->
                  
                </li>
                <li><a href="contact.php">Contact</a></li>
              </ul>
            </div>
            

            <div class="header-action-area header-navigation-area d-none d-xl-block">
              <div class="dropdown">
                <a class="btn  dropdown-toggle text-warning" href="profile.php" type="button" data-bs-toggle="dropdown" >
                  My Account
                </a>
                <ul class="dropdown-menu">
                  
                <?php 
                  include "dbcon.php";
                  
                  if(isset($_SESSION['user_id']) && $_SESSION['user_id'] != "") {
                      echo '<li><a class="dropdown-item " href="profile.php">Profile</a></li>';
                      echo '<li><a class="dropdown-item" href="shop-cart.php">Cart</a></li>';
                      echo '<li><a class="dropdown-item" href="Change_password.php">Change password</a></li>';
                      echo '<li><a class="dropdown-item" href="logout.php">Logout</a></li>';
                  } else {
                      // User doesn't exist in the database
                      echo '<li><a class="dropdown-item" href="login-register.php">Login/Register</a></li>';
                
                  }
                ?>
                </ul>
              </div> 
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>
  <!--== End Header Wrapper ==-->