<?php session_start();?>
<?php include "header.php"?>  
  <main class="main-content">
    <!--== Start Page Title Area ==-->
    <section class="page-title-area bg-img" data-bg-img="assets/img/photos/bg-page2.jpg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page-title-content content-style2">
              <h2 class="title"><span>SHOP</span> CHECKOUT</h2>
              <div class="desc">
                <p class="ml-0">We have very professional and exprt Instructor and they can very important to maintain <br>our health luptas sit fugit, sed quia cuuntur magni dolores some products</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Page Title Area ==-->

    <!--== Start Shop Checkout Area ==-->
    <section class="shop-checkout-area">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="shop-return-login" id="returnloginAccordion">
              <div class="card">
                <h6>Returning customer? <span data-bs-toggle="collapse" data-bs-target="#returnloginaccordion"> Click here to login</span>
                </h6>
                <div id="returnloginaccordion" class="collapse" data-bs-parent="#returnloginAccordion">
                  <div class="card-body">
                    <p>If you have shopped with us before, please enter your details in the boxes below. If you are a new customer, please proceed to the Billing & Shipping section.</p>
                    <form action="#" method="post">
                      <div class="form-group">
                        <label for="rl_username">Username or email <span class="required">*</span></label>
                        <input class="form-control" id="rl_username" type="text">
                      </div>
                      <div class="form-group">
                        <label for="rl_password">Password <span class="required">*</span></label>
                        <input class="form-control" id="rl_password" type="text">
                      </div>
                      <button class="btn btn-coupon w-100">Login</button>
                      <div class="remember-lostpassword">
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="RadioRememberMe">
                          <label class="custom-control-label ps-1" for="RadioRememberMe">Remember me</label>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-12">
            <div class="shop-checkout-coupon" id="checkoutloginAccordion">
              <div class="card">
                <h6>Have a coupon? <span data-bs-toggle="collapse" data-bs-target="#couponaccordion"> Click here to enter your code</span>
                </h6>
                <div id="couponaccordion" class="collapse" data-bs-parent="#checkoutloginAccordion">
                  <div class="card-body">
                    <p>If you have a coupon code, please apply it below.</p>
                    <form action="#" method="post">
                      <div class="form-group">
                        <input class="form-control" type="text" placeholder="Enter Your Coupon Code">
                      </div>
                      <button class="btn btn-coupon">Apply Coupon</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php
          include "dbcon.php";
          
          if (isset($_POST["submit"])) {
            
            $id=$_SESSION['user_id'];
            $cf_name = $_POST['cf_name'];
            $cf_company_name = $_POST['cf_company_name'];
            $cf_country = $_POST['cf_country'];
            $cf_street_address = $_POST['cf_street_address'];
            $cf_apartment_address = $_POST['cf_apartment_address'];
            $cf_town_city = $_POST['cf_town_city'];
            $cf_state_region = $_POST['cf_state_region'];
            $cf_zip = $_POST['cf_zip'];
            $cf_phone = $_POST['cf_phone'];
            $cf_email = $_POST['cf_email'];

            $insert = mysqli_query($con,"INSERT INTO `billing_details` (`user_id`,`cf_name`,`cf_company_name`,`cf_country`,`cf_street_address`,`cf_apartment_address`,`cf_town_city`,`cf_state_region`,`cf_zip`,`cf_phone`,`cf_email`)
            VALUES('$id','$cf_name','$cf_company_name','$cf_country','$cf_street_address','$cf_apartment_address','$cf_town_city','$cf_state_region','$cf_zip','$cf_phone','$cf_email')"); 
            $order_id = mysqli_insert_id($con);
        if($insert) {

              $id=$_SESSION['user_id'];
              $select =mysqli_query($con,"SELECT * FROM `cart` where user_id =  $id  ");
              while ($row = mysqli_fetch_array($select)) { 
              $prodid = $row['product_id'];
              $produtselect =mysqli_query($con,"SELECT * FROM `product` WHERE id = $prodid");
              $productrow = mysqli_fetch_array($produtselect);
              $product_img = $productrow['product_image'];
              $productname =$productrow ['product_name'];
              $quantity = $row['quantity'];
              $price = $row['price'];
              $total = $row['total' ];
              $odr_insert = mysqli_query($con,"INSERT INTO `order_product` (`user_id`,`product_id`,`product_image`,`product_name`,`quantity`,`price`,`total`,`order_id`) 
              VALUES('$id','$prodid','$product_img','$productname','$quantity','$price','$total','$order_id')");

              $delete =mysqli_query($con,"DELETE FROM `cart` WHERE user_id='$id'");

              }
            }
            else {
                echo "Fail";
            }
          }
        ?>
        <div class="row ">
          <div class="col-lg-8 col-md-12">
            <div class="shop-billing-form">
              <form action="#" method="post">
                <h4 class="title">Billing details</h4>
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="cf_name">Name <abbr class="required" title="required">*</abbr></label>
                      <input class="form-control" name="cf_name" id="c_name" type="text">
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label for="cf_company_name">Company name (optional)</label>
                  <input class="form-control" name="cf_company_name" id="cf_company_name" type="text">
                </div>

                <div class="form-group">
                  <label for="cf_country_region">Country / Region <abbr class="required" title="required">*</abbr></label>
                  <input class="form-control" name="cf_country" id="cf_country" type="text">
                </div>

                <div class="form-group">
                  <label for="cf_street_address">Street address <abbr class="required" title="required">*</abbr></label>
                  <input class="form-control" name="cf_street_address" id="cf_street_address" type="text" placeholder="House number and street name">
                </div>

                <div class="form-group">
                  <input class="form-control" name="cf_apartment_address" type="text" placeholder="Apartment, suite, unit, etc. (optional)">
                </div>

                <div class="form-group">
                  <label for="cf_town_city">Town / City <abbr class="required" title="required">*</abbr></label>
                  <input class="form-control" name="cf_town_city" id="cf_town_city" type="text">
                </div>

                <div class="form-group">
                  <label for="cf_state_region">State <abbr class="required" title="required">*</abbr></label>
                  <input class="form-control" name="cf_state_region" id="cf_state_region" type="text">
                </div>

                <div class="form-group">
                  <label for="cf_zip">ZIP <abbr class="required" title="required">*</abbr></label>
                  <input class="form-control" name="cf_zip" id="cf_zip" type="number">
                </div>

                <div class="form-group">
                  <label for="cf_phone">Phone <abbr class="required" title="required">*</abbr></label>
                  <input class="form-control" name="cf_phone" id="cf_phone" type="number">
                </div>

                <div class="form-group">
                  <label for="cf_email">Email address <abbr class="required" title="required">*</abbr></label>
                  <input class="form-control" name="cf_email" id="cf_email" type="text">
                </div>

                <div class="checkout-box-wrap ship-different-address">
              
                  <div class="ship-to-different single-form-row">
                
                  </div>
                </div>

                <div class="form-group">
                  <label for="cf_order_notes">Order notes (optional)</label>
                  <textarea class="form-control" name="comment" id="cf_order_notes" placeholder="Notes about your order, e.g. special notes for delivery."></textarea>
                </div>
             
            </div>
          </div>

          <div class="col-lg-4 col-md-12 mt-md-70">
            <h4 class="title">Your order</h4>
            <div class="order-review-details">
              <table class="table">
                <thead>
                  <tr>
                    <th>Product</th>
                    <th>Subtotal</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                    include("dbcon.php");
                    $no=0; 
                    $id=$_SESSION['user_id'];
                    $select =mysqli_query($con,"SELECT * FROM `cart` where user_id =  $id  ");
                    while ($row = mysqli_fetch_array($select)) { 
                    $prodid = $row['product_id'];
                    $produtselect =mysqli_query($con,"SELECT * FROM `product` WHERE id = $prodid");
                    $productrow = mysqli_fetch_array($produtselect);
                    $no++;
                  ?>
                  <tr>
                    <td>
                      <span class="product-title"><?php echo $productrow['product_name']; ?></span>
                      <span class="product-quantity"> × <?php echo $row['quantity'];?></span>
                    </td>
                    
                    <td>$<?php echo $row['price'];?></td>
                  </tr>
                  <!-- <tr>
                    <td>
                      <span class="product-title">Knit cropped cardigan</span>
                      <span class="product-quantity"> × 1</span>
                    </td>
                    <td>£29.90</td>
                  </tr> -->
                  <?php } ?>
                </tbody>
                <tfoot>
                <?php 
                    include "dbcon.php";
                    $selectsum = mysqli_query($con,"SELECT SUM(total) AS TotalItemsOrdered FROM cart where user_id =  $id ");
                    $sum = mysqli_fetch_array($selectsum);
                  ?>
                  <tr class="cart-subtotal">
                    <th>Subtotal</th>
                    <td>$<span class="amount"><?php echo $sum['TotalItemsOrdered'];?></span></td>

                  </tr>
                  <tr class="shipping">
                    <th class="shipping-title">Shipping</th>
                    <td class="shipping-check">
                       <div class="form-check">
                        <!-- <input type="radio" class="form-check-input" id="validationFormCheck2" name="radio-stacked" required> -->
                        <label class="form-check-label" for="validationFormCheck2"> + <span>$50.00</span></label>
                      </div>
                    </td>
                  </tr>
                 
                  <tr class="final-total">
                    <th>Total</th>
                    <td>$<span class="amount"><?php echo $sum['TotalItemsOrdered'] + 50;?></span></td>
                  </tr>
                </tfoot>
               
              </table>
              <div class="shop-payment-method">
                <div id="accordion">
                  <div class="card">
                    <div class="card-header" id="direct_bank_transfer">
                      <h4 class="title" data-bs-toggle="collapse" data-bs-target="#itemOne" aria-controls="itemOne" aria-expanded="false">Direct bank transfer</h4>
                    </div>
                    <div id="itemOne" class="collapse" aria-labelledby="direct_bank_transfer" data-bs-parent="#accordion">
                      <div class="card-body">
                        <p>Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order will not be shipped until the funds have cleared in our account.</p>
                      </div>
                    </div>
                  </div>

                  <div class="card">
                    <div class="card-header" id="check_payments">
                      <h5 class="title" data-bs-toggle="collapse" data-bs-target="#itemTwo" aria-controls="itemTwo" aria-expanded="true">Check payments</h5>
                    </div>
                    <div id="itemTwo" class="collapse show" aria-labelledby="check_payments" data-bs-parent="#accordion">
                      <div class="card-body">
                        <p>Please send a check to Store Name, Store Street, Store Town, Store State / County, Store Postcode.</p>
                      </div>
                    </div>
                  </div>

                  <div class="card">
                    <div class="card-header" id="cash_on_delivery">
                      <h5 class="title" data-bs-toggle="collapse" data-bs-target="#itemThree" aria-controls="itemThree" aria-expanded="false">Cash on delivery</h5>
                    </div>
                    <div id="itemThree" class="collapse" aria-labelledby="cash_on_delivery" data-bs-parent="#accordion">
                      <div class="card-body">
                        <p>Pay with cash upon delivery.</p>
                      </div>
                    </div>
                  </div>

                  <div class="card">
                    <div class="card-header" id="Pay_Pal">
                      <h5 class="title" data-bs-toggle="collapse" data-bs-target="#item4" aria-controls="item4" aria-expanded="false">PayPal <img src="assets/img/icons/paypal.png" alt=""> <a href="#/">What is PayPal?</a></h5>
                    </div>
                    <div id="item4" class="collapse" aria-labelledby="Pay_Pal" data-bs-parent="#accordion">
                      <div class="card-body">
                        <p>Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account.</p>
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            </div>
            <p class="shop-checkout-info">Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our privacy policy.</p>
            <button class="btn place-order-btn" name="submit" type="submit">Place order</button>
            </form>
          </div>
        </div>
      </div>
    </section>
    <!--== End Shop Checkout Area ==-->
  </main>

  <?php include "footer.php"?>  