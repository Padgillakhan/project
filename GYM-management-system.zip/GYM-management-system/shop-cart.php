<style>
.quantity {
  color: black;
  display: flex;
  border-radius: 4px;
  overflow: hidden;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.quantity a {
  color: black;
  border: 1 ;
  cursor: pointer;
  font-size: 20px;
  width: 30px;
  height: auto;
  text-align: center;
  transition: background-color 0.2s;
}

.input-box {
  width: 40px;
  text-align: center;
  border: none;
  padding:3px 12px;
  font-size: 16px;
  outline: none;
}

/* Hide the number input spin buttons */
.input-box::-webkit-inner-spin-button,
.input-box::-webkit-outer-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* .input-box[type="number"] {
  -moz-appearance: textfield;
} */

</style>

<?php include "header.php"?>   

  <main class="main-content">
    <!--== Start Page Title Area ==-->
    <section class="page-title-area bg-img" data-bg-img="assets/img/photos/bg-page2.jpg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page-title-content content-style2">
              <h2 class="title"><span>SHOP</span> CART</h2>
              <div class="desc">
                <p class="ml-0">We have very professional and exprt Instructor and they can very important to maintain <br>our health luptas sit fugit, sed quia cuuntur magni dolores some products</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Page Title Area ==-->

    <!--== Start Cart Area Wrapper ==-->
    <section class="product-area cart-page-area">
      <div class="container">
        <div class="row">
                
          <div class="col-lg-8">
            <div class="shipping-info">
              <div class="loading-bar">
                <div class="load-percent"></div>
                <div class="label-free-shipping">
                  <div class="free-shipping svg-icon-style">
                    <span class="svg-icon" id="svg-icon-shipping2" data-svg-icon="assets/img/icons/shop1.svg"></span>
                  </div>
                  <p>Spend £101.10 to get Free Shipping</p>
                </div>
              </div>
            </div>
            <div class="cart-table-wrap">
              <div class="cart-table table-responsive">
             
                
                <table>
              
                  <thead>
                    <tr>  
                      <th class="pro-remove"> </th>
                      <th class="pro-thumbnail"> </th>
                      <th class="pro-name">Product</th>
                      <th class="pro-price">Price</th>
                      <th class="pro-quantity">Quantity</th>
                      <th class="pro-subtotal">Subtotal</th>
                    </tr>
                  </thead>
                  <tbody>

                  <?php
                    include("dbcon.php");
                   
                    $no=0; 
                    $id=$_SESSION['user_id'];
                    $select =mysqli_query($con,"SELECT * FROM `cart` where user_id =  $id  ");
                    while ($row = mysqli_fetch_array($select)) { 
                    $prodid = $row['product_id'];
                    $produtselect =mysqli_query($con,"SELECT * FROM `product` WHERE id = $prodid");
                    $productrow = mysqli_fetch_array($produtselect);
                    $no++;
                  ?>
                    <tr>
                      <td class="pro-remove"><a href="cart_remove.php?id=<?php echo $row['id'];?>"><i class="fa fa-remove"></i></a></td>
                      <td class="pro-thumbnail">
                        <div class="pro-info">
                          <div class="pro-img">
                            <img src="admin/product_image/<?php echo $productrow['product_image'];?>" alt="image">
                          </div>
                        </div>
                      </td>
                      <td class="pro-name"><span><?php echo $productrow['product_name'];?></span></td>
                      <td class="pro-price"><span>$<?php echo $productrow['product_price'];?></span></td>
                      <td class="pro-quantity">

                      <div class="quantity">
                        <a href="minusqty.php?id=<?php echo $row['id'];?>" class="minus" aria-label="Decrease">&minus;</a>
                        <input type="number" class="input-box" value="<?php echo $row['quantity'];?>" min="1" max="10">
                        <a href="plus_cart.php?id=<?php echo $row['id'];?>" aria-label="Increase">&plus;</a>
                      </div>
                      <td class="pro-subtotal"><span>$<?php echo $productrow['product_price'] * $row['quantity'];?>  </span></td>
                    </tr>
                    <?php }?>
                  </tbody>
               
                </table>
              </div>
            </div>
            <div class="coupon-action">
              <div class="coupon">
                <!-- <input type="text" name="coupon_code" class="input-text" id="coupon_code" value="" placeholder="Coupon code">
                <button type="submit" class="button" name="apply_coupon" value="Apply coupon">Apply coupon</button> -->
              </div>
              <!-- <button type="submit" class="button" name="apply_coupon" value="Apply coupon">Update cart</button> -->
            </div>
          </div>
          <div class="col-lg-4">
            <div class="cart-payment">
              <div class="cart-subtotal">
                <h2 class="title">Cart totals</h2>
                <table>
                  <?php 
                    include "dbcon.php";
                    $selectsum = mysqli_query($con,"SELECT SUM(total) AS TotalItemsOrdered FROM cart where user_id =  $id ");
                    $sum = mysqli_fetch_array($selectsum);
                  ?>
                  <tbody>
                    <tr>
                      <th>Subtotal</th>
                     <td><span class="amount"><?php echo $sum['TotalItemsOrdered'];?></span></td>
                    </tr>
                    <tr class="shipping-totals">
                      <th>Shipping Charge </th>
                      <td>
                        <ul>
                          <li>
                            <div class="form-check">
                              <!-- <input class="form-check-input" type="text" name="flexRadioDefault" id="flexRadioDefault1"> -->
                              <label class="form-check-label" for="flexRadioDefault1"> +  <span class="amount">₹50.00</span></label>
                            </div>
                            <!-- <div class="form-check">
                              <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked>
                              <label class="form-check-label" for="flexRadioDefault2">Local pickup</label>
                            </div> -->
                          </li>
                        </ul>
                        <!-- <p>Shipping options will be updated during checkout.</p>
                        <p>Calculate shipping</p> -->
                      </td>
                    </tr>
                    <tr class="amount-total">
                      <th>Total</th>
                      <td><span class="amount"><?php echo $sum['TotalItemsOrdered']+50;?></span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <a class="btn-theme" href="shop-checkout.php">Proceed to Checkout</a>
            </div>
          </div>
    
        </div>
      </div>
    </section>
    <!--== End Cart Area Wrapper ==-->
  </main>

 <?php include "footer.php"?> 
 
 
<script>
(function () {
  const quantityContainer = document.querySelector(".quantity");
  const minusBtn = quantityContainer.querySelector(".minus");
  const plusBtn = quantityContainer.querySelector(".plus");
  const inputBox = quantityContainer.querySelector(".input-box");

  updateButtonStates();

  quantityContainer.addEventListener("click", handleButtonClick);
  inputBox.addEventListener("input", handleQuantityChange);

  function updateButtonStates() {
    const value = parseInt(inputBox.value);
    minusBtn.disabled = value <= 1;
    plusBtn.disabled = value >= parseInt(inputBox.max);
  }

  function handleButtonClick(event) {
    if (event.target.classList.contains("minus")) {
      decreaseValue();
    } else if (event.target.classList.contains("plus")) {
      increaseValue();
    }
  }

  function decreaseValue() {
    let value = parseInt(inputBox.value);
    value = isNaN(value) ? 1 : Math.max(value - 1, 1);
    inputBox.value = value;
    updateButtonStates();
    handleQuantityChange();
  }

  function increaseValue() {
    let value = parseInt(inputBox.value);
    value = isNaN(value) ? 1 : Math.min(value + 1, parseInt(inputBox.max));
    inputBox.value = value;
    updateButtonStates();
    handleQuantityChange();
  }

  function handleQuantityChange() {
    let value = parseInt(inputBox.value);
    value = isNaN(value) ? 1 : value;

    // Execute your code here based on the updated quantity value
    console.log("Quantity changed:", value);
  }
})();

 </script>