
<?php include "header.php"?>  

  <main class="main-content">
    <!--== Start Page Title Area ==-->
    <section class="page-title-area bg-img" data-bg-img="assets/img/photos/bg-page2.jpg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page-title-content content-style2">
              <h2 class="title"><span>Profile </span></h2>
              <div class="desc">
                <p>We have very professional and exprt Instructor and they can very important to maintain<br>our health luptas sit fugit, sed quia cuuntur magni dolores some products</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Page Title Area ==-->

    <!--== Start Contact Area ==-->
    <section class="contact-area position-relative">
      <div class="contact-page-wrap">
        <div class="container">
          <div class="row">
            <div class="row">
              <div class="col-lg-12">
                <div class="section-title text-center">
                  <h2 class="title">GET IN <span>TOUCH</span></h2>
                  <div class="desc">
                    <p>Profile Details</p>
                  </div>
                </div>
              </div>
            </div>
          
          </div>
        <!-- php  code start -->
        <?php
            include "dbcon.php";
            $id=$_SESSION['user_id'];
            $select =mysqli_query($con,"SELECT * FROM `gymregister` WHERE id ='$id'");
            $row =mysqli_fetch_array($select);
        ?>
            
        <?php 
            include "dbcon.php";  
            if(isset($_POST["update"])) {
                $username = $_POST['username'];
                $number = $_POST['number'];
                $gmail = $_POST['gmail'];
                $password = $_POST['password'];
                $gender = $_POST['gender']; 

                if($_FILES["image"]["name"] ==""){
                    $file_name = $row['image'];  // img insert  karava mate 
                    
                }else{
                    $file_name =$_FILES["image"]["name"];
                    $file_tmp =$_FILES["image"]["tmp_name"];
                    move_uploaded_file($file_tmp,"images/".$file_name);
                }
    
    
                $edits =mysqli_query($con,"UPDATE `gymregister` SET `username`='$username', `number`='$number', `gmail`='$gmail', `password`='$password', `gender`='$gender',   `image`='$file_name'  WHERE id = '$id' ");
        
                if($edits){
                    echo "<script>window.location.href='profile.php'</script>";
                }
                else{   
                    echo"fail";
                }
        
            }
   
        ?>
        <!-- php code end -->
          <div class="row">
            <div class="col-lg-6">
              <div class="contact-form mb-md-90">
                <form class="login-form-wrapper"  method="post" enctype="multipart/form-data">
                      <div class="row">
                        <div class="col-lg-12">
                          <div class="row">
                            <div class="col-md-12">
                              <div class="form-group">
                                <label for="RegUserName" class="form-label">Username *</label>
                                <input type="text" name="username" value="<?php echo $row['username'];?>" class="form-control" id="RegUserName">
                              </div>
                            </div>
                            <div class="col-md-12 ">
                              <label class="form-label  mt-15" for="number">Number *</label>
                              <input type="number" name="number"  value="<?php echo $row['number'];?>" id="number" accept="" class="form-control">
                            </div>
                            <div class="col-md-12">
                              <div class="form-group">
                                <label for="regemail" class="form-label mt-15">Email address *</label>
                                <input type="email" name="gmail" value="<?php echo $row['gmail'];?>" class="form-control" id="regemail">
                              </div>
                            </div>
                            <div class="col-md-12">
                              <div class="form-group mb-0">
                                <label for="regpassword" class="form-label mt-15">Password *</label>
                                <input type="password" name="password" value="<?php echo $row['password'];?>" class="form-control" id="regpassword">
                              </div>
                            </div><br>
                            <div class="col-md-12">
                              <label class="form-label mt-15" for="gender">Gender *</label><br>
                                          
                              <input type="radio" <?php if($row['gender']=="male"){ echo "checked='checked'";}?>  name="gender" value="male" checked>  
                              <label class="form-label" for="gender" >male</label>
          
                              <input type="radio" <?php if($row['gender']=="female"){ echo "checked='checked'";}?>  name="gender" value="female">
                              <label for="gender" class="form-label">Female</label>
                            </div>
                            <div class="col-md-12">
                              <label class="form-label" for="upload">Uploade img *</label>
                              <input type="file" name="image" class="form-control">
                            </div>
                            <div class="col-md-12">
                              <div class="form-group mb-0">
                                <p>Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our privacy policy.</p>
                            </div>
                            <div class="col-md-12">
                              <div class="form-group mb-0 form-group-info">
                                <button class="btn btn-theme btn-black text-white" name="update" type="submit">Update</button>
                                <!-- <a class="btn btn-theme btn-black" href="logout.php">Log out</a> -->
                              </div>
                            </div>
                           
                          </div>
                        </div>
                        </div>
                      </div>
                    </form>
               </div>
              <!-- Message Notification -->
              <div class="form-message"></div>
            </div>
            <div class="col-lg-6">
              <div class="contact-map-area">   
                <img src="images/<?php echo $row['image'];?>" alt="" width="400px"><br><br>
                <h3 class="text-start">Profile picture</h3>
                <!-- img side ma show karava mate  -->
              </div>
              <?php
                  include "dbcon.php";
                  $id=$_SESSION['user_id'];
                  $membershipselect =mysqli_query($con,"SELECT * FROM `membership` WHERE userid ='$id'");
                  $membershiprow =mysqli_fetch_array($membershipselect);
              ?>
              <div class="col-md-12">
                <label for="membership" class="form-label">Membership</label>
                <input type="text" name="membership" class="form-control" readonly value="<?php echo $membershiprow['membership'];?>" >
              </div>
            </div>
          </div>
        </div>
        <div class="shape-group">
          <div class="shape-img5">
            <img src="assets/img/photos/shape1.png" alt="Image">
          </div>
        </div>
      </div>
    </section>
    <!--== End Contact Area ==-->
  </main>
  <?php include "footer.php"?>  