<?php include "header.php"?>  
  <main class="main-content">
    <!--== Start Page Title Area ==-->
    <section class="page-title-area bg-img" data-bg-img="assets/img/photos/bg-page2.jpg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page-title-content content-style2">
              <h2 class="title"><span>BODY </span>BUILDING</h2>
              <div class="desc">
                <p class="ml-0">We provide special  classes very important to maintain our health luptas sit fugit, <br>for your fitness sed quia cuuntur magni dolores eos qui rat ione volupta</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Page Title Area ==-->

    <!--== Start class Area ==-->
    <section class="class-details-area">
      <div class="container">
        <div class="row">
          <div class="col-lg-8">
            <div class="class-details-item">
              <div class="thumb">
                <img class="w-100" src="assets/img/service/details/1.jpg" alt="Image">
              </div>
              <div class="content">
                <h2 class="title">BODY BUILDING CLASS</h2>
                <p>Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which some great pleasure </p>
                <p>Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter</p>
                <div class="class-details-info">
                  <h2 class="title">Class details</h2>
                  <p>Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which some great pleasure more than enough to make your body fit with this class, but you need to continure your class regularly and timely </p>
                </div>
              </div>
              <div class="class-info-area">
                <div class="content bg-img" data-bg-img="assets/img/service/details/bg1.jpg">
                  <div class="row row-gutter-0">
                    <div class="col-6 col-sm-4">
                      <div class="info-item">
                        <h4 class="title">Intensity</h4>
                         <p>Medium and High</p>
                      </div>
                    </div>
                    <div class="col-6 col-sm-4">
                      <div class="info-item info-style-2">
                        <h4 class="title">Feel</h4>
                        <p>High Energy</p>
                      </div>
                    </div>
                    <div class="col-6 col-sm-4">
                      <div class="info-item info-style-3">
                        <h4 class="title">Group</h4>
                        <p>16 People</p>
                      </div>
                    </div>
                    <div class="col-6 col-sm-4">
                      <div class="info-item">
                        <h4 class="title">Price</h4>
                        <p>$25/month</p>
                      </div>
                    </div>
                    <div class="col-6 col-sm-4">
                      <div class="info-item info-style-2">
                        <h4 class="title">No of Instructor</h4>
                        <p>2 Instructor</p>
                      </div>
                    </div>
                    <div class="col-6 col-sm-4">
                      <div class="info-item info-style-3">
                        <h4 class="title">Duration</h4>
                        <p>50 Minutes</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="thumb bg-img" data-bg-img="assets/img/service/details/2.jpg">
                </div>
              </div>
              <div class="class-info-list-area">
                <h2 class="title">What to bring with you</h2>
                <p>Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter</p>
                <ul>
                  <li>Resuable water bottle</li>
                  <li>Comfortable workout clothes</li>
                  <li>Shower Essentials</li>
                  <li>Compact microfiber towel</li>
                  <li>Clean & Comfortable shoes</li>
                  <li>Headphone</li>
                </ul>
              </div>
              <div class="class-info-schedule-area">
                <h2 class="title">Class schedule</h2>
                <p>Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter</p>
                <table class="table">
                  <thead>
                    <tr>
                      <th class="day">Day</th>
                      <th class="time">Time</th>
                      <th class="tnstructor">Instructor</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Sunday</td>
                      <td class="time">9.00 am to 10.30 am</td>
                      <td>Nikolus Smith</td>
                    </tr>
                    <tr>
                      <td>Monday</td>
                      <td class="time">9.00 am to 10.30 am</td>
                      <td>Nikolus Smith</td>
                    </tr>
                    <tr>
                      <td>Wednesday</td>
                      <td class="time">3.00 pm to 4.30 pm</td>
                      <td>Robert Cristopher</td>
                    </tr>
                    <tr>
                      <td>Thursday</td>
                      <td class="time">3.00 pm to 4.30 pm</td>
                      <td>Robert Cristopher</td>
                    </tr>
                  </tbody>
                </table>
              </div>

            </div>
            <div class="team-area">
              <div class="row">
                <div class="col-lg-12">
                  <div class="team-section-title">
                    <h2 class="title">Instructors</h2>
                  </div>
                </div>
              </div>
              <div class="row row-gutter-22 team-items-style2">
                <div class="col-sm-6">
                  <!-- Start Team Item -->
                  <div class="team-item mb-xs-30">
                    <div class="team-member">
                      <div class="thumb">
                        <a href="team-details.php"><img src="assets/img/team/10.jpg" alt="Image"></a>
                      </div>
                      <div class="content">
                        <div class="member-info">
                          <h4 class="name"><a href="team-details.php">Nikolus Smith</a></h4>
                          <h6 class="designation">Bodybuild Trainer</h6>
                          <div class="social-icons">
                            <a href="#"><i class="fa fa-facebook icon"></i></a>
                            <a href="#"><i class="fa fa-phone icon"></i></a>
                            <a href="#"><i class="fa fa-instagram icon"></i></a>
                            <a href="#"><i class="fa fa-twitter icon"></i></a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- End Team Item -->
                </div>
                <div class="col-sm-6">
                  <!-- Start Team Item -->
                  <div class="team-item">
                    <div class="team-member">
                      <div class="thumb">
                        <a href="team-details.php"><img src="assets/img/team/9.jpg" alt="Image"></a>
                      </div>
                      <div class="content">
                        <div class="member-info">
                          <h4 class="name"><a href="team-details.php">Robert Cristoper</a></h4>
                          <h6 class="designation">Bodybuild Trainer</h6>
                          <div class="social-icons">
                            <a href="#"><i class="fa fa-facebook icon"></i></a>
                            <a href="#"><i class="fa fa-phone icon"></i></a>
                            <a href="#"><i class="fa fa-instagram icon"></i></a>
                            <a href="#"><i class="fa fa-twitter icon"></i></a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- End Team Item -->
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-8 col-md-6 col-lg-4">
            <div class="sidebar-area class-sidebar-area inner-right-padding mt-md-90">
              <div class="widget-item">
                <div class="widget-title">
                  <h3 class="title">CATEGORIES</h3>
                </div>
                <div class="widget-body widget-categorie-body">
                  <div class="widget-categories2">
                    <ul>
                      <?php 
                        include("dbcon.php");
                        $no=0;  
                        $select =mysqli_query($con,"SELECT * FROM `class_category`");
                        while ($row = mysqli_fetch_array($select)) { 
                        $no++;
                      ?>
                        <li><a href="class_category.php?id=<?php echo $row['id']; ?>"> <?php echo $row['name'];?><span>View</span></a></li>   
                      <?php } ?>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="widget-item">
                <div class="widget-title">
                  <h3 class="title">OPENING HOUR</h3>
                </div>
                <div class="widget-body widget-hour-body p-0">
                  <div class="widget-hour">
                    <ul>
                      <li>Monday - Friday <i class="fa fa-long-arrow-right"></i> <span>7.00 am to 10.00pm</span></li>
                      <li>Saturday - Sunday <i class="fa fa-long-arrow-right"></i> <span>9.00 am to 8.00 pm</span></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End class Area ==-->
  </main>

  <?php include "footer.php"?>