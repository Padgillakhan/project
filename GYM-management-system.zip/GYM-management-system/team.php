<?php include "header.php"?> 
  <main class="main-content">
    <!--== Start Page Title Area ==-->
    <section class="page-title-area bg-img" data-bg-img="assets/img/photos/bg-page2.jpg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page-title-content">
              <h2 class="title"><span>OUR</span><br>INSTRUCTORS</h2>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Page Title Area ==-->

    <!--== Start Team Area ==-->
    <section class="team-area team-inner-area">
      <div class="container">
        <div class="row">

          <?php
            include("dbcon.php");
            $no=0;  
            $select =mysqli_query($con,"SELECT * FROM `trainer` ");
            while ($row = mysqli_fetch_array($select)) { 
            $no++;
          ?>
          <div class="col-sm-6 col-md-4 col-lg-3">


            <!-- Start Team Item -->
            <div class="team-item">
              <div class="team-member">
                <div class="thumb">
                <img src="admin/trainer/<?php echo $row['trainer_image'];?>" alt="image">
                </div>
                <div class="content">
                  <div class="member-info">
                    <h4 class="name"><a href="team-details.php"><?php echo $row['tainer_name'];?></a></h4>
                    <h6 class="designation"><?php echo $row['profession'];?></h6>
                    <div class="social-icons">
                      <a href="#/"><i class="fa fa-facebook icon"></i></a>
                      <a href="#/"><i class="fa fa-phone icon"></i></a>
                      <a href="#/"><i class="fa fa-instagram icon"></i></a>
                      <a href="#/"><i class="fa fa-twitter icon"></i></a>
                    </div>
                    <div class="team-footer">
                      <a class="btn" href="team-details.php?id=<?php echo $row['id'];?>">VIEW PROFILE</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- End Team Item -->

          </div>
          <?php } ?>
        </div>
      </div>
    </section>

  </main>
  <?php include "footer.php"?> 