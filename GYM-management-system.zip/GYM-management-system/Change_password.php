
<?php include "dbcon.php"; ?> 
<?php include "header.php"; ?>  
  
  <main class="main-content">
    <!--== Start Page Title Area ==-->
    <section class="page-title-area bg-img" data-bg-img="assets/img/photos/bg-page2.jpg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page-title-content content-style2">
              <h2 class="title"><span>Change</span> Password</h2>
              <div class="desc">
                <p class="ml-0">We have very professional and exprt Instructor and they can very important to maintain <br>our health luptas sit fugit, sed quia cuuntur magni dolores some products</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Page Title Area ==-->

    <!--== Start Contact Area ==-->
    <div class="account-login-area">
      <div class="container">
        <div class="row">
          <div class="col-lg-7 m-auto">
            <div class="login-top">
              <nav class="login-form-nav">
                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                  <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Change Password</button>
                  <!-- <button class="nav-link nav-register" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Register</button> -->
                </div>
              </nav>
            </div>

            <!-- php code start -->
            <?php
                if(isset($_POST["chnage_password"])){
                    $id = $_SESSION['user_id'];
                    $changepasswordselect = mysqli_query($con,"SELECT * FROM `gymregister` WHERE id='$id' ");
                    $changepasswordrow = mysqli_fetch_array($changepasswordselect);
                    
                    $old_pass = $changepasswordrow['password'];
                    $current_pss = $_POST['old_password'];
                    $new_pass = $_POST['new_password'];
                    $confirm_pass = $_POST['cnf_password']; 
                    
                    if($old_pass = $current_pss ){
                        if( $new_pass = $confirm_pass){
                            $update = mysqli_query($con,"UPDATE `gymregister` SET password='$new_pass' WHERE id = $id");
                            echo "your password successfuly update";
                        }else{
                            echo "New password and confirm password do not match";
                        }
                    }else{
                        echo "Invalid Old Password";
                    }
                }
            ?>
            <!-- php code end -->
            <div class="login-bottom">
              <div class="login-form-content tab-content" id="nav-tabContent">
                <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                  <div class="login-form">
                    <form class="login-form-wrapper" id="login-form"  method="post">
                      <div class="row">
                        <div class="col-lg-12">
                          <div class="row">
                            <div class="col-md-12">
                              <div class="form-group mb-0">
                                <label for="password" class="form-label mt-15">Password *</label>
                                <input type="password"  name="old_password"  class="form-control" id="password">
                              </div>
                            </div>
                            <div class="col-md-12">
                              <div class="form-group mb-0">
                                <label for="password" class="form-label mt-15">New Password *</label>
                                <input type="password"  name="new_password"  class="form-control" id="password">
                              </div>
                            </div>
                            <div class="col-md-12">
                              <div class="form-group mb-0">
                                <label for="password" class="form-label mt-15">Confirm  Password *</label>
                                <input type="password"  name="cnf_password"  class="form-control" id="password">
                              </div>
                            </div>
                            <div class="col-md-12">
                              <div class="form-group mt-15">
                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                <label class="form-check-label" for="exampleCheck1"> Remember me</label>
                              </div>
                            </div>
                            <div class="col-md-12">
                              <div class="form-group form-group-info">
                                <button class="btn btn-theme btn-black" name="chnage_password" type="submit">Change Password</button>
                                <a class="btn-forgot" href="shop-account.php">Lost your password?</a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                  <!-- Message Notification -->
                  <div class="form-message"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--== End Contact Area ==-->
  </main>
<?php include "footer.php";?>