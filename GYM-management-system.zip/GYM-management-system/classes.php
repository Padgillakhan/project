<?php include "header.php"?>
  <main class="main-content">
    <!--== Start Page Title Area ==-->
    <section class="page-title-area bg-img" data-bg-img="assets/img/photos/bg-page2.jpg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page-title-content content-style2">
              <h2 class="title"><span>OUR </span>CLASSES</h2>
              <div class="desc">
                <p class="ml-0">We provide special  classes very important to maintain our health luptas sit fugit, <br>for your fitness sed quia cuuntur magni dolores eos qui rat ione volupta</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Page Title Area ==-->

    <!--== Start Service Area ==-->
    <section class="service-area class-service-area position-relative">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="section-title text-center">
              <h2 class="title"><span>CLASSES </span>WE PROVIDE</h2>
              <div class="desc">
                <p>Gym classes dolor sit amet, consectetur adipiscing elit, sed do eiod tempor <br>didunt ut labore et dolore m et dolore magna aliqua minim niam</p>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-10 offset-md-1 col-lg-12 offset-lg-0">
            <div class="row">
            <?php
                  include("dbcon.php");
                  $no=0;  
                  $classselect =mysqli_query($con,"SELECT * FROM `class` ");
                  while ($row = mysqli_fetch_array($classselect)) { 
                  $no++;
                ?>
              <div class="col-sm-6 col-lg-4">
                <!-- Start Service Item -->
                <div class="service-item">
                  <div class="inner-content">
                    <div class="thumb">
                      <a href="class-details.php?id=<?php echo $row ['id']; ?>"><span><img src="admin/team/<?php echo $row['class_img'];?>" alt="Image"></span></a>
                    </div>
                    <div class="content">
                      <h4 class="title"><a href="class-details.php?id=<?php echo $row['id'];?>"><?php echo $row['class_name'];?></a></h4>
                      <h4 class="class-time">Duration <?php echo $row['class_duration'];?> Minutes</h4>
                    </div>
                  </div>
                </div>
                <!-- End Service Item -->
              </div>
              <?php } ?>
            </div>
          </div>
        </div>
      </div>
      <div class="shape-group">
        <div class="shape-img6">
          <img src="assets/img/photos/shape1.png" alt="Image">
        </div>
      </div>
    </section>
  </main>
<?php include "footer.php"?>