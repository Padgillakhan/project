<?php include "header.php"?>  
  <main class="main-content">
    <!--== Start Page Title Area ==-->
    <section class="page-title-area bg-img" data-bg-img="assets/img/photos/bg-page2.jpg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page-title-content content-style2">
              <h2 class="title"><span>ABOUT </span>US</h2>
              <div class="desc">
                <p class="ml-0">Gym is very important to maintain our health luptas sit fugit,<br>sed quia cuuntur magni dolores eos qui rat ione volupta</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Page Title Area ==-->

    <!--== Start About Area ==-->
    <section class="about-area about-inner-area position-relative">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="section-title stitle-style2 text-left text-lg-center">
              <div class="subtitle">WELCOME TO Zymzoo</div>
              <h2 class="title">BEST <span>GYM STATION </span>FOR YOU BECAUSE<br>WE PROVIDE <span>BEST </span>QUALITY OF <span>EQUIPMENTS <br></span>AS WELL AS <span class="underline">INSTRACTORS</span></h2>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-7 order-1 order-lg-0">
            <div class="thumb">
              <img src="assets/img/about/2.png" alt="Image">
            </div>
          </div>
          <div class="col-lg-5 order-0 order-lg-1">
            <div class="about-content">
              <div class="desc">
                <p>Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely </p>
              </div>
              <div class="inner-content">
                <div class="about-list">
                  <ul>
                    <li>Builds Aerobic Power</li>
                    <li>Strong body Structure</li>
                    <li>Boots your Memory</li>
                    <li>Brng about resultful Sleep</li>
                  </ul>
                </div>
                <div class="inline-style">
                  <a class="btn btn-theme" href="classes.php">LET’S START</a>
                  <div class="btn-play-box">
                    <a class="btn-play play-video-popup" href="https://www.youtube.com/watch?v=MLpWrANjFbI"><img src="assets/img/icons/play-btn1.png" alt="Image">INTRO VIDEO</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="shape-group">
        <div class="shape-img3">
          <img src="assets/img/photos/shape1.png" alt="Image">
        </div>
      </div>
    </section>
    <!--== End About Area ==-->

    <!--== Start Features Area Wrapper ==-->
    <section class="features-area">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="featured-columns-wrap">
              <div class="featured-items-style2 bg-img" data-bg-img="assets/img/photos/bg-f2.jpg">
                <div class="row row-gutter-0">
                  <div class="col-md-6">
                    <!-- Start Featured Item -->
                    <div class="featured-item">
                      <div class="featured-icon">
                        <img src="assets/img/icons/f1.png" alt="Image">
                      </div>
                      <div class="featured-info">
                        <h4>Best Training</h4>
                        <p>Best Training dolor sit consectetur adipiscing elit, sed do eiusmod temp incididunt ut labore et dolore</p>
                      </div>
                    </div>
                    <!-- End Featured Item -->
                  </div>
                  <div class="col-md-6">
                    <!-- Start Featured Item -->
                    <div class="featured-item">
                      <div class="featured-icon">
                        <img src="assets/img/icons/f2.png" alt="Image">
                      </div>
                      <div class="featured-info">
                        <h4>Qualified Instructor</h4>
                        <p>Qualified Instructor consectetur adipg elit, sed do eiusmod tempor incididu ut labore  dolore are same magna </p>
                      </div>
                    </div>
                    <!-- End Featured Item -->
                  </div>
                  <div class="col-md-6">
                    <!-- Start Featured Item -->
                    <div class="featured-item">
                      <div class="featured-icon">
                        <img src="assets/img/icons/f3.png" alt="Image">
                      </div>
                      <div class="featured-info">
                        <h4>Latest Equipment</h4>
                        <p class="m-0">Latest equipment dolor consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna </p>
                      </div>
                    </div>
                    <!-- End Featured Item -->
                  </div>
                  <div class="col-md-6">
                    <!-- Start Featured Item -->
                    <div class="featured-item">
                      <div class="featured-icon">
                        <img src="assets/img/icons/f4.png" alt="Image">
                      </div>
                      <div class="featured-info">
                        <h4>Award Winners</h4>
                        <p class="m-0">Award winner dolor sit consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna </p>
                      </div>
                    </div>
                    <!-- End Featured Item -->
                  </div>
                </div>
              </div>
              <div class="featured-discount-item">
                <div class="thumb" data-bg-img="assets/img/photos/f1.jpg"></div>
                <div class="content">
                  <h2>35%</h2>
                  <h3>DISCOUNT</h3>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Features Area Wrapper ==-->

    <!--== Start Pricing Area Wrapper ==-->
    <section class="pricing-area pricing-default-area">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="section-title text-center">
              <h2 class="title">CHOOSE YOUR <span>MEMBERSHIP</span></h2>
              <div class="desc">
                <p>Gym classes dolor sit amet, consectetur adipiscing elit, sed do eiod tempor <br>didunt ut labore et dolore m et dolore magna aliqua minim niam</p>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <!--== Start Pricing Item ==-->
            <div class="pricing-item mb-sm-50">
              <div class="pricing-title">
                <h5>BASIC</h5>
              </div>
              <div class="pricing-thumb pricing-thumb-style1">
                <img src="assets/img/photos/pricing1.png" alt="Image">
              </div>
              <div class="pricing-amount">
                <h2>$120</h2>
                <h3>per month</h3>
              </div>
              <div class="pricing-content">
                <ul class="pricing-list">
                  <li>6 hour access to the gym.</li>
                  <li>5 Instrument to use.</li>
                  <li>3 class per week</li>
                  <li>One month membership</li>
                  <li>Free drinking package</li>
                  <li>One personal instructor</li>
                </ul>
              </div>
              <div class="pricing-footer">
                <div class="pricing-footer-inner">
                  <a href="membership.php" class="btn btn-theme">JOIN TODAY</a>
                </div>
              </div>
            </div>
            <!--== End Pricing Item ==-->
          </div>
          <div class="col-md-4">
            <!--== Start Pricing Item ==-->
            <div class="pricing-item mb-sm-50">
              <div class="pricing-title">
                <h5>SILVER</h5>
              </div>
              <div class="pricing-thumb pricing-thumb-style2">
                <img src="assets/img/photos/pricing2.png" alt="Image">
              </div>
              <div class="pricing-amount">
                <h2>$165</h2>
                <h3>per month</h3>
              </div>
              <div class="pricing-content">
                <ul class="pricing-list">
                  <li>Unlimited access to the gym.</li>
                  <li>20 Instrument to use.</li>
                  <li>5 class per week</li>
                  <li>Six month membership</li>
                  <li>Free drinking package</li>
                  <li>Two personal instructor</li>
                </ul>
              </div>
              <div class="pricing-footer">
                <div class="pricing-footer-inner">
                  <a href="membership.php" class="btn btn-theme">JOIN TODAY</a>
                </div>
              </div>
            </div>
            <!--== End Pricing Item ==-->
          </div>
          <div class="col-md-4">
            <!--== Start Pricing Item ==-->
            <div class="pricing-item">
              <div class="pricing-title">
                <h5>GOLD</h5>
              </div>
              <div class="pricing-thumb pricing-thumb-style3">
                <img src="assets/img/photos/pricing3.png" alt="Image">
              </div>
              <div class="pricing-amount">
                <h2>$225</h2>
                <h3>per month</h3>
              </div>
              <div class="pricing-content">
                <ul class="pricing-list">
                  <li>Unlimited access to the gym.</li>
                  <li>All Instrument to use.</li>
                  <li>7 class per week</li>
                  <li>One year membership</li>
                  <li>Free drinking package</li>
                  <li>Five personal instructor</li>
                </ul>
              </div>
              <div class="pricing-footer">
                <div class="pricing-footer-inner">
                  <a href="membership.php" class="btn btn-theme">JOIN TODAY</a>
                </div>
              </div>
            </div>
            <!--== End Pricing Item ==-->
          </div>
        </div>
      </div>
    </section>

    <!--== Start Popular Products Area Wrapper ==-->
    <section class="product-area product-default-area position-relative">
      <div class="container">
        <div class="row">
          <div class="col-lg-12-">
            <div class="section-title text-center">
              <h2 class="title"><span>GATESHAPE </span>PRODUCTS</h2>
              <div class="desc">
                <p>Gym classes dolor sit amet, consectetur adipiscing elit, sed do eiod tempor <br>didunt ut labore et dolore m et dolore magna aliqua minim niam</p>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <?php
            include("dbcon.php");
            $no=0;  
            $select =mysqli_query($con,"SELECT * FROM `product` LIMIT 4 ");
            while ($row = mysqli_fetch_array($select)) { 
            $no++;
          ?>

          <div class="col-sm-6 col-md-3">
            <!-- Start Product Item -->
            <div class="product-item mb-sm-30">
              <div class="product-thumb">
                <a href="product-details.php?id=<?php echo $row['id'];?>">
                  <img src="admin/product_image/<?php echo $row['product_image'];?>" alt="image">
                </a>
                <div class="ribbons">
                  <span class="ribbon ribbon-new">NEW</span>
                </div>
                <div class="product-action">
                <a class="btn-theme" href="cart.php?id=<?php echo $row['id'];?>">Add to Cart</a>
                </div>
              </div>
              <div class="product-info">
              <h4 class="title"><a href="product-details.php?id=<?php echo $row['id'];?>"><?php echo $row['product_name'];?></a></h4>
                <div class="prices">
                        <span class="price">$<?php echo $row['product_price'];?></span>
                </div>
              </div>
            </div>
            <!-- End Product Item -->
          </div>
          <?php } ?>
        </div>
        <div class="row">
          <div class="col-lg-12">
            <div class="product-btn">
              <a class="btn-border" href="shop.php">VIEW ALL</a>
            </div>
          </div>
        </div>
      </div>
      <div class="shape-group">
        <div class="shape-img4">
          <img src="assets/img/photos/shape1.png" alt="Image">
        </div>
      </div>
    </section>
    <!--== End Popular Products Area Wrapper ==-->

    <!--== Start Features Area Wrapper ==-->
    <section class="features-area features-default-area">
      <div class="container-fluid p-0">
        <div class="row row-gutter-0">
          <div class="col-sm-6 col-lg-3">
            <!-- Start Featured Item -->
            <div class="featured-item">
              <div class="featured-thumb">
                <img src="assets/img/class/f1.jpg" alt="Image">
              </div>
              <div class="featured-info">
                <h4>Dumble back lift</h4>
                <h5>3 SETS, <span>5 MINUTES</span></h5>
              </div>
            </div>
            <!-- End Featured Item -->
          </div>
          <div class="col-sm-6 col-lg-3">
            <!-- Start Featured Item -->
            <div class="featured-item">
              <div class="featured-thumb">
                <img src="assets/img/class/f2.jpg" alt="Image">
              </div>
              <div class="featured-info">
                <h4>Weight lifting</h4>
                <h5>4 SETS, <span>3 MINUTES</span></h5>
              </div>
            </div>
            <!-- End Featured Item -->
          </div>
          <div class="col-sm-6 col-lg-3">
            <!-- Start Featured Item -->
            <div class="featured-item">
              <div class="featured-thumb">
                <img src="assets/img/class/f3.jpg" alt="Image">
              </div>
              <div class="featured-info">
                <h4>Abs<br>fitness</h4>
                <h5>2 SETS, <span>3 MINUTES</span></h5>
              </div>
            </div>
            <!-- End Featured Item -->
          </div>
          <div class="col-sm-6 col-lg-3">
            <!-- Start Featured Item -->
            <div class="featured-item">
              <div class="featured-thumb">
                <img src="assets/img/class/f4.jpg" alt="Image">
              </div>
              <div class="featured-info">
                <h4>Ropes lifting</h4>
                <h5>5 SETS, <span>3 MINUTES</span></h5>
              </div>
            </div>
            <!-- End Featured Item -->
          </div>
        </div>
      </div>
    </section>
    <!--== End Features Area Wrapper ==-->
  </main>
<?php include "footer.php"?>