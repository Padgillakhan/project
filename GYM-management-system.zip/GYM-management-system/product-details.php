<?php include "header.php"?>  
  <main class="main-content site-wrapper-reveal">
    <!--== Start Page Title Area ==-->
    <section class="page-title-area bg-img" data-bg-img="assets/img/photos/bg-page2.jpg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page-title-content">
              <h2 class="title"><span>PRODUCT </span><br>DETAILS</h2>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Page Title Area ==-->

    <!--== Start Shop Area ==-->
    <section class="product-area shop-single-product">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-9">
            <?php
              include("dbcon.php");
              $id = $_GET['id'];
              $sel = mysqli_query($con,"SELECT * FROM `product` WHERE id='$id'");
              $row =mysqli_fetch_array($sel);
            ?>

            <div class="row row-gutter-0">
              <div class="col-md-6">
                <div class="single-product-thumb">
                  <div class="thumb-item">
                    <a class="lightbox-image" data-fancybox="gallery" href="admin/product_image/<?php echo $row['product_image'];?>">
                      <img  src="admin/product_image/<?php echo $row['
                      '];?>" alt=""> <!-- img side ma show karava mate  -->
                    </a>
                  </div>
                </div>
              </div>
         
              <div class="col-md-6">
                <div class="single-product-info">
                  <h4 class="title"> <?php echo $row['product_name'];?></h4>
                  <div class="product-availability">
                    <span>$<?php echo $row['product_price'];?></span>  
                  </div>
                  <p class="product-desc">
                    <?php echo $row['description'];?>
                  </p>
                  <div class="single-product-desc">
                    <div class="quick-product-action">
                      <div class="action-top">
                        <div class="pro-qty-area">
                          <h5 class="title">Quantity:</h5>
                          <div class="pro-qty">
                            <input type="text" id="quantity" title="Quantity" value="01" />
                          </div>
                        </div>
                      </div>
                      <div class="action-bottom">
                      <a class="btn-theme" href="cart.php?id=<?php echo $row['id'];?>">Add to Cart</a>
                      </div>
                    </div>
                    <div class="product-category">
                      <?php 
                      // Fetch category name from the database based on category_id
                      $category_id = $row['category_id'];
                      $category_query = mysqli_query($con, "SELECT name FROM `category` WHERE id = $category_id");
                      if($category_query && mysqli_num_rows($category_query) > 0) {
                          $category_data = mysqli_fetch_assoc($category_query);
                          $category_name = $category_data['name'];
                          ?>
                          <h5 class="title">Category: <span><?php echo htmlspecialchars($category_name); ?></span></h5>
                      <?php } else {
                          // Handle case where category is not found
                          ?>
                          <h5 class="title">Category: <span>Unknown</span></h5>
                      <?php } ?>
                  </div>
                  </div>
                </div>
                
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <div class="product-description-review">
                  <ul class="nav nav-tabs product-description-tab-menu" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                      <button class="nav-link active" id="product-desc-tab" data-bs-toggle="tab" data-bs-target="#productDesc" type="button" role="tab" aria-controls="productDesc" aria-selected="true">Description</button>
                    </li>
                  
                    <li class="nav-item" role="presentation">
                      <button class="nav-link" id="product-custom-tab" data-bs-toggle="tab" data-bs-target="#productCustom" type="button" role="tab" aria-controls="productCustom" aria-selected="false">Shopping & Returns</button>
                    </li>
                    <li class="nav-item" role="presentation">
                      <button class="nav-link" id="product-review-tab" data-bs-toggle="tab" data-bs-target="#productReview" type="button" role="tab" aria-controls="productReview" aria-selected="false">Reviews (3)</button>
                    </li>
                  </ul>
                  <div class="tab-content product-description-tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="productDesc" role="tabpanel" aria-labelledby="product-desc-tab">
                      <div class="product-desc">
                        <h2 class="title">Provide the best Gym product for your for our client with their more for the same we have expert team, modern equipments and quality materials provide</h2>
                        <p>Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione some of volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter that are their the extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because maintain it is pain, but because occasionally circumstances occur in which some great pleasure more than enough to popular make your body fit with this class, but you need to continure your class regularly and timely </p>
                        <p>Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione desier volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter that are but putextremely painful. Nor again is there anyone who loves or pursues or desires to obtain</p>
                      </div>
                    </div>
                   
                    <div class="tab-pane fade" id="productCustom" role="tabpanel" aria-labelledby="product-custom-tab">
                      <div class="product-shipping-policy">
                        <div class="section-title">
                          <h2 class="title">Shopping & Returns policy for our store</h2>
                          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate</p>
                        </div>
                        <ul class="shipping-policy-list">
                          <li>1-2 business days (Typically by end of day)</li>
                          <li><a href="#">30 days money back guaranty</a></li>
                          <li>24/7 live support</li>
                          <li>odio dignissim qui blandit praesent</li>
                          <li>luptatum zzril delenit augue duis dolore</li>
                          <li>te feugait nulla facilisi.</li>
                        </ul>
                        <p>Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum</p>
                        <p>claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per</p>
                        <p>seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.</p>
                      </div>
                    </div>
                    <div class="tab-pane fade" id="productReview" role="tabpanel" aria-labelledby="product-review-tab">
                      <div class="product-review">
                        <div class="review-header">
                          <h4 class="title">Customer Reviews</h4>
                          <div class="review-info">
                            <ul class="review-rating">
                              <li><i class="fa fa-star"></i></li>
                              <li><i class="fa fa-star"></i></li>
                              <li><i class="fa fa-star"></i></li>
                              <li><i class="fa fa-star"></i></li>
                              <li><i class="fa fa-star-o"></i></li>
                            </ul>
                            <span class="review-caption">Based on 1 review</span>
                            <span class="review-write-btn">Write a review</span>
                          </div>
                        </div>
                        <div class="product-review-form">
                          <h4 class="title">Write a review</h4>
                          <form action="#" method="post">
                            <div class="review-form-content">
                              <div class="row">
                                <div class="col-md-12">
                                  <div class="form-group">
                                    <label for="reviewFormName">Name</label>
                                    <input class="form-control" id="reviewFormName" type="text" placeholder="Enter your name" required="">
                                  </div>
                                </div>
                                <div class="col-md-12">
                                  <div class="form-group">
                                    <label for="reviewFormEmail">Email</label>
                                    <input class="form-control" id="reviewFormEmail" type="email" placeholder="john.smith@example.com" required="">
                                  </div>
                                </div>
                                <div class="col-md-12">
                                  <div class="rating">
                                    <span class="rating-title">Rating</span>
                                    <span>
                                      <a class="fa fa-star-o" href="#/"></a>
                                      <a class="fa fa-star-o" href="#/"></a>
                                      <a class="fa fa-star-o" href="#/"></a>
                                      <a class="fa fa-star-o" href="#/"></a>
                                      <a class="fa fa-star-o" href="#/"></a>
                                    </span>
                                  </div>
                                </div>
                                <div class="col-md-12">
                                  <div class="form-group">
                                    <label for="reviewReviewTitle">Review Title</label>
                                    <input class="form-control" id="reviewReviewTitle" type="text" placeholder="Give your review a title" required="">
                                  </div>
                                </div>
                                <div class="col-md-12">
                                  <div class="form-group">
                                    <label for="reviewFormTextarea">Body of Review <span>(1500)</span></label>
                                    <textarea class="form-control textarea" id="reviewFormTextarea" name="comment" rows="7" placeholder="Write your comments here" required=""></textarea>
                                  </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-12">
                                  <div class="form-group pull-right">
                                    <button class="btn btn-theme" type="submit">Submit Review</button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </form>
                        </div>
                        <div class="review-content">
                          <div class="review-item">
                            <ul class="review-rating">
                              <li><i class="fa fa-star"></i></li>
                              <li><i class="fa fa-star"></i></li>
                              <li><i class="fa fa-star"></i></li>
                              <li><i class="fa fa-star"></i></li>
                              <li><i class="fa fa-star-o"></i></li>
                            </ul>
                            <h4 class="title">Cobus Bester</h4>
                            <h5 class="review-date"><span>Cobus Bester</span> on <span>Mar 03, 2023</span></h5>
                            <p>Can’t wait to start mixin’ with this one! Irba-irr-Up-up-up-up-date your theme!</p>
                            <a class="review-report" href="#/">Report as Inappropriate</a>
                          </div>
                        </div>
                        <div class="review-content">
                          <div class="review-item">
                            <ul class="review-rating">
                              <li><i class="fa fa-star"></i></li>
                              <li><i class="fa fa-star"></i></li>
                              <li><i class="fa fa-star"></i></li>
                              <li><i class="fa fa-star"></i></li>
                              <li><i class="fa fa-star-o"></i></li>
                            </ul>
                            <h4 class="title">Cobus Bester</h4>
                            <h5 class="review-date"><span>Cobus Bester</span> on <span>Mar 05, 2023</span></h5>
                            <p>Can’t wait to start mixin’ with this one! Irba-irr-Up-up-up-up-date your theme!</p>
                            <a class="review-report" href="#/">Report as Inappropriate</a>
                          </div>
                        </div>
                        <div class="review-content">
                          <div class="review-item">
                            <ul class="review-rating">
                              <li><i class="fa fa-star"></i></li>
                              <li><i class="fa fa-star"></i></li>
                              <li><i class="fa fa-star"></i></li>
                              <li><i class="fa fa-star"></i></li>
                              <li><i class="fa fa-star-o"></i></li>
                            </ul>
                            <h4 class="title">Cobus Bester</h4>
                            <h5 class="review-date"><span>Cobus Bester</span> on <span>Mar 07, 2023</span></h5>
                            <p>Can’t wait to start mixin’ with this one! Irba-irr-Up-up-up-up-date your theme!</p>
                            <a class="review-report" href="#/">Report as Inappropriate</a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-12">
                <div class="product-area">
                  <div class="section-title">
                    <h2 class="title">RELATED PRODUCT</h2>
                  </div>
                  <div class="row">
                  <?php
                        include("dbcon.php");
                        $no=0;  
                        $select =mysqli_query($con,"SELECT * FROM `product` LIMIT 3 ");
                        while ($row = mysqli_fetch_array($select)) { 
                        $no++;
                      ?>
                <div class="col-sm-4">
                  <!-- Start Product Item -->
                  <div class="product-item">
                    <div class="product-thumb">
                        <a href="product-details.php?id=<?php echo $row['id'];?>">
                          <img src="admin/product_image/<?php echo $row['product_image'];?>" alt="image">
                        </a>
                        <div class="product-action">
                          <a class="btn-theme" href="cart.php?id=<?php echo $row['id'];?>">Add to Cart</a>
                        </div>
                    </div>
                    <div class="product-info">
                      <h4 class="title"><a href="product-details.php?id=<?php echo $row['id'];?>"><?php echo $row['product_name'];?></a></h4>
                      <div class="prices">
                        <span class="price">$<?php echo $row['product_price'];?></span>
                      </div>
                    </div>
                 
                  </div>
                  <!-- End Product Item -->
                </div>
                <?php } ?>
              </div>   
                
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-12 col-lg-3">
            <div class="sidebar-area shop-sidebar-area mt-md-90">
              <div class="widget-item">
                <div class="widget-title">
                  <h3 class="title">SEARCH</h3>
                </div>
                <div class="widget-body">
                  <div class="widget-search-box">
                    <form action="#" method="post">
                      <div class="form-input-item">
                        <label for="search2" class="sr-only">Keywords here</label>
                        <input type="text" id="search2" placeholder="Keywords here">
                        <button type="submit" class="btn-src">
                          <i class="fa fa-search"></i>
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
              <div class="widget-item">
                <div class="widget-title">
                  <h3 class="title">CATEGORIES</h3>
                </div>
                <div class="widget-body widget-categorie-body">
                  <div class="widget-categories">
                    <ul>
                    <?php
                      include("dbcon.php");
                        $no=0;  
                        $select =mysqli_query($con,"SELECT * FROM `category`");
                        while ($row = mysqli_fetch_array($select)) { 
                        $no++;
                    ?>
                      <li><a href="shop-category.php?id=<?php echo $row['id']; ?>"> <?php echo $row['name'];?></a></li>
                      
                      <?php } ?>
                    
                    </ul>
               
                  </div>
                </div>
              </div>
          
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Shop Area ==-->
  </main>
  <?php include "footer.php"?>  