
<?php include "header.php"?>  
  <main class="main-content">
    <!--== Start Page Title Area ==-->
    <section class="page-title-area bg-img" data-bg-img="assets/img/photos/bg-page2.jpg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page-title-content content-style2">
              <h2 class="title"><span>Memberaship</span></h2>
              <div class="desc">
                <p>We have very professional and exprt Instructor and they can very important to maintain<br>our health luptas sit fugit, sed quia cuuntur magni dolores some products</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Page Title Area ==-->

    <!--== Start Contact Area ==-->
    <section class="contact-area position-relative">
      <div class="contact-page-wrap">
        <div class="container">
          <div class="row">
            <div class="row">
              <div class="col-lg-12">
                <div class="section-title text-center">
                  <h2 class="title">GET IN <span>TOUCH</span></h2>
                  <div class="desc">
                    <p>Memberaship Details</p>
                  </div>
                </div>
              </div>
            </div>
          
          </div>
        <!-- php  code start -->        
          <?php          
            include "dbcon.php";                          
            if (isset($_POST["submit"])) {

                $userid=$_SESSION['user_id'];
                $firstname = $_POST['firstname'];
                $lastname = $_POST['lastname'];
                $email = $_POST['email'];
                $password = $_POST['password'];
                $number = $_POST['number'];                                
                $address = $_POST['address'];
                $city = $_POST['city'];
                $country = $_POST['country'];
                $code = $_POST['code']; 
                $file_name =$_FILES["pimage"]["name"];
                $file_tmp =$_FILES["pimage"]["tmp_name"];
                $membership = $_POST['membership'];

                move_uploaded_file($file_tmp, "membership/".$file_name);   
                $ins = mysqli_query($con,"INSERT INTO `membership`(`userid`,`firstname`,`lastname`,`email`,`password`,`number`,`address`,`city`,`country`,`code`,`pimage`,`membership`)
                VALUES( '$userid','$firstname','$lastname','$email','$password','$number','$address','$city','$country','$code','$file_name','$membership')");

                if($ins) {
                    echo "success";
                }else {
                    echo "Fail";
                }
              }                            
          ?>

        <!-- php code end -->
          <div class="row">
            <div class="col-lg-12">
              <div class="contact-form mb-md-90">
                <form method="post" enctype="multipart/form-data"> 
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label for="firstnameInput" class="form-label">First Name :</label>
                                <input type="text" class="form-control" name="firstname" value="" placeholder="Enter your firstname">
                            </div>
                        </div>
                        <!--end col-->
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label for="lastnameInput" class="form-label">Last Name :</label>
                                <input type="text" name="lastname" class="form-control" value="" placeholder="Enter your lastname"  >
                            </div>
                        </div>
                        <!--end col-->
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label for="gmailInput" class="form-label">Email :</label>
                                <input type="Email" class="form-control" name="email" value="" placeholder="Enter your Gmail">
                            </div>
                        </div>
                        <!--end col-->
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label for="lastnameInput" class="form-label">Password :</label>
                                <input type="password" name="password" class="form-control" value="" placeholder="Enter your password" >
                            </div>
                        </div>
                        <!--end col-->
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label for="phonenumberInput" class="form-label">Phone Number</label>
                                <input type="number" class="form-control" name="number" value="" placeholder="Enter your phone number">
                            </div>
                        </div>
                        <!--end col-->                                                  
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label for="cityInput" class="form-label">City :</label>
                                <input type="text" class="form-control" name="city"  placeholder="City" >
                            </div>
                        </div>
                        <!--end col-->
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label for="countryInput" class="form-label">Country :</label>
                                <input type="text" name="country" class="form-control" value="" placeholder="Country"  >
                            </div>
                        </div>
                        <!--end col-->
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label for="zipcodeInput" class="form-label">Zip Code</label>
                                <input type="text" name="code" class="form-control" minlength="5" maxlength="6"  value="" placeholder="Enter zipcode">
                            </div>
                        </div>
                        <!--end col-->
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label for="addressInput" class="form-label">Address :</label>
                                <textarea name="address" class="form-control" cols="5" rows="5"  placeholder="Enter your addtess"></textarea>
                            </div>
                        </div>
                        <!-- end col -->
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label for="imageInput" class="form-label">Upload Profile images</label>    
                                <input type="file" name="pimage" class="form-control"   placeholder="Upload image">
                            </div>
                            <div class="col-lg-6">
                            <label for="cars" class="form-label">Choose Memberaship types : </label>
                                <select name="membership"class="form-control">
                                    <option value="">choose Memberaship :</option>
                                    <option value="Basic">Basic</option>
                                    <option value="Silver">Silver</option>
                                    <option value="Gold">Gold</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-12">
                          <div class="form-group ">
                            <input type="checkbox" class="form-check-input" id="exampleCheck1">
                            <label class="form-check-label" for="exampleCheck1"> Remember me</label>
                          </div>
                        </div>
                        <!--end row-->
                        <div class="col-md-2">
                            <div class="hstack gap-2 justify-content-end">
                                <button type="submit" name="submit" class="btn btn-primary">Upload</button>
                                <button type="button" class="btn btn-subtle-danger">Cancel</button>
                            </div>
                        </div>
                        <!--end col-->
                    </div>
                    <!--end row-->
                </form>
             </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Contact Area ==-->
  </main>
  <?php include "footer.php"?>  