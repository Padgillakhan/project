<?php include("header.php");  ?>  
            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-xl-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="card-title mb-0">Product Order</h4>
                                    </div><!-- end card header -->
                                    <div class="card-body mt-5">
                                        <div class="table-responsive table-card">
                                            <table class="table align-middle table-nowrap table-striped-columns mb-0">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th scope="col" style="width: 46px;">
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" value="" id="cardtableCheck">
                                                                <label class="form-check-label" for="cardtableCheck"></label>
                                                            </div>
                                                        </th>
                                                        <th scope="col">ID</th>
                                                        <th scope="col">User ID</th>
                                                        <th scope="col">customer Name</th>
                                                        <th scope="col">company Name</th>                      
                                                        <th scope="col">Country</th>
                                                        <th scope="col">S0treet Address</th>
                                                        <th scope="col">Apartment Address</th>
                                                        <th scope="col">Town City</th>
                                                        <th scope="col">State Region</th>
                                                        <th scope="col">Zip </th>
                                                        <th scope="col">Phone</th>
                                                        <th scope="col">Email</th>
                                                        <th scope="col" style="width: 150px;">Action</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                        include("dbcon.php");
                                                        $no=0;  
                                                        $select =mysqli_query($con,"SELECT * FROM `billing_details`");
                                                        while ($row = mysqli_fetch_array($select)) { 
                                                            $username = $row['user_id'];
                                                            $usernameselect = mysqli_query($con,"SELECT * FROM `gymregister` WHERE id = $username");
                                                            $usernamerow = mysqli_fetch_array($usernameselect);
                                                        $no++;
                                                    ?>
                                                    <tr>
                                                        <th>
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" value="" id="cardtableCheck01">
                                                                <label class="form-check-label" for="cardtableCheck01"></label>
                                                            </div>
                                                        </th>
                                                        <th scope="row"><?php echo $no;?></th>
                                                        <th><?php echo $usernamerow['username'];?></th>
                                                        <th><?php echo $row['cf_name'];?></th>
                                                        <th><?php echo $row['cf_company_name'];?></th>
                                                        <th><?php echo $row['cf_country'];?></th>
                                                        <th><?php echo $row['cf_street_address'];?></th>
                                                        <th><?php echo $row['cf_apartment_address'];?></th>
                                                        <th><?php echo $row['cf_town_city'];?></th>
                                                        <th><?php echo $row['cf_state_region'];?></th>
                                                        <th><?php echo $row['cf_zip'];?></th>
                                                        <th><?php echo $row['cf_phone'];?></th>
                                                        <th><?php echo $row['cf_email'];?></th>
                                                        <th>
                                                            <a class="btn btn-sm btn-success" href="order.php?id=<?php echo $row['id'];?>">view</a>
                                                        </th>
                                                    </tr>
                                                    <?php } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div><!-- end card-body -->
                                </div><!-- end card -->
                            </div><!-- end col -->
                        </div><!-- end row -->

                    </div>
                    <!-- container-fluid -->
                </div>
                <!-- End Page-content -->
            </div>
            <!-- end main content-->
<?php include("footer.php");?>
