<?php include("header.php");  ?>
        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <!-- start php code  -->

                    <!-- End php code -->
                    <!-- start page title -->

                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title mb-0"> Class Details </h4>
                                </div><!-- end card header -->

                                <div class="card-body mt-5">
                                    <div class="table-responsive table-card">
                                        <table class="table align-middle table-nowrap table-striped-columns mb-0">
                                            <thead class="table-light">
                                                <tr>
                                                    <th scope="col" style="width: 46px;">
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="checkbox" value="" id="cardtableCheck">
                                                            <label class="form-check-label" for="cardtableCheck"></label>
                                                        </div>
                                                    </th>
                                                    <th scope="col">ID</th>
                                                    <th scope="col">class_name</th>
                                                    <th scope="col">class_duration</th>
                                                    <th scope="col">Description</th>
                                                    <th scope="col">class_img</th>
                                             
                                                    <th scope="col" style="width: 150px;">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <!-- Start php code -->
                                                <?php
                                                    include("dbcon.php");
                                                        $no=0;  
                                                        $select =mysqli_query($con,"SELECT * FROM `class`");
                                                        while ($row = mysqli_fetch_array($select)) { 
                                                        $no++;
                                                ?>
                                                <tr>
                                                    <th>
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="checkbox" value="" id="cardtableCheck01">
                                                            <label class="form-check-label" for="cardtableCheck01"></label>
                                                        </div>
                                                    </th>
                                                        <th scope="row"><?php echo $no;?></th>
                                                        <th><?php echo $row['class_name'];?></th>
                                                        <th><?php echo $row['class_duration'];?></th>
                                                        <th>
                                                                <!-- Button trigger modal -->
                                                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#<?php echo $row['id'];?>">
                                                                    view  Class Details
                                                                </button>

                                                                <!-- Modal -->
                                                                <div class="modal fade" id="<?php echo $row['id'];?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                                <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                                                                    <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="<?php echo $row['id'];?>">Class_details</h5>
                                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                    </div>
                                                                    <div class="modal-body">

                                                                        <?php echo $row['Description'];?>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                                    </div>
                                                                    </div>
                                                                </div>
                                                                </div>
                                                        </th>                                               
                                                   
                                                        <th><img src="team/<?php echo $row['class_img'];?>" alt="" width="100px;" ></th>
                                                    <th>
                                                        <a class="btn btn-sm btn-success" href="classEdit.php?id=<?php echo $row['id'];?>">Edit</a>
                                                        <a class="ms-3 btn btn-sm btn-danger" href="class_delete.php?id=<?php echo $row['id'];?>">Delet</a>
                                                    </th>
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- end card-body -->
                            </div><!-- end card -->
                        </div><!-- end col -->
                    </div><!-- end row -->
                        <a class="btn btn-primary mb-4" href="class.php">New Add</a>
                </div> <!-- container-fluid -->
            </div><!-- End Page-content -->
        </div><!-- end main content-->
 <?php include ("footer.php");?>