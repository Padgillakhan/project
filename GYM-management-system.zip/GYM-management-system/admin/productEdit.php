<?php include("header.php");  ?>
           <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">
                        <!-- start page title -->
                        <div class="row">
                          
                        </div>
                        <!-- end page title -->
                        <!-- start the php code -->
                        <?php
                            include("dbcon.php");
                            // $id = $_SESSION['id'];
                            $id = $_GET['id'];
                            $sel = mysqli_query($con,"SELECT * FROM `product` WHERE id='$id'");
                            $roww =mysqli_fetch_array($sel);
                        ?>

                        <?php
                            include "dbcon.php";
                            if(isset($_POST["submit"])){
                                $category = $_POST['category_id'];
                                $product_name = $_POST['product_name'];
                                $product_price = $_POST['product_price'];
                                $description = $_POST['description'];
                                
                                if($_FILES ["product_image"]["name"] == '') {
                                    $file_name ="".$roww['product_image'];
                                }else{
                                    $file_name = $_FILES["product_image"]["name"];
                                    $file_tmp = $_FILES["product_image"]["tmp_name"];
                                    
                                    move_uploaded_file($file_tmp,"product_image/". $file_name);
                                }

                                $upd = mysqli_query($con,"UPDATE `product` SET `category_id`='$category',`product_name`='$product_name', `product_price`='$product_price', `description`='$description', `product_image`='$file_name' WHERE id='$id' ");
                                if($upd){    
                                    echo "<script>window.location.href = 'view_product.php';</script>";
            
                                }
                                else{   
                                    echo"fail";
                                }
            
                            }
                        ?>

                        <!-- end the php code  -->
                        <form  method="POST" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h4 class="card-title mb-0">Product</h4>
                                        </div><!-- end card header -->
                                        <div class="card-body">
                                            <div class="row gy-4">
                                                <!-- <div class="col"> -->
                                                    <div class="col-md-6 mt-3 mb-3">

                                                        <label for="category" class="form-label">Category :</label>
                                                        <select name="category_id" class="form-select"  aria-label="size 3 select example">
                                                            <?php 
                                                            include ("dbcon.php");
                                                            $category = mysqli_query($con,"SELECT * FROM `category`");
                                                            foreach ($category as $row): 
                                                            ?>
                                                            
                                                            <option  <?php if($row['id']== $roww['category_id']){ echo "selected='selected'";}?> value="<?php echo $row['id'];?>">  <?php echo $row['name']?></option>
                                                            <?php endforeach; ?>
                                                        </select>

                                                    </div>
                                                
                                                    <div class="col-md-6 mt-3 mb-3">
                                                        <label for="name" class="form-label">Product Name :</label>
                                                        <input type="text" class="form-control" value="<?php echo $roww['product_name'];?>" name="product_name" required>
                                                    </div>
                                                    <div class="col-md-6 mt-3 mb-3">
                                                        <label for="price" class="form-label">Product Price :</label>
                                                        <input type="number" class="form-control" value="<?php echo $roww['product_price'];?>" name="product_price"  required>
                                                    </div>
                                                    <div class="col-md-6 mt-3 mb-3">
                                                        <label for="description" class="form-label">Product Description :</label>
                                                        <input type="text" class="form-control" value="<?php echo $roww['description'];?>" name="description"  required>
                                                    </div>
                                                    <div class="col-md-6 ">
                                                        <img  src="product_image/<?php echo $roww['product_image'];?>" alt="" width="150px;" > <!-- img side ma show karava mate  -->
                                                        <p class="mt-4mx-auto">Product Image </p>
                                                    </div>
                                                    <div class="col-md-6 mt-2 mb-4">
                                                        <label class="form-label" for="image">Product Image:</label><br>
                                                        <input type="file"  name="product_image" class="form-control-file">
                                                    </div>
                                                    <div class="col-md-6 mt-3 mb-3">
                                                        <button class="btn btn-primary" type="submit" name="submit">Submit</button>
                                                        <a class="btn btn-success" href="view_product.php">View Product</a>
                                                    </div>
                                                
                                                
                                                <!--end col-->
                                            </div>
                                            <!--end row-->
                                        </div>
                                    </div>
                                </div>
                                <!--end col-->
                            </div> <!--end row-->
                        </form>
  
                    </div> <!-- container-fluid -->
                </div><!-- End Page-content -->
            </div><!-- end main content-->
 <?php include ("footer.php");?>