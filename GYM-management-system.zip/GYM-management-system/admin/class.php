<?php include("header.php");  ?>
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">
                        <!-- php code start -->
                        <?php
                        include "dbcon.php";
                        if(isset($_POST["submit"])){
                            $class_name = $_POST['class_name'];
                          
                            $class_duration = $_POST['class_duration'];
                            $Description = $_POST['Description'];
                            $file_name =$_FILES["class_img"]["name"];
                            $file_tmp =$_FILES["class_img"]["tmp_name"];
                            move_uploaded_file($file_tmp,"team/".$file_name);

                            $inset = mysqli_query($con,"INSERT INTO `class` (`class_name`,`class_img`,`class_duration`,`Description`) VALUES ('$class_name','$file_name','$class_duration','$Description')");
                            if($inset){
                                echo "success";
                            }else{
                                echo "Fails";
                            }
                        }
                        ?>
                        <!-- php code End -->
                        <div class="row">
                            <div class="col-lg-12">
                                    <div class="container mt-5">
                                        <form  method="POST" enctype="multipart/form-data">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="card">
                                                        <div class="card-header">
                                                            <h4 class="card-title mb-0">Class</h4>
                                                        </div><!-- end card header -->
                                                        <div class="card-body">
                                                            <div class="row gy-4">
                                                                <div class="col">
                                                                    <div class="col-md-6 mt-3 mb-3">
                                                                        <label for="class_name" class="form-label">class_name :</label>
                                                                        <input type="text" class="form-control" name="class_name" placeholder="Enter class name :" required>
                                                                    </div>
                                                                    <div class="col-md-6 mt-3 mb-3">
                                                                        <label for="class_img" class="form-label">class_img :</label>
                                                                        <input type="file" class="form-control" name="class_img" placeholder="Enter class img  :" required>
                                                                    </div>
                                                                    <div class="col-md-6 mt-3 mb-3">
                                                                        <label for="class_duration" class="form-label">class_duration :</label>
                                                                        <input type="number" class="form-control" name="class_duration" placeholder="Enter class duration  :" required>
                                                                    </div>
                                                                            
                                                                    <div class="col-md-6  form-group mt-2 mb-4">
                                                                        <label class="form-label" for="Description"> Description :</label>
                                                                        <textarea name="Description" id="summernote1"  class="form-control"  require></textarea>
                                                                    </div>
                                                    
                                                                    <div class="col-md-5 mt-3 mb-3">
                                                                        <button class="btn btn-primary" type="submit" name="submit">Submit</button>
                                                                        <a class="btn btn-success" href="class_select.php">View class</a>
                                                                    </div>
                                                                </div>
                                                                
                                                                <!--end col-->
                                                            </div>
                                                            <!--end row-->
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--end col-->
                                            </div> <!--end row-->
                                        </form>
                                    </div>
                            </div> <!-- end col -->
                        </div> <!-- end row -->
                    </div> <!-- container-fluid -->
                </div><!-- End Page-content -->
            </div><!-- End main- content -->
<?php include ("footer.php");?>
<script>
    $(document).ready(function() {
        $('#summernote1').summernote();
    });
    $(document).ready(function() {
        $('#summernote2').summernote();
    });

    $(document).ready(function() {
        $('#summernote3').summernote();
    });
  </script>
