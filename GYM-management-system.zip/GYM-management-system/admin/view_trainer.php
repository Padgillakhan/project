<?php include("header.php");  ?>  
            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-xl-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="card-title mb-0"> Trainer :</h4>
                                    </div><!-- end card header -->
                                    <div class="card-body mt-5">
                                        <div class="table-responsive table-card">
                                            
                                            <table class="table align-middle table-nowrap table-striped-columns mb-0">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th scope="col" style="width: 46px;">
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" value="" id="cardtableCheck">
                                                                <label class="form-check-label" for="cardtableCheck"></label>
                                                            </div>
                                                        </th>
                                                        <th scope="col">ID</th>
                                                        <th scope="col">trainer_image</th>
                                                        <th scope="col">tainer_name</th>
                                                        <th scope="col">profession</th>
                                                        <th scope="col" style="width: 150px;">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                        include("dbcon.php");
                                                        $no=0;  
                                                        $select =mysqli_query($con,"SELECT * FROM `trainer`");
                                                        while ($row = mysqli_fetch_array($select)) { 
                                                        $no++;
                                                    ?>
                                                    <tr>
                                                        <th>
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" value="" id="cardtableCheck01">
                                                                <label class="form-check-label" for="cardtableCheck01"></label>
                                                            </div>
                                                        </th>
                                                        <th scope="row"><?php echo $no;?></th>
                                                        <th><img src="trainer/<?php echo $row['trainer_image'];?>" alt="" width="100px;" ></th>
                                                        <th><?php echo $row['tainer_name'];?></th>
                                                        <th><?php echo $row['profession'];?></th>
                                                     
                                                        <th>
                                                            <a class="btn btn-md btn-success" href="trainer-edit.php?id=<?php echo $row['id'];?>">Edit</a>
                                                            <a class="ms-3 btn btn-md btn-danger" href="trainer-delete.php?id=<?php echo $row['id'];?>">Delet</a>
                                                            <a class="ms-3 btn  btn-warning" href="trainer_details.php?id=<?php echo $row['id'];?>">View</a>
                                                        </th>
                                                       
                                                    </tr>
                                                    <?php } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div><!-- end card-body -->
                                </div><!-- end card -->
                            </div><!-- end col -->
                        </div><!-- end row -->
                        <a class="btn btn-primary mb-4" href="trainer.php">Add New Trainer</a>

                    </div>
                    <!-- container-fluid -->
                </div>
                <!-- End Page-content -->
            </div>
            <!-- end main content-->
<?php include("footer.php");?>
