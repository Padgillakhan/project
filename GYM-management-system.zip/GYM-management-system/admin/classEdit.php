<?php include("header.php");  ?>

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
           <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">
                        <!-- php code start -->

                        <?php
                            include("dbcon.php");
                            // $id = $_SESSION['id'];
                            $id = $_GET['id'];
                            $sel = mysqli_query($con,"SELECT * FROM `class` WHERE id='$id'");
                            $roww =mysqli_fetch_array($sel);
                        ?>


                        <?php
                            include "dbcon.php";
                            if(isset($_POST["submit"])){

            
                                $class_name = $_POST['class_name'];
                                  
                                $class_duration = $_POST['class_duration'];

                                $Description = $_POST['Description'];
        
                               if($file_name =$_FILES["class_img"]["name"] ==''){
                                    $file_name = $roww['class_img'];
                                   
                                }else{
                                    $file_name = $_FILES["class_img"]["name"];
                                    $file_tmp = $_FILES["class_img"]["tmp_name"];
                                    
                                    move_uploaded_file($file_tmp,"team/". $file_name);
                                }
                                
                               
                                $upd = mysqli_query($con,"UPDATE `class` SET `class_name`='$class_name',`class_duration`='$class_duration', `class_img`='$file_name', `Description`='$Description' WHERE id='$id' ");
                                if($upd){    
                                    echo "<script>window.location.href = 'class_select.php';</script>"; 
                                }
                                else{   
                                    echo"fail";
                                }
            
                            }
                        ?>

                        <!-- php code End -->
                        <div class="row">
                            <div class="col-lg-12">
                                    <div class="container mt-5">
                                        <form  method="POST" enctype="multipart/form-data">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="card">
                                                        <div class="card-header">
                                                            <h4 class="card-title mb-0">Class Details</h4>
                                                        </div><!-- end card header -->
                                                        <div class="card-body">
                                                            <div class="row gy-4">
                                                                <div class="col-md-6">
                                                                    <div class="col mt-3 mb-3">
                                                                        <label for="class_name" class="form-label">class_name :</label>
                                                                        <input type="text" class="form-control" value="<?php echo $roww['class_name'];?>"  name="class_name" placeholder="Enter class name :" required>
                                                                    </div>
                                                                    <div class="col mt-3 mb-3">
                                                                        <label for="class_img" class="form-label">class_img :</label>
                                                                        <input type="file" class="form-control" name="class_img" placeholder="Enter class img  :">
                                                                    </div>
                                                                    <div class="col ">
                                                                        <img  src="team/<?php echo $roww['class_img'];?>" alt="" width="150px;" > <!-- img side ma show karava mate  -->
                                                                        <p class="mt-4mx-auto">Class Image </p>
                                                                    </div>

                                                                    <div class="col mt-3 mb-3">
                                                                        <label for="class_duration" class="form-label">class_duration :</label>
                                                                        <input type="number" class="form-control" value="<?php echo $roww['class_duration'];?>"  name="class_duration" placeholder="Enter class duration  :" required>
                                                                    </div>
                                                                    <div class="col mt-3 mb-3">
                                                                        <button class="btn btn-primary" type="submit" name="submit">Submit</button>
                                                                        <a class="btn btn-success" href="class_select.php">View class</a>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <div class="form-group mt-2 mb-4 ">
                                                                        <label class="form-label" for="achivement"> Class description :</label>
                                                                        <textarea name="Description" id="summernote2"  class="form-control" require><?php echo $roww['Description'];?> </textarea>
                                                                    </div>
                                                                </div>
                                                                <!--end col-->
                                                            </div>
                                                            <!--end row-->
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--end col-->
                                            </div> <!--end row-->
                                        </form>
                                    </div>
                            </div> <!-- end col -->
                        </div> <!-- end row -->
                    </div> <!-- container-fluid -->
                </div><!-- End Page-content -->
            </div><!-- End main- content -->
<?php include ("footer.php");?>
<script>
    $(document).ready(function() {
        $('#summernote1').summernote();
    });
    $(document).ready(function() {
        $('#summernote2').summernote();
    });

    $(document).ready(function() {
        $('#summernote3').summernote();
    });
  </script>