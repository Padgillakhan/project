<?php include("header.php");  ?>

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">
                        <!-- php code start -->
                        <?php
                        include "dbcon.php";
                        if(isset($_POST["submit"])){
                            $day = $_POST['day'];
                            $time = $_POST['time'];
                            $Instructor	 = $_POST['Instructor'];
                            $inset = mysqli_query($con,"INSERT INTO `class_schedule` (`day`,`time`,`Instructor`) VALUES ('$day','$time','$Instructor')");
                            if($inset){
                                echo "Details submited successfully";
                            }else{
                                echo "Fails";
                            }
                        }
                        ?>
                        <!-- php code End -->
                        <div class="row">
                            <div class="col-lg-12">
                                <h4>class Schedules</h4>
                                    <div class="container mt-5">
                                        <form  method="POST" enctype="multipart/form-data">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="card">
                                                        <div class="card-header">
                                                            <h4 class="card-title mb-0">  </h4>
                                                        </div><!-- end card header -->
                                                        <div class="card-body">
                                                            <div class="row gy-4">
                                                                <div class="col">
                                                                    <div class="col-md-6 mt-3 mb-3">
                                                                        <label for="day" class="form-label"> Day :</label>
                                                                        <input type="text" class="form-control" name="day" placeholder="Enter class Day name :" required>
                                                                    </div>
                                                                    <div class="col-md-6 mt-3 mb-3">
                                                                        <label for="time" class="form-label">time :</label>
                                                                        <input type="text" class="form-control" name="time" placeholder="Enter class time   :" required>
                                                                    </div>
                                                                    <div class="col-md-6 mt-3 mb-3">
                                                                        <label for="Instructor" class="form-label">class Instructor :</label>
                                                                        <input type="text" class="form-control" name="Instructor" placeholder="Enter class Instructor  :" required>
                                                                    </div>
                                                                    <div class="col-md-5 mt-3 mb-3">
                                                                        <button class="btn btn-primary" type="submit" name="submit">Submit</button>
                                                                    </div>
                                                                </div>

                                                                <!-- view the class  schedules -->

                                                                <h4> class Schedules Details :</h4>
                                                                <table class="table align-middle table-nowrap table-striped-columns mb-0">
                                                                    <thead class="table-light">
                                                                        <tr>
                                                                            <th scope="col" style="width: 46px;">
                                                                                <div class="form-check">
                                                                                    <input class="form-check-input" type="checkbox" value="" id="cardtableCheck">
                                                                                    <label class="form-check-label" for="cardtableCheck"></label>
                                                                                </div>
                                                                            </th>
                                                                            <th scope="col">ID</th>
                                                                            <th scope="col">Day</th>
                                                                            <th scope="col">Time</th>
                                                                            <th scope="col">Instructor</th>
                                                                            <th scope="col" style="width: 150px;">Action</th>

                                                                        </tr>
                                                                    </thead>

                                                                <tbody>
                                                                    <?php
                                                                        include("dbcon.php");
                                                                        $no=0;  
                                                                        $select =mysqli_query($con,"SELECT * FROM `class_schedule`");
                                                                        while ($row = mysqli_fetch_array($select)) { 
                                                                        $no++;
                                                                    ?>
                                                                    <tr>
                                                                        <th>
                                                                            <div class="form-check">
                                                                                <input class="form-check-input" type="checkbox" value="" id="cardtableCheck01">
                                                                                <label class="form-check-label" for="cardtableCheck01"></label>
                                                                            </div>
                                                                        </th>
                                                                        <th scope="row"><?php echo $no;?></th>
                                                                        <th><?php echo $row['day'];?></th>
                                                                        <th><?php echo $row['time'];?></th>
                                                                        <th><?php echo $row['Instructor'];?></th>
                                                                        
                                                                        <th>
                                                                            <a class="btn btn-sm btn-success" href="classschedulwsEdit.php?id=<?php echo $row['id'];?>">Edit</a>
                                                                            <a class="ms-3 btn btn-sm btn-danger" href="classschedulwsDelete.php?id=<?php echo $row['id'];?>">Delet</a>
                                                                        </th>
                                                                    
                                                                    </tr>
                                                                    <?php } ?>
                                                                    
                                                                </tbody>
                                                                </table>
           
                                                                
                                                                <!--end col-->
                                                            </div>
                                                            <!--end row-->
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--end col-->
                                            </div> <!--end row-->
                                        </form>
                                    </div>
                            </div> <!-- end col -->
                        </div> <!-- end row -->
                    </div> <!-- container-fluid -->
                </div><!-- End Page-content -->
            </div><!-- End main- content -->
<?php include ("footer.php");?>
