<?php include("header.php");  ?>
<link href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
           <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0">Trainer</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                        <!-- start the php code -->
                        <?php
                            include("dbcon.php");
                            $id = $_GET['id'];
                            $sel = mysqli_query($con,"SELECT * FROM `trainer` WHERE id='$id'");
                            $roww =mysqli_fetch_array($sel);
                        ?>

                        <?php
                            include "dbcon.php";
                            if(isset($_POST["submit"])){
                                $tainer_name = $_POST['tainer_name'];
                                $profession = $_POST['profession'];
                                $biography = $_POST['biography'];
                                $achivement = $_POST['achivement'];
                                $contact_info = $_POST['contact_info'];
                         
                                if($_FILES ["trainer_image"]["name"] == '') {
                                    $file_name = $roww['trainer_image'];
                                }else{
                                    $file_name = $_FILES["trainer_image"]["name"];
                                    $file_tmp = $_FILES["trainer_image"]["tmp_name"];
                                    
                                    move_uploaded_file($file_tmp,"trainer/". $file_name);
                                }

                                $upd = mysqli_query($con,"UPDATE `trainer` SET `tainer_name`='$tainer_name',`profession`='$profession',`biography`='$biography',`achivement`='$achivement',`contact_info`='$contact_info',`trainer_image`='$file_name' WHERE id='$id' ");
                                if($upd){    
                                    // echo "Submited successfully";
                                    echo "<script>window.location.href = 'view_trainer.php';</script>";

                                }
                                else{   
                                    echo"fail";
                                }
            
                            }
                        ?>

                        <!-- end the php code  -->
                        <form  method="POST" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h4 class="card-title mb-0">Trainer</h4>
                                        </div><!-- end card header -->
                                        <div class="card-body">
                                            <div class="row gy-4">
                                            
                                                    <div class="col-md-6 mt-3 mb-3">
                                                        <label for="name" class="form-label">Trainer Name :</label>
                                                        <input type="text" class="form-control" value="<?php echo $roww['tainer_name'];?>" name="tainer_name" required>
                                                    </div>
                                                    <div class="col-md-6 mt-3 mb-3">
                                                        <label for="price" class="form-label">profession  :</label>
                                                        <input type="text" class="form-control" value="<?php echo $roww['profession'];?>" name="profession"  required>
                                                    </div>
    

                                                    <div class="col-md-6 modal-dialog modal-dialog-scrollable   form-group mt-2 mb-4">
                                                        <label class="form-label" for="biography"> Biography :</label>
                                                        <textarea name="biography" id="summernote1" class="form-control" require><?php echo $roww['biography'];?> </textarea>
                                                    </div>
                                                    
                                                    <div class="col-md-6  form-group mt-2 mb-4">
                                                        <label class="form-label" for="achivement"> Achivement :</label>
                                                        <textarea name="achivement" id="summernote2"  class="form-control" require><?php echo $roww['achivement'];?> </textarea>
                                                    </div>

                                                    <div class="col-md-6  form-group mt-2 mb-4">
                                                        <label class="form-label" for="contact_info"> Contact info :</label>
                                                        <textarea name="contact_info" id="summernote3"  class="form-control"  require><?php echo $roww['contact_info'];?></textarea>
                                                    </div>

                                                    <div class="col-md-6 ">
                                                        <img  src="trainer/<?php echo $roww['trainer_image'];?>" alt="" width="150px;" > <!-- img side ma show karava mate  -->
                                                        <p class="mt-4mx-auto">Trainer Image </p>
                                                    </div>
                                                    <div class="col-md-6 mt-2 mb-4">
                                                        <label class="form-label" for="image">Trainer Image:</label><br>
                                                        <input type="file"  name="trainer_image" class="form-control-file">
                                                    </div>
                                                    <div class="col-md-6 mt-3 mb-3">
                                                        <button class="btn btn-primary me-2" type="submit" name="submit">Submit</button>
                                                        <a class="btn btn-success" href="view_trainer.php">View Trainer Details</a>
                                                    </div>
                                                </div>
                                                
                                                <!--end col-->
                                            </div>
                                            <!--end row-->
                                        </div>
                                    </div>
                                </div>
                                <!--end col-->
                            </div> <!--end row-->
                        </form>
  
                    </div> <!-- container-fluid -->
                </div><!-- End Page-content -->
            </div><!-- end main content-->
 <?php include ("footer.php");?>
 <script>
    $(document).ready(function() {
        $('#summernote1').summernote();
    });
    $(document).ready(function() {
        $('#summernote2').summernote();
    });

    $(document).ready(function() {
        $('#summernote3').summernote();
    });
  </script>
