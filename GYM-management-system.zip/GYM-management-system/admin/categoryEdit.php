<?php include("header.php");  ?>
           <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                            
                            </div>
                        </div>
                        <!-- end page title -->
                        <!-- start the php code -->
                        <?php
                            include("dbcon.php");
                            // $id = $_SESSION['id'];
                            $id = $_GET['id'];
                            $sel = mysqli_query($con,"SELECT * FROM `category` WHERE id='$id'");
                            $row =mysqli_fetch_array($sel);
                        ?>

                        <?php
                            include "dbcon.php";
                            if (isset($_POST["submit"])) {
                                $name =$_POST['name'];
                                $update = mysqli_query($con,"UPDATE  `category` SET `name`='$name' WHERE id = '$id'");
                                if($update){
                                    echo "<script>window.location.href = 'view_category.php';</script>";
                                }else{
                                    echo "fail";
                                }
                            }
                        ?>
                        <!-- end the php code  -->
                        <form  method="POST">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h4 class="card-title mb-0">Category</h4>
                                        </div><!-- end card header -->
                                        <div class="card-body">
                                            <div class="row gy-4">
                                                <div class="col">
                                                    <div class="col-md-6 mt-3 mb-3">
                                                        <label for="name" class="form-label">Name :</label>
                                                        <input type="text" class="form-control" value="<?php echo $row['name'];?>" name="name" placeholder="Enter your name :" required>
                                                    </div>
                                                    <div class="col-md-5 mt-3 mb-3">
                                                        <button class="btn btn-primary" type="submit" name="submit">Submit</button>
                                                        <a class="btn btn-success" href="view_category.php">View Category</a>
                                                    </div>
                                                
                                                </div>
                                                
                                                <!--end col-->
                                            </div>
                                            <!--end row-->
                                        </div>
                                    </div>
                                </div>
                                <!--end col-->
                            </div> <!--end row-->
                        </form>
  
                    </div> <!-- container-fluid -->
                </div><!-- End Page-content -->
            </div><!-- end main content-->
 <?php include ("footer.php");?>