<?php include("header.php");  ?>

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">
                        <!-- php code start -->

                        <?php
                            include("dbcon.php");
                            
                            $id = $_GET['id'];
                            $sel = mysqli_query($con,"SELECT * FROM `class_schedule` WHERE id='$id'");
                            $rowww = mysqli_fetch_array($sel);
                        ?>


              
                        <?php
                       
                        if(isset($_POST["submit"])){
                            $day = $_POST['day'];
                            $time = $_POST['time'];
                            $Instructor	 = $_POST['Instructor'];
                            
                            $update = mysqli_query($con,"UPDATE `class_schedule` SET `day`='$day', `time`='$time', `Instructor`='$Instructor' WHERE id='$id'");
                            if($update){
                            
                                echo "<script>window.location.href = 'classSchedules.php';</script>";
                            }else{
                                echo "Fail";
                            }
                        }
                        ?>
                        <!-- php code End -->
                    
                        <div class="row">
                            <div class="col-lg-12">
                                <h4>class Schedules</h4>
                                    <div class="container mt-5">
                                        <form  method="POST" enctype="multipart/form-data">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="card">
                                                        <div class="card-header">
                                                            <h4 class="card-title mb-0">  </h4>
                                                        </div><!-- end card header -->
                                                        <div class="card-body">
                                                            <div class="row gy-4">
                                                                <div class="col">
                                                                    <div class="col-md-6 mt-3 mb-3">
                                                                        <label for="day" class="form-label"> Day :</label>
                                                                        <input type="text" class="form-control" name="day" value="<?php echo $rowww['day'];?>" placeholder="Enter class Day name :" required>
                                                                    </div>
                                                                    <div class="col-md-6 mt-3 mb-3">
                                                                        <label for="time" class="form-label">time :</label>
                                                                        <input type="text" class="form-control" name="time" value="<?php echo $rowww['time'];?>" placeholder="Enter class time   :" required>
                                                                    </div>
                                                                    <div class="col-md-6 mt-3 mb-3">
                                                                        <label for="Instructor" class="form-label">class Instructor :</label>
                                                                        <input type="text" class="form-control" name="Instructor" value="<?php echo $rowww['Instructor'];?>" placeholder="Enter class Instructor  :" required>
                                                                    </div>
                                                                    <div class="col-md-5 mt-3 mb-3">
                                                                        <button class="btn btn-primary" type="submit" name="submit">Submit</button>
                                                                        <a class="btn btn-success" href="classSchedules.php">View class</a>
                                                                    </div>
                                                                </div>                                                                
                                                                <!--end col-->
                                                            </div>
                                                            <!--end row-->
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--end col-->
                                            </div> <!--end row-->
                                        </form>
                                    </div>
                            </div> <!-- end col -->
                        </div> <!-- end row -->
                    </div> <!-- container-fluid -->
                </div><!-- End Page-content -->
            </div><!-- End main- content -->
<?php include ("footer.php");?>
