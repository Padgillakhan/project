<?php include("header.php");  ?>
        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                <!-- start php code  -->
                    <?php
                        include("dbcon.php");
                        if(isset($_POST["submit"])){
                            $name =$_POST['subname'];
                            $category = $_POST['category_name'];

                            $sql = mysqli_query($con,"INSERT INTO `subcategory` (`subname`,`category_name`)  VALUES ('$name','$category')");
                            if($sql){
                                echo "success";
                            }else{
                                echo "Fail";
                            }
                        }
                    ?>
                <!-- End php code -->
                <!-- start page title -->
                <form class="bg-white" method="post">
                    <div class="row">
                        <h4 class="mb-sm-0 py-3 ms-3"> Sub Category </h4>
                        <div class="ms-3 col-7">
                            <div class="page-title-box d-sm-flex align-items-center justify-content-between mt-3"> 
                                <div class="col grop-form">
                                    <label for="category" class="form-label">Category :</label>
                                    <select name="category_name" class="form-select"  aria-label="size 3 select example">
                                        <?php 
                                        include ("dbcon.php");
                                        $category = mysqli_query($con,"SELECT * FROM `category`");
                                        foreach ( $category as $row): 
                                        ?>
                                        <option value="<?php echo $row['id'] ?>"><?php echo $row['name']?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div> 
                            <div class="page-title-box d-sm-flex align-items-center justify-content-between mt-3"> 
                                <div class="col grop-form">
                                    <label for="subcategory " class="form-label">Sub Category</label>
                                    <input type="text" name="subname" class="form-control">
                                 </div>
                            </div> 
                                
                            <div class=" mb-4 mt-2 --">
                                <button class="btn btn-primary" type="submit" name="submit"> Submit</button>
                                <a href="view_subcategory.php" class="btn btn-success">View subcategory</a>
                            </div>
                        </div>
                    </div>
                </form>

            </div> <!-- container-fluid -->
            </div><!-- End Page-content -->
        </div><!-- end main content-->
 <?php include ("footer.php");?>