<?php include("header.php");  ?>  
            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-xl-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="card-title mb-0">Categorys</h4>
                                    </div><!-- end card header -->

                                    <div class="card-body mt-5">
                                        <div class="table-responsive table-card">
                                            <table class="table align-middle table-nowrap table-striped-columns mb-0">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th scope="col" style="width: 46px;">
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" value="" id="cardtableCheck">
                                                                <label class="form-check-label" for="cardtableCheck"></label>
                                                            </div>
                                                        </th>
                                                        <th scope="col">ID</th>
                                                        <th scope="col">Name</th>
                                                        <th scope="col" style="width: 150px;">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <?php
                                                        include("dbcon.php");
                                                        $no=0;  
                                                        $select =mysqli_query($con,"SELECT * FROM `category`");
                                                        while ($row = mysqli_fetch_array($select)) { 
                                                        $no++;
                                                    ?>
                                                    <tr>
                                                        <th>
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" value="" id="cardtableCheck01">
                                                                <label class="form-check-label" for="cardtableCheck01"></label>
                                                            </div>
                                                        </th>
                                                        <th scope="row"><?php echo $no;?></th>
                                                        <th><?php echo $row['name'];?></th>
                                                        <th>
                                                            <a class="btn btn-sm btn-success" href="categoryEdit.php?id= <?php echo $row['id'];?>">Edit</a>
                                                            <a class="ms-3 btn btn-sm btn-danger" href="categoryDelete.php?id=<?php echo $row['id'];?>">Delet</a>
                                                        </th>
                                                    </tr>
                                                    <?php } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div><!-- end card-body -->
                                </div><!-- end card -->
                            </div><!-- end col -->
                        </div><!-- end row -->
                        <a class="btn btn-primary" href="category.php">New Add</a>

                    </div>
                    <!-- container-fluid -->
                </div>
                <!-- End Page-content -->
            </div>
            <!-- end main content-->
<?php include("footer.php");?>
