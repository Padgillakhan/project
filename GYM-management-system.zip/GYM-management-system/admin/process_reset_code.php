<?php
session_start();
include("dbcon.php");

use PHPmailer\PHPmailer\PHPMailer;
use PHPmailer\PHPmailer\SMTP;
use PHPmailer\PHPmailer\Exception;

require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';

function send_password_reset($get_name, $get_email, $token, $mail) {
    // Instantiate PHPMailer object
    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp.example.com';                     //SMTP server
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'user@example.com';                     //SMTP username
        $mail->Password   = 'secret';                               //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
        $mail->Port       = 465;                                    //TCP port to connect to

        //Recipients
        $mail->setFrom('from@example.com', 'Mailer');
        $mail->addAddress($get_email, $get_name);                  //Add a recipient

        // Content
        $mail->isHTML(true);                                      // Set email format to HTML
        $mail->Subject = 'Password Reset';
        $mail->Body    = 'Click the following link to reset your password: <a href="http://example.com/reset.php?token='.$token.'">Reset Password</a>';

        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}

if(isset($_POST["password_reset_link"])) {
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $token = md5(uniqid(rand(), true)); // Generating a unique token

    $check_email = "SELECT username, gmail FROM gymadmin WHERE gmail='$email' LIMIT 1";
    $check_email_run = mysqli_query($con, $check_email);

    if(mysqli_num_rows($check_email_run) > 0) {
        $row = mysqli_fetch_assoc($check_email_run);
        $get_name = $row['username'];
        $get_email = $row['gmail'];

        $update_token = "UPDATE gymadmin SET verify_token='$token' WHERE gmail='$get_email'";
        $update_token_run = mysqli_query($con, $update_token);

        if($update_token_run) {
            // Instantiate PHPMailer object
            $mail = new PHPMailer(true);
            if(send_password_reset($get_name, $get_email, $token, $mail)) {
                $_SESSION['status'] = "We have emailed you a password reset link.";
            } else {
                $_SESSION['status'] = "Failed to send password reset email.";
            }
        } else {
            $_SESSION['status'] = "Something went wrong. #1";
        }
    } else {
        $_SESSION['status'] = "No Email Found";
    }
    header("location: auth-pass-reset.php");
    exit();
}
?>
