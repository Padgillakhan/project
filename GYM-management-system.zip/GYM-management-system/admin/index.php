<?php include("header.php");?>
    <?php session_start();?>
       <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                <h4 class="mb-sm-0">Profile Settings</h4>

                                <div class="page-title-right">
                                   
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- end page title -->
                        <?php

                        // include "dbcon.php";
                        $id = $_SESSION['id'];
                        $select = mysqli_query($con,"SELECT * FROM `gymadmin` WHERE id='$id'");
                        $row = mysqli_fetch_array($select);
                        ?>
                    <div class="row">
                        <!--end col-->
                        <div class="col-xxl-3">
                            <div class="card overflow-hidden">
                                <div>
                                    <img src="pic/<?php echo $row['cimage'];?>" alt="" class="card-img-top profile-wid-img object-fit-cover" style="height: 200px;">
                                </div>
                                <div class="card-body pt-0 mt-n5">
                                    <div class="text-center">
                                        <div class="profile-user position-relative d-inline-block mx-auto">
                                            <img src="pic/<?php echo $row['pimage'];?>" alt="" class="avatar-lg rounded-circle object-fit-cover border-0 img-thumbnail user-profile-image">
                                        </div>
                                        <div class="mt-3">
                                            <h5>Richard Marshall <i class="bi bi-patch-check-fill align-baseline text-info ms-1"></i></h5>
                                        </div>
                                    </div>
                                </div> 
                            </div>
                        </div>
                        <div class="col-xxl-9">
                            <div class="d-flex align-items-center flex-wrap gap-2 mb-4">
                                <ul class="nav nav-pills arrow-navtabs nav-secondary gap-2 flex-grow-1 order-2 order-lg-1" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link active" data-bs-toggle="tab" href="#personalDetails" role="tab" aria-selected="true">
                                            Personal Details
                                        </a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" data-bs-toggle="tab" href="#changePassword" role="tab" aria-selected="false" tabindex="-1">
                                            Changes Password
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="card">
                                <div class="tab-content">

                                    <div class="tab-pane active" id="personalDetails" role="tabpanel">
                                        <div class="card-header">
                                            <h6 class="card-title mb-0">Personal Details</h6>
                                        </div>
                                        <div class="card-body">

                                            <?php
                                            
                                                if (isset($_POST["submit"])) {
                                                    $username = $_POST['username']; 
                                                    $username =  $_POST['username'];
                                                    $gmail = $_POST['gmail'];
                                                    $password = $_POST['password'];
                                                    $number = $_POST['number'];
                                                    $firstname = $_POST['firstname'];
                                                    $lastname = $_POST['lastname'];
                                                    $address = $_POST['address'];
                                                    $city = $_POST['city'];
                                                    $country = $_POST['country'];
                                                    $code = $_POST['code'];

                                                    if($_FILES["pimage"]["name"]==""){
                                                        $pfile_name =$row['pimage'];
                                                    }else{
                                                        $pfile_name = $_FILES["pimage"]["name"];
                                                        $pfile_tmp = $_FILES["pimage"]["tmp_name"];
                                                        
                                                        move_uploaded_file($pfile_tmp,"pic/". $pfile_name);
                                                    }
                                        
                                                    if($_FILES["cimage"]["name"]==""){
                                                        $cfile_name = $row['cimage'];
                                                    }else{
                                                        $cfile_name = $_FILES["cimage"]["name"];
                                                        $cfile_tmp = $_FILES["cimage"]["tmp_name"];
                                                        
                                                        move_uploaded_file($cfile_tmp,"pic/". $cfile_name);
                                                    }
                                        

                                                        $upd = mysqli_query($con, "UPDATE `gymadmin` SET `username`='$username', `gmail`='$gmail', 
                                                        `password`='$password', `number`='$number', `firstname`='$firstname', `lastname`='$lastname',
                                                        `address`='$address',`city`='$city', `country`='$country', `code`='$code', `pimage`='$pfile_name', `cimage`='$cfile_name' WHERE id='$id'");
                                                    
                                                    if ($upd) {    
                                                        echo "<script>window.location.href='pages-profile.php'</script>";
                                                    } else {   
                                                        echo "Update failed";
                                                    }
                                                }
                                            ?>

                                            <form method="post" enctype="multipart/form-data"> 
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="usernameInput" class="form-label">Username</label>
                                                            <input type="text" class="form-control" name="username" value="<?php echo $row['username'];?>" placeholder="Enter your username">
                                                        </div>
                                                    </div>
                                                    <!--end col-->
                                                    <div class="col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="gmailInput" class="form-label">Gmail :</label>
                                                            <input type="gmail" class="form-control" name="gmail" value="<?php echo $row['gmail'];?>" placeholder="Enter your Gmail">
                                                        </div>
                                                    </div>
                                                    <!--end col-->
                                                    <div class="col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="lastnameInput" class="form-label">Password :</label>
                                                            <input type="password" name="password" class="form-control" value="<?php echo $row['password'];?>" placeholder="Enter your password" >
                                                        </div>
                                                    </div>
                                                    <!--end col-->
                                                    <div class="col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="phonenumberInput" class="form-label">Phone Number</label>
                                                            <input type="number" class="form-control" name="number" value="<?php echo  $row['number'];?>" placeholder="Enter your phone number">
                                                        </div>
                                                    </div>
                                                    <!--end col-->
                                                    <div class="col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="firstnameInput" class="form-label">First Name :</label>
                                                            <input type="text" class="form-control" name="firstname" value="<?php echo $row['firstname'];?>" placeholder="Enter your firstname">
                                                        </div>
                                                    </div>
                                                    <!--end col-->
                                                    <div class="col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="lastnameInput" class="form-label">Last Name :</label>
                                                            <input type="text" name="lastname" class="form-control" value="<?php echo $row['lastname'];?>" placeholder="Enter your lastname"  >
                                                        </div>
                                                    </div>
                                                    <!--end col-->
                                                    <div class="col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="addressInput" class="form-label">Address :</label>
                                                            <textarea name="address" class="form-control" cols="5" rows="5"  placeholder="Enter your addtess"><?php echo $row['address'];?></textarea>
                                                        </div>
                                                    </div>
                                                    <!--end col-->                                                    
                                                    <div class="col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="cityInput" class="form-label">City :</label>
                                                            <input type="text" class="form-control" name="city" value="<?php echo $row['city'];?>" placeholder="City" >
                                                        </div>
                                                    </div>
                                                    <!--end col-->
                                                    <div class="col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="countryInput" class="form-label">Country :</label>
                                                            <input type="text" name="country" class="form-control" value="<?php echo $row['country'];?>" placeholder="Country"  >
                                                        </div>
                                                    </div>
                                                    <!--end col-->
                                                    <div class="col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="zipcodeInput" class="form-label">Zip Code</label>
                                                            <input type="text" name="code" class="form-control" minlength="5" maxlength="6"  value="<?php echo $row['code'];?>" placeholder="Enter zipcode">
                                                        </div>
                                                    </div>
                                                    <!--end col-->
                                                    <div class="col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="imageInput" class="form-label">Upload Profile images</label>
                                                            <input type="file" name="pimage" class="form-control"   placeholder="Upload image">
                                                        </div>

                                                    </div>
                                                    <!--end col-->
                                                    <div class="col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="imageInput" class="form-label">Upload Cover images</label>
                                                            <input type="file" name="cimage" class="form-control"   placeholder="Upload image">

                                                        </div>
                                                    </div>
                                                    <!--end col-->
                                                    <div class="col-lg-12">
                                                        <div class="hstack gap-2 justify-content-end">
                                                            <button type="submit" name="submit" class="btn btn-primary">Updates</button>
                                                            <button type="button" class="btn btn-subtle-danger">Cancel</button>
                                                        </div>
                                                    </div>
                                                    <!--end col-->
                                                </div>
                                                <!--end row-->
                                            </form>
                                        </div>
                                    </div>
                                    <!--end tab-pane-->

                                    <!-- Php  start -->
                                    <?php
                                        if(isset($_POST["updatepass"])){

                                        $id = $_SESSION['id'];
                                        $currentPasswordselect = mysqli_query($con,"SELECT * FROM `gymadmin` WHERE id='$id'");
                                        $currentPasswordrow = mysqli_fetch_array($currentPasswordselect);
                                        $current_password = $currentPasswordrow['password'];
                                        $oldpassword = $_POST['oldpassword'];
                                        $new_password = $_POST['new_password'];
                                        $confirm_password = $_POST['confirm_password'];

                                            if($oldpassword  = $current_password ){
                                                if($new_password  = $confirm_password ){
                                                    $update = mysqli_query($con,"UPDATE `gymadmin` SET password='$new_password' WHERE id = $id");
                                                }else{
                                                    echo "New password and confirm password do not match";
                                                }

                                            }else{
                                                    echo "Invalid Old Password";
                                            }
                                        }
                                    ?>
                                    <!-- php end -->
                                    <div class="tab-pane" id="changePassword" role="tabpanel">
                                        <div class="card-header">
                                            <h6 class="card-title mb-0">Changes Password</h6>
                                        </div>
                                        <div class="card-body">
                                            <form method="POST">
                                                <div class="row g-2 justify-content-lg-between align-items-center">
                                                    <div class="col-lg-4">
                                                        <div class="auth-pass-inputgroup">
                                                            <label for="oldpasswordInput" class="form-label">Old Password*</label>
                                                            <div class="position-relative">
                                                                <input type="password" class="form-control password-input" name="oldpassword" id="oldpasswordInput" placeholder="Enter current password">
                                                                <button class="btn btn-link position-absolute top-0 end-0 text-decoration-none text-muted password-addon" type="button"><i class="ri-eye-fill align-middle"></i></button>

                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-lg-4">
                                                        <div class="auth-pass-inputgroup">
                                                            <label for="password-input" class="form-label">New Password*</label>
                                                            <div class="position-relative">
                                                                <input type="password" class="form-control password-input" name="new_password"   placeholder="Enter new password" aria-describedby="passwordInput"  required>
                                                                <button class="btn btn-link position-absolute end-0 top-0 text-decoration-none text-muted password-addon" type="button"><i class="ri-eye-fill align-middle"></i></button>
                                                            </div>

                                                        </div>
                                                    </div>

                                                    <div class="col-lg-4">
                                                        <div class="auth-pass-inputgroup">
                                                            <label for="confirm-password-input" class="form-label">Confirm Password*</label>
                                                            <div class="position-relative">
                                                                <input type="password" class="form-control password-input"  name="confirm_password"  placeholder="Confirm password"  required>
                                                                <button class="btn btn-link position-absolute end-0 top-0 text-decoration-none text-muted password-addon" type="button"><i class="ri-eye-fill align-middle"></i></button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="d-flex align-items-center justify-content-between">
                                                        <a href="javascript:void(0);" class="link-primary text-decoration-underline">Forgot Password ?</a>
                                                        <div class="">

                                                            <button type="submit" name="updatepass" class="btn btn-success">Change Password</button>
                                                        </div>
                                                    </div>

                                                    <!--end col-->

                                                    <div class="col-lg-12">
                                                        <div class="card bg-light shadow-none passwd-bg" id="password-contain">
                                                            <div class="card-body">
                                                                <div class="mb-4">
                                                                    <h5 class="fs-sm">Password must contain:</h5>
                                                                </div>
                                                                <div class="">
                                                                    <p id="pass-length" class="invalid fs-xs mb-2">Minimum <b>8 characters</b></p>
                                                                    <p id="pass-lower" class="invalid fs-xs mb-2">At <b>lowercase</b> letter (a-z)</p>
                                                                    <p id="pass-upper" class="invalid fs-xs mb-2">At least <b>uppercase</b> letter (A-Z)</p>
                                                                    <p id="pass-number" class="invalid fs-xs mb-0">A least <b>number</b> (0-9)</p>

                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                                <!--end row-->
                                            </form>
                                        </div>
                                    </div>
                                    <!--end tab-pane-->
                                   
                                </div>
                            </div>
                        </div>
                        <!--end col-->
                    </div>
                    <!--end row-->

                </div>
                <!-- container-fluid -->
            </div><!-- End Page-content -->
        </div>
    <?php include("footer.php");?>