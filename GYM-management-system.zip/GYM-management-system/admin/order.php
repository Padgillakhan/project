<?php include("header.php");  ?>  
            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-xl-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="card-title mb-0">Order Details</h4>
                                    </div><!-- end card header -->
                                    <div class="card-body mt-5">
                                        <div class="table-responsive table-card">

                                            <table class="table align-middle table-nowrap table-striped-columns mb-0">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th scope="col" style="width: 46px;">
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" value="" id="cardtableCheck">
                                                                <label class="form-check-label" for="cardtableCheck"></label>
                                                            </div>
                                                        </th>
                                                        <th scope="col">ID</th>
                                                        <th scope="col">Product Image</th> 
                                                        <th scope="col">User ID</th>
                                                        <th scope="col">Product ID </th>
                                                      
                                                        <th scope="col">Product Name</th>                      
                                                        <th scope="col">Quantity</th>
                                                        <th scope="col">Price </th>
                                                        <th scope="col">Total</th>
                                                        <th scope="col">Order_id</th>
                                                     
                                                    </tr>
                                                </thead>
                                            
                                                <tbody>
                                                <?php
                                            $id = $_GET['id'];
                                            if(isset($_GET['id'])) {
                                            include("dbcon.php");
                                          
                                            $select =mysqli_query($con,"SELECT * FROM `order_product` WHERE order_id='$id'");
                                            $no=0;  
                                            while($row = mysqli_fetch_array($select)){
                                            $no++;
                                        ?>
                                                    <tr>
                                                        <th>
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" value="" id="cardtableCheck01">
                                                                <label class="form-check-label" for="cardtableCheck01"></label>
                                                            </div>
                                                        </th>
                                                        <th scope="row"><?php echo $no;?></th>
                                                        <th><img src="product_image/<?php echo $row['product_image'];?>" alt="" width="100px;" ></th>
                                                        <th><?php echo $row['user_id'];?></th>
                                                        <th><?php echo $row['product_id'];?></th>
                                                        <th><?php echo $row['product_name'];?></th>
                                                        <th><?php echo $row['quantity'];?></th>
                                                        <th><?php echo $row['price'];?></th>
                                                        <th><?php echo $row['total'];?></th>
                                                        <th><?php echo $row['order_id'];?></th>
                                                    </tr>
                                                    <?php }?>
                                                </tbody>
                                            </table>
                                          
                                            <?php } ?>
                                        </div>
                                    </div><!-- end card-body -->
                                </div><!-- end card -->
                            </div><!-- end col -->
                        </div><!-- end row -->
                        <a class="btn btn-primary mb-3"  href="view_product_order.php">Back</a>

                    </div>
                    <!-- container-fluid -->
                </div>
                <!-- End Page-content -->
            </div>
            <!-- end main content-->
<?php include("footer.php");?>
