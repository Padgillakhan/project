<?php include("header.php");  ?>  
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-xl-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="card-title mb-0"> Trainer :</h4>
                                    </div><!-- end card header -->
                                    <div class="card-body mt-5">
                                        <?php 
                                            $id = $_GET['id'];
                                            include("dbcon.php");
                                            $no=0;  
                                            $select =mysqli_query($con,"SELECT * FROM `trainer`where id = $id ");
                                            while ($row = mysqli_fetch_array($select)) { 
                                            $no++;
                                        ?>
                                        <form action="">
                                            <div class="row">
                                                <div class="col">
                                                    <div class="form-group mt-3 mb-3">
                                                        <label class="form-label " for="biography">Biography :</label>
                                                        <textarea class="form-control" name="biography" id="summernote1" cols="30" rows="10"><?php echo $row['biography'];?></textarea>
                                                    </div>
                                                    <div class="form-group mt-3 mb-3">
                                                        <label class="form-label " for="biography">Achivement :</label>
                                                        <textarea class="form-control"  name="achivement" id="summernote2" cols="30" rows="10"><?php echo $row['achivement']; ?></textarea>
                                                    </div>
                                                    <div class="form-group mt-3 mb-3">
                                                        <label class="form-label " for="biography">Contact Info :</label>
                                                        <textarea class="form-control" name="contact_info" id="summernote3" cols="30" rows="10"><?php echo $row['contact_info']; ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                        <?php }?>
                                    </div><!-- end card-body -->
                                </div><!-- end card -->
                            </div><!-- end col -->
                        </div><!-- end row -->
                        <a class="btn btn-primary mb-4" href="View_trainer.php">Back</a>

                    </div>
                    <!-- container-fluid -->
                </div>
                <!-- End Page-content -->
            </div>
            <!-- end main content-->
<?php include("footer.php");?>
<script>
    $(document).ready(function() {
        $('#summernote1').summernote();
    });
    $(document).ready(function() {
        $('#summernote2').summernote();
    });

    $(document).ready(function() {
        $('#summernote3').summernote();
    });
  </script>
