<?php include("header.php");  ?>
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">
                        <!-- php code start -->
                        <?php 
                            include "dbcon.php";
                            
                            if(isset($_POST["submit"])){
                                $tainer_name = $_POST['tainer_name'];
                                $profession = $_POST['profession'];
                                $biography = $_POST['biography'];
                                $achivement = $_POST['achivement'];
                                $contact_info = $_POST['contact_info'];
                                $file_name =$_FILES["trainer_image"]["name"];
                                $file_tmp =$_FILES["trainer_image"]["tmp_name"];
                                move_uploaded_file($file_tmp,"trainer/".$file_name);

                                $insert = mysqli_query($con,"INSERT INTO `trainer` (`tainer_name`,`profession`,`biography`,`achivement`,`contact_info`,`trainer_image`)
                                VALUES('$tainer_name','$profession','$biography','$achivement','$contact_info','$file_name')");

                                if($insert){
                                    echo "Success";
                                }else{
                                    echo "Fail";
                                }
                            }
                        ?>
                        <!-- php code End -->
                        <div class="row">
                            <div class="col-lg-12">
                                    <div class="container mt-5">
                                        <h1 class="text-center mb-4">Gym Trainer</h1>
                                       
                                        <div class="card">
                                            <h2 class="card-header"> Trainer</h2>
                                            <div class="card-body ">
                                                <form  method="post" class="row" enctype="multipart/form-data">

                                                    <div class=" col-md-6 form-group mt-2 mb-4">
                                                        <label class="form-label"  for="name">Trainer Name :</label>
                                                        <input type="text" name="tainer_name" class="form-control" required>
                                                    </div>

                                                    <div class="col-md-6  form-group mt-2 mb-4">
                                                        <label class="form-label" for="price"> Profession :</label>
                                                        <input type="text" id="profession" name="profession" class="form-control"  required>
                                                    </div>
                                                    
                                                    <div class="col-md-6  form-group mt-2 mb-4">
                                                        <label class="form-label" for="biography"> Biography :</label>
                                                        <textarea name="biography" id="summernote1" cols="30" rows="10" class="form-control"  require></textarea>
                                                    </div>
                                                    
                                                    <div class="col-md-6  form-group mt-2 mb-4">
                                                        <label class="form-label" for="achivement"> Achivement :</label>
                                                        <textarea name="achivement" id="summernote2"  class="form-control"  require></textarea>
                                                    </div>

                                                    <div class="col-md-6  form-group mt-2 mb-4">
                                                        <label class="form-label" for="contact_info"> Contact info :</label>
                                                        <textarea name="contact_info" id="summernote3"  class="form-control"  require></textarea>
                                                    </div>

                                                    <div class="col-md-6 form-group mt-2 mb-4">
                                                        <label class="form-label" for="image">Trainer Image:</label><br>
                                                        <input type="file"  name="trainer_image" class="form-control">
                                                    </div>
                                                    <div class="col-md-4 form-group mt-2 mb-4">
                                                        <button type="submit" name="submit" class="btn btn-primary mt-2 mb-4"> Submit </button>
                                                        <a href="view_trainer.php" class="btn btn-success mt-2 mb-4">View Trainer details </a>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                            </div> <!-- end col -->
                        </div> <!-- end row -->
                    </div> <!-- container-fluid -->
                </div><!-- End Page-content -->
            </div><!-- End main- content -->
<?php include ("footer.php");?>

<script>
    $(document).ready(function() {
        $('#summernote1').summernote();
    });
    $(document).ready(function() {
        $('#summernote2').summernote();
    });

    $(document).ready(function() {
        $('#summernote3').summernote();
    });
  </script>
