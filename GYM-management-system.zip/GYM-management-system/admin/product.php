<?php include("header.php");  ?>

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">
                        <!-- php code start -->
                        <?php 
                            include "dbcon.php";
                            
                            if(isset($_POST["submit"])){
                                $product_name = $_POST['product_name'];
                                $product_price = $_POST['product_price'];
                                $description = $_POST['description'];
                                $main_description =$_POST['main_description'];
                                $Shopping_Returns = $_POST['Shopping_Returns'];
                          
                                $file_name =$_FILES["product_image"]["name"];
                                $file_tmp =$_FILES["product_image"]["tmp_name"];
                                move_uploaded_file($file_tmp,"product_image/".$file_name);
                                $category_id = $_POST['category_id'];

                                $insert = mysqli_query($con,"INSERT INTO `product` (`product_name`,`product_price`,`description`,`main_description`,`Shopping_Returns`,`product_image`,`category_id`)
                                VALUES('$product_name','$product_price','$description','$main_description','$Shopping_Returns','$file_name','$category_id')");

                                if($insert){
                                    echo "Success";
                                }else{
                                    echo "Fail";
                                }
                            }
                        ?>
                        <!-- php code End -->
                        <div class="row">
                            <div class="col-lg-12">
                                    <div class="container mt-5">
                                        <h1 class="text-center mb-4">Gym Products</h1>
                                       
                                        <div class="card">
                                            <h2 class="card-header"> Product</h2>
                                            <div class="card-body">
                                                <form class="row"  method="post" enctype="multipart/form-data">

                                                    <div class="col-md-6 grop-form mt-2 mb-4">
                                                        <label for="category" class="form-label">Category :</label>
                                                        <select name="category_id" class="form-select"  aria-label="size 3 select example">
                                                            <?php 
                                                            include ("dbcon.php");
                                                            $category = mysqli_query($con,"SELECT * FROM `category`");
                                                            foreach ( $category as $row): 
                                                            ?>
                                                            <option value="<?php echo $row['id'] ?>"><?php echo $row ['id']?> <?php echo $row['name']?></option>
                                                            <?php endforeach; ?>
                                                        </select>   
                                                    </div>

                                                    <div class=" col-md-6 form-group mt-2 mb-4">
                                                        <label class="form-label"  for="name">Product Name:</label>
                                                        <input type="text" name="product_name" class="form-control" required>
                                                    </div>

                                                    <div class="col-md-6  form-group mt-2 mb-4">
                                                        <label class="form-label" for="price">Price ($):</label>
                                                        <input type="number" id="product_price" name="product_price" class="form-control" min="0" step="0.01" required>
                                                    </div>

                                                    <div class="col-md-6 form-group mt-2 mb-4">
                                                        <label class="form-label" for="description">Sub  Description:</label>
                                                        <textarea id="description" name="description" class="form-control" rows="4" required></textarea>
                                                    </div>
                                                    <div class="col-md-6 form-group mt-2 mb-4">
                                                        <label class="form-label" for="main_description">Main Description:</label>
                                                        <textarea id="main_description" name="main_description" class="form-control" required></textarea>
                                                    </div>

                                                    <div class="col-md-6 form-group mt-2 mb-4">
                                                        <label class="form-label" for="Shopping_Returns">Shopping & Returns:</label>
                                                        <textarea id="Shopping_Returns" name="Shopping_Returns" class="form-control"  required></textarea>
                                                    </div>


                                                    <div class="col-md-6 form-group mt-2 mb-2">
                                                        <label class="form-label" for="image">Product Image:</label><br>
                                                        <input type="file"  name="product_image" class="form-control-file">
                                                    </div>
                                                    
                                                    <div class="col-md-5">
                                                        <button type="submit" name="submit" class="btn btn-primary mt-2 mb-4"> Submit </button>
                                                        <a href="view_product.php" class="btn btn-success mt-2 mb-4">View Product</a>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                            </div> <!-- end col -->
                        </div> <!-- end row -->
                    </div> <!-- container-fluid -->
                </div><!-- End Page-content -->
            </div><!-- End main- content -->
<?php include ("footer.php");?>
