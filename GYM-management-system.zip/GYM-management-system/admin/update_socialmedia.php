<?php include("header.php");  ?>
           <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                            
                            </div>
                        </div>
                        <!-- end page title -->
                        <!-- start the php code -->
                        <?php
                            include("dbcon.php");
                            // $id = $_SESSION['id'];
                            $id = $_GET['id'];
                            $sel = mysqli_query($con,"SELECT * FROM `social_media` WHERE id='$id'");
                            $row =mysqli_fetch_array($sel);
                        ?>

                        <?php
                            include "dbcon.php";
                            if (isset($_POST["submit"])) {
                                $facebook =$_POST['facebook'];
                                $instagram =$_POST['instagram'];
                                $twitter =$_POST['twitter'];

                                $update = mysqli_query($con,"UPDATE  `social_media` SET `facebook`='$facebook', `instagram`='$instagram', `twitter`='$twitter' WHERE id = '$id'");
                                if($update){
                                    echo "your details successfuly submited";
                                }else{
                                    echo "fail";
                                }
                            }
                        ?>
                        <!-- end the php code  -->
                        <form  method="POST">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h4 class="card-title mb-0">Social Medai</h4>
                                        </div><!-- end card header -->
                                        <div class="card-body">
                                            <div class="row gy-4">
                                                <div class="col">
                                                    <div class="col-md-6 mt-3 mb-3">
                                                        <label for="facebook" class="form-label"> FACEBOOK :</label>
                                                        <input type="text" class="form-control" value="<?php echo $row['facebook'];?>" name="facebook" placeholder="Enter your name :" required>
                                                    </div>
                                                    <div class="col-md-6 mt-3 mb-3">
                                                        <label for="instagram" class="form-label"> INSTRAGRAM:</label>
                                                        <input type="text" class="form-control" value="<?php echo $row['instagram'];?>" name="instagram" placeholder="Enter your name :" required>
                                                    </div>
                                                    <div class="col-md-6 mt-3 mb-3">
                                                        <label for="twitter" class="form-label"> TWITTER :</label>
                                                        <input type="text" class="form-control" value="<?php echo $row['twitter'];?>" name="twitter" placeholder="Enter your name :" required>
                                                    </div>
                                                    <div class="col-md-5 mt-3 mb-3">
                                                        <button class="btn btn-primary" type="submit" name="submit">Update</button>
                                                        <a class="btn btn-success" href="social_media.php">View Category</a>
                                                    </div>
                                                
                                                </div>
                                                
                                                <!--end col-->
                                            </div>
                                            <!--end row-->
                                        </div>
                                    </div>
                                </div>
                                <!--end col-->
                            </div> <!--end row-->
                        </form>
  
                    </div> <!-- container-fluid -->
                </div><!-- End Page-content -->
            </div><!-- end main content-->
 <?php include ("footer.php");?>