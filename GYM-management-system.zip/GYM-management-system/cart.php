<?php session_start(); ?>
<?php include "dbcon.php";?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>cart</title>
</head>
<body>
    <?php
    include "dbcon.php";
    $user_id =$_SESSION['user_id'];
    $quantity = '1';
    $product_id = $_GET['id'];


    $prodselect = mysqli_query($con,"SELECT * FROM `product` WHERE id = '$product_id'");
    $prodrow = mysqli_fetch_array($prodselect);
    $price = $prodrow['product_price'];
    $total = $price *  $quantity;
    $insert = mysqli_query($con,"INSERT INTO `cart` (`user_id`,`product_id`,`quantity`,`price`,`total`)
    VALUES('$user_id','$product_id','$quantity','$price','$total')");

    if($insert){
        echo "<script>window.location.href = 'shop-cart.php';</script>";
    }else{
        echo "Fail";
    }
    ?>
</body>
</html>