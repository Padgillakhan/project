
  <!--== Start Footer Area Wrapper ==-->
  <footer class="footer-area default-style bg-img" data-bg-img="assets/img/photos/bg-f1.png">
    <div class="footer-main">
      <div class="container">
        <div class="row">
          <div class="col-sm-6 col-md-4 col-lg-3">
            <div class="widget-item mb-sm-30">
              <div class="about-widget">
                <a class="footer-logo" href="index.php">
                <h4 class="text-warning">gym world</h4>  
                  <!-- <img src="assets/img/images.png " alt="Logo"> -->
                </a>
                <p> winner dolor sit consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna</p>
                <div class="opening-time">
                  <h4 class="title">Opening time</h4>
                  <ul>
                    <li>Monday - Friday: 7 am to 10 pm</li>
                    <li>Saturday - Sunday: 9 am to 10 pm</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-4 col-lg-3">
            <div class="widget-item pl-20 pl-sm-0 mb-sm-30 mb-xs-40">
              <h4>USEFULL LINK</h4>
              <nav class="widget-menu-wrap">
                <ul class="nav-menu nav">
                  <li><a href="about.php">About us</a></li>
                  <li><a href="about.php">Membership</a></li>
                  <li><a href="classes.php">Our Classes</a></li>
                  <li><a href="team.php">Instructors</a></li>
                  <li><a href="shop.php">Shop</a></li>
                  <!-- <li><a href="blog.php">Blog post</a></li> -->
                </ul>
                <ul class="nav-menu nav">
                  <li><a href="#/">Schedules</a></li>
                  <li><a href="#/">Payment</a></li>
                  <li><a href="#/">Faqs</a></li>
                  <li><a href="contact.php">Contact</a></li>
                </ul>
              </nav>
            </div>
          </div>
          <div class="col-sm-6 col-md-4 col-lg-3">
            <div class="widget-item mb-xs-50">
              <h4>CONTACT INFO</h4>
              <div class="widget-contact-info">
                <div class="contact-info-item">
                  <div class="icon-box">
                    <img src="assets/img/icons/1.png" alt="Logo">
                  </div>
                  <div class="content">
                    <h4 class="title">Address</h4>
                    <p>252B, Central Street Main road Belix Tower, New York, USA</p>
                  </div>
                </div>
                <div class="contact-info-item">
                  <div class="icon-box">
                    <img src="assets/img/icons/2.png" alt="Logo">
                  </div>
                  <div class="content">
                    <h4 class="title">Phone</h4>
                    <ul>
                      <li><a href="tel://09(123)456789">09 (123) 456 789</a></li>
                      <li><a href="tel://09(987)654321">09 (987) 654 321</a></li>
                    </ul>
                  </div>
                </div>
                <div class="contact-info-item">
                  <div class="icon-box">
                    <img src="assets/img/icons/3.png" alt="Logo">
                  </div>
                  <div class="content">
                    <h4 class="title">Web</h4>
                    <ul>
                      <li><a href="mailto://info@example.com">info@example.com</a></li>
                      <li><a href="index.php">www.example.com</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-6 col-lg-3">
            <div class="widget-item">
              <h4>NEWSLETTER</h4>   
              <div class="widget-newsletter">
                <p>Subscribe our Newsletter and gates latest updates of offers, productsa and promotions from every week we provide</p>
                <?php
                    include "dbcon.php";

                    if(isset($_POST["send"])){
                        $email = $_POST['email'];
                        
                        // Check if the email already exists in the database
                        $check_email_query = mysqli_query($con, "SELECT COUNT(*) as count FROM `newsletter` WHERE email = '$email'");
                        $email_count = mysqli_fetch_assoc($check_email_query)['count'];
                        
                        if ($email_count > 0) {
                            // Email already exists, show error message or take appropriate action
                            echo '<script>alert("Email address already exists in the newsletter.");</script>';
                            } else {
                            // Insert the new email into the database
                            $insert = mysqli_query($con, "INSERT INTO `newsletter` (`email`) VALUES ('$email')");
                            if($insert){
                                echo "success";
                            } else {
                                echo "fail";
                            }
                        }
                    }
                ?>

                <form class="" method="POST">
                  <input class="form-control" name="email" type="text" placeholder="Email here">
                  <button class="btn btn-theme" name="send"  type="submit"><i class="fa fa-paper-plane-o"></i></button>
                </form>
              </div>         
              <div class="widget-social-icons">
                <?php 
                    include "dbcon.php";
                    $id = $_SESSION['id'];
                    $select = mysqli_query($con,"SELECT * FROM `social_media` WHERE id='$id'");
                    $rowe = mysqli_fetch_array($select);
                ?>
                <a href="<?php echo $rowe['facebook']; ?> "><i class="fa fa-facebook"></i></a>
                <a href="<?php echo $rowe['instagram']; ?> "><i class="fa fa-instagram"></i></a>
                <a href="<?php echo $rowe['twitter']; ?> "><i class="fa fa-twitter"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="container">
        <div class="footer-bottom-content">
          <div class="row align-items-center">
            <div class="col-12">
        
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!--== End Footer Area Wrapper ==-->
  
  <!--== Scroll Top Button ==-->
  <div class="scroll-to-top"><span class="fa fa-angle-double-up"></span></div>

  <!--== Start Side Menu ==-->
  <aside class="off-canvas-wrapper">
    <div class="off-canvas-inner">
      <div class="off-canvas-overlay d-none"></div>
      <!-- Start Off Canvas Content Wrapper -->
      <div class="off-canvas-content">
        <!-- Off Canvas Header -->
        <div class="off-canvas-header">
          <div class="close-action">
            <button class="btn-close"><i class="pe-7s-close"></i></button>
          </div>
        </div>

        <div class="off-canvas-item">
          <!-- Start Mobile Menu Wrapper -->
          <div class="res-mobile-menu">
            <!-- Note Content Auto Generate By Jquery From Main Menu -->
          </div>
          <!-- End Mobile Menu Wrapper -->
        </div>
        <!-- Off Canvas Footer -->
        <div class="off-canvas-footer"></div>
      </div>
      <!-- End Off Canvas Content Wrapper -->
    </div>
  </aside>
  <!--== End Side Menu ==-->
</div>

<!--=======================Javascript============================-->

<!--=== Modernizr Min Js ===-->
<script src="assets/js/modernizr.js"></script>
<!--=== jQuery Min Js ===-->
<script src="assets/js/jquery-main.js"></script>
<!--=== jQuery Migration Min Js ===-->
<script src="assets/js/jquery-migrate.js"></script>
<!--=== Popper Min Js ===-->
<script src="assets/js/popper.min.js"></script>
<!--=== Bootstrap Min Js ===-->
<script src="assets/js/bootstrap.min.js"></script>
<!--=== jquery Appear Js ===-->
<script src="assets/js/jquery.appear.js"></script>
<!--=== jquery Swiper Min Js ===-->
<script src="assets/js/swiper.min.js"></script>
<!--=== jquery Fancybox Min Js ===-->
<script src="assets/js/fancybox.min.js"></script>
<!--=== jquery Aos Min Js ===-->
<script src="assets/js/aos.min.js"></script>
<!--=== jquery Slicknav Js ===-->
<script src="assets/js/jquery.slicknav.js"></script>
<!--=== jquery Countdown Js ===-->
<script src="assets/js/jquery.countdown.min.js"></script>
<!--=== jquery Tippy Js ===-->
<script src="assets/js/tippy.all.min.js"></script>
<!--=== Isotope Min Js ===-->
<script src="assets/js/isotope.pkgd.min.js"></script>
<!--=== jquery Vivus Js ===-->
<script src="assets/js/vivus.js"></script>
<!--=== Parallax Min Js ===-->
<script src="assets/js/parallax.min.js"></script>
<!--=== Slick  Min Js ===-->
<script src="assets/js/slick.min.js"></script>
<!--=== jquery Wow Min Js ===-->
<script src="assets/js/wow.min.js"></script>
<!--=== jquery Zoom Min Js ===-->
<script src="assets/js/jquery-zoom.min.js"></script>

<!--=== Custom Js ===-->
<script src="assets/js/custom.js"></script>

</body>
</html>