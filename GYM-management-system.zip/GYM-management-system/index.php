<?php include "header.php";?>
  
  <main class="main-content">
    <!--== Start Hero Area Wrapper ==-->
    <section class="home-slider-area slider-default">
      <div class="home-slider-content">
        <div class="swiper-container home-slider-container">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <!-- Start Slide Item -->
              <div class="home-slider-item">
                <div class="bg-thumb bg-img" data-bg-img="assets/img/slider/1.jpg"></div>
                <div class="slider-content-area">
                  <div class="container">
                    <div class="row align-items-center">
                      <div class="col-sm-8 offset-sm-2 col-lg-5 offset-lg-0">
                        <div class="content">
                          <div class="inner-content">
                            <div class="icon">
                              <img src="assets/img/icons/g1.png" alt="Image">
                            </div>
                            <h2>Time <span>To</span> <span>Get</span> Fit</h2>
                            <p>Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta</p>
                            <a href="contact.php" class="btn-theme">Contact Now</a>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-7 col-lg-7">
                        <div class="slider-thumb">
                          <img src="assets/img/slider/h-1.png" alt="Image">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- End Slide Item -->
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Hero Area Wrapper ==-->

    <!--== Start Features Area Wrapper ==-->
    <section class="features-area features-default-area">
      <div class="container-fluid p-0">
        <div class="row row-gutter-0">
          <div class="col-sm-6 col-lg-3">
            <!-- Start Featured Item -->
            <div class="featured-item">
              <div class="featured-thumb">
                <img src="assets/img/class/f1.jpg" alt="Image">
              </div>
              <div class="featured-info">
                <h4>Dumble back lift</h4>
                <h5>3 SETS, <span>5 MINUTES</span></h5>
              </div>
            </div>
            <!-- End Featured Item -->
          </div>
          <div class="col-sm-6 col-lg-3">
            <!-- Start Featured Item -->
            <div class="featured-item">
              <div class="featured-thumb">
                <img src="assets/img/class/f2.jpg" alt="Image">
              </div>
              <div class="featured-info">
                <h4>Weight lifting</h4>
                <h5>4 SETS, <span>3 MINUTES</span></h5>
              </div>
            </div>
            <!-- End Featured Item -->
          </div>
          <div class="col-sm-6 col-lg-3">
            <!-- Start Featured Item -->
            <div class="featured-item">
              <div class="featured-thumb">
                <img src="assets/img/class/f3.jpg" alt="Image">
              </div>
              <div class="featured-info">
                <h4>Abs<br>fitness</h4>
                <h5>2 SETS, <span>3 MINUTES</span></h5>
              </div>
            </div>
            <!-- End Featured Item -->
          </div>
          <div class="col-sm-6 col-lg-3">
            <!-- Start Featured Item -->
            <div class="featured-item">
              <div class="featured-thumb">
                <img src="assets/img/class/f4.jpg" alt="Image">
              </div>
              <div class="featured-info">
                <h4>Ropes lifting</h4>
                <h5>5 SETS, <span>3 MINUTES</span></h5>
              </div>
            </div>
            <!-- End Featured Item -->
          </div>
        </div>
      </div>
    </section>
    <!--== End Features Area Wrapper ==-->

    <!--== Start About Area ==-->
    <section class="about-area about-default-area position-relative">
      <div class="container">
        <div class="row">
          <div class="col-lg-7 col-xl-7 order-1 order-lg-0">
            <div class="thumb" data-aos="fade-left" data-aos-duration="1000">
              <img src="assets/img/about/1.png" alt="Image">
            </div>
          </div>
          <div class="col-lg-5 col-xl-5 order-0 order-lg-1">
            <div class="about-content">
              <div class="section-title stitle-style2">
                <div class="subtitle">SCIENCE 2005</div>
                <h2 class="title">BEST <span>EQUIPMENTS <br>& FITNESS </span>TRAINERS</h2>
                <div class="desc">
                  <p>Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely </p>
                </div>
              </div>
              <div class="inner-content">
                <div class="about-list">
                  <ul>
                    <li>Builds Aerobic Power</li>
                    <li>Strong body Structure</li>
                    <li>Boots your Memory</li>
                    <li>Brng about resultful Sleep</li>
                  </ul>
                </div>
                <div class="inline-style">
                  <a class="btn btn-theme" href="classes.php">LET’S START</a>
                  <div class="btn-play-box">
                    <a class="btn-play play-video-popup" href="https://www.youtube.com/watch?v=MLpWrANjFbI"><img src="assets/img/icons/play-btn1.png" alt="Image">INTRO VIDEO</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="shape-group">
        <div class="shape-img1">
          <img src="assets/img/photos/shape1.png" alt="Image">
        </div>
      </div>
    </section>
    <!--== End About Area ==-->

    <!--== Start Features Area Wrapper ==-->
    <section class="features-area">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="featured-columns-wrap">
              <div class="featured-items-style2 bg-img" data-bg-img="assets/img/photos/bg-f2.jpg">
                <div class="row row-gutter-0">
                  <div class="col-md-6">
                    <!-- Start Featured Item -->
                    <div class="featured-item">
                      <div class="featured-icon">
                        <img src="assets/img/icons/f1.png" alt="Image">
                      </div>
                      <div class="featured-info">
                        <h4>Best Training</h4>
                        <p>Best Training dolor sit consectetur adipiscing elit, sed do eiusmod temp incididunt ut labore et dolore</p>
                      </div>
                    </div>
                    <!-- End Featured Item -->
                  </div>
                  <div class="col-md-6">
                    <!-- Start Featured Item -->
                    <div class="featured-item">
                      <div class="featured-icon">
                        <img src="assets/img/icons/f2.png" alt="Image">
                      </div>
                      <div class="featured-info">
                        <h4>Qualified Instructor</h4>
                        <p>Qualified Instructor consectetur adipg elit, sed do eiusmod tempor incididu ut labore  dolore are same magna </p>
                      </div>
                    </div>
                    <!-- End Featured Item -->
                  </div>
                  <div class="col-md-6">
                    <!-- Start Featured Item -->
                    <div class="featured-item">
                      <div class="featured-icon">
                        <img src="assets/img/icons/f3.png" alt="Image">
                      </div>
                      <div class="featured-info">
                        <h4>Latest Equipment</h4>
                        <p class="m-0">Latest equipment dolor consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna </p>
                      </div>
                    </div>
                    <!-- End Featured Item -->
                  </div>
                  <div class="col-md-6">
                    <!-- Start Featured Item -->
                    <div class="featured-item">
                      <div class="featured-icon">
                        <img src="assets/img/icons/f4.png" alt="Image">
                      </div>
                      <div class="featured-info">
                        <h4>Award Winners</h4>
                        <p class="m-0">Award winner dolor sit consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna </p>
                      </div>
                    </div>
                    <!-- End Featured Item -->
                  </div>
                </div>
              </div>
              <div class="featured-discount-item">
                <div class="thumb" data-bg-img="assets/img/photos/f1.jpg"></div>
                <div class="content">
                  <h2>35%</h2>
                  <h3>DISCOUNT</h3>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Features Area Wrapper ==-->

    <!--== Start Service Area ==-->
    <section class="service-area service-default-area">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="section-title text-center" data-aos="fade-up" data-aos-duration="1000">
              <h2 class="title"><span>CLASSES </span>WE PROVIDE</h2>
              <div class="desc">
                <p>Gym classes dolor sit amet, consectetur adipiscing elit, sed do eiod tempor <br>didunt ut labore et dolore m et dolore magna aliqua minim niam</p>
              </div>
            </div>
          </div>
        </div>
        <div class="row" data-aos="fade-up" data-aos-duration="1100">
          <div class="col-md-10 offset-md-1 col-lg-12 offset-lg-0">
            <div class="row">
              <?php
                include("dbcon.php");
                $no=0;  
                $classselect =mysqli_query($con,"SELECT * FROM `class` ");
                while ($row = mysqli_fetch_array($classselect)) { 
                $no++;
              ?>
              <div class="col-sm-6 col-lg-4">
                <!-- Start Service Item -->
                <div class="service-item">
                  <div class="inner-content">
                    <div class="thumb">
                    <a href="class-details.php?id=<?php echo $row ['id']; ?>"><span><img src="admin/team/<?php echo $row['class_img'];?>" alt="Image"></span></a>
                    </div>
                    <div class="content">
                    <h4 class="title"><a href="class-details.php?id=<?php echo $row['id'];?>"><?php echo $row['class_name'];?></a></h4>
                      <h4 class="class-time">Duration <?php echo $row['class_duration'];?> Minutes</h4>
                    </div>
                  </div>
                </div>
                <!-- End Service Item -->
              </div>
              <?php }?>

            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Service Area ==-->

    <!--== Start Service Area ==-->
    <section class="classical-workout-area">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="classical-workout-wrap bg-img" data-bg-img="assets/img/photos/workout.bg2.jpg">
              <div class="column-left bg-img" data-bg-img="assets/img/photos/workout.bg1.png" data-aos="fade-right" data-aos-duration="1000">
                <div class="content">
                  <h2 class="title">CLASSICAL<br>WORKOUT</h2>
                  <p>Lorem ipsum dolor amet, consectetur adipiscing elit, sed do eiod tempor incididunt ut labore</p>
                  <a class="btn-link" href="classes.php">VIEW SCHEDULE</a>
                </div>
              </div>
              <div class="shape-style" data-aos="fade-right" data-aos-duration="1000"></div>
              <div class="column-right">
                <div class="workout-items">
                  <div class="workout-item">
                    <div class="thumb">
                      <img src="assets/img/photos/workout1.png" alt="Image">
                    </div>
                    <div class="content">
                      <h3>01.</h3>
                    </div>
                  </div>
                  <div class="workout-item">
                    <div class="thumb">
                      <img src="assets/img/photos/workout2.png" alt="Image">
                    </div>
                    <div class="content">
                      <h3>02.</h3>
                    </div>
                  </div>
                  <div class="workout-item mb-0 mb-xxs-40">
                    <div class="thumb">
                      <img src="assets/img/photos/workout3.png" alt="Image">
                    </div>
                    <div class="content">
                      <h3>03.</h3>
                    </div>
                  </div>
                  <div class="workout-item mb-0">
                    <div class="thumb">
                      <img src="assets/img/photos/workout4.png" alt="Image">
                    </div>
                    <div class="content">
                      <h3>04.</h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Service Area ==-->

    <!--== Start Gallery Slider Area Wrapper ==-->
    <section class="gallery-area gallery-default-area">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-xl-4 pr-0">
            <div class="section-title stitle-style2" data-aos="fade-up" data-aos-duration="1000">
              <div class="subtitle">FITNESS GALLERY</div>
              <h2 class="title">BELIEVE IN <span>YOURSELF, <br>BE FIT </span>& HEALTHIER</h2>
            </div>
          </div>
          <div class="col-md-6 col-xl-8 d-none d-md-block text-center text-md-end">
            <a href="classes.php" class="btn-theme">VIEW ALL</a>
          </div>
        </div>
      </div>
      <div class="container-fluid p-0">
        <div class="row">
          <div class="col-md-12">
            <div class="gallery-slider-content">
              <div class="swiper-container gallery-slider-container">
                <div class="swiper-wrapper gallery-slider">
                  <div class="swiper-slide">
                    <div class="gallery-item">
                      <div class="thumb">
                        <a class="lightbox-image" data-fancybox="gallery" href="assets/img/gallery/g1.png"><img src="assets/img/gallery/g1.png" alt="Image"></a>
                      </div>
                    </div>
                  </div>
                  <div class="swiper-slide">
                    <div class="gallery-item">
                      <div class="thumb">
                        <a class="lightbox-image" data-fancybox="gallery" href="assets/img/gallery/g2.png"><img src="assets/img/gallery/g2.png" alt="Image"></a>
                      </div>
                    </div>
                  </div>
                  <div class="swiper-slide">
                    <div class="gallery-item">
                      <div class="thumb">
                        <a class="lightbox-image" data-fancybox="gallery" href="assets/img/gallery/g3.png"><img src="assets/img/gallery/g3.png" alt="Image"></a>
                      </div>
                    </div>
                  </div>
                  <div class="swiper-slide">
                    <div class="gallery-item">
                      <div class="thumb">
                        <a class="lightbox-image" data-fancybox="gallery" href="assets/img/gallery/g4.png"><img src="assets/img/gallery/g4.png" alt="Image"></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Gallery Slider Area Wrapper ==-->

    <!--== Start Team Area ==-->
    <section class="team-area team-default-area">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="section-title text-center" data-aos="fade-up" data-aos-duration="1000">
              <h2 class="title">PROFESSIONAL <span>INSTRUCTORS</span></h2>
              <div class="desc">
                <p>Gym classes dolor sit amet, consectetur adipiscing elit, sed do eiod tempor <br>didunt ut labore et dolore m et dolore magna aliqua minim niam</p>
              </div>
            </div>
          </div>
        </div>
        <div class="row" data-aos="fade-up" data-aos-duration="1100">
          <?php
            include("dbcon.php");
            $no=0;  
            $select =mysqli_query($con,"SELECT * FROM `trainer` LIMIT 4");
            while ($row = mysqli_fetch_array($select)) { 
            $no++;
          
          ?>
          
          <div class="col-sm-6 col-lg-3">
            <!-- Start Team Item -->
            <div class="team-item mb-md-30">
              <div class="team-member">
                <div class="thumb">
                <a  href="team-details.php?id=<?php echo $row['id'];?>"><img src="admin/trainer/<?php echo $row['trainer_image'];?>" alt="image"></a>   
                </div>
                <div class="content">
                  <div class="member-info">
                 
                  <h4 class="name"> <a href="team-details.php?id=<?php echo $row['id'];?>"> <?php echo $row['tainer_name'];?></a></h4>
                    <h6 class="designation"><?php echo $row['profession'];?></h6>
                    <div class="social-icons">
                      <a href="#/"><i class="fa fa-facebook icon"></i></a>
                      <a href="#/"><i class="fa fa-phone icon"></i></a>
                      <a href="#/"><i class="fa fa-instagram icon"></i></a>
                      <a href="#/"><i class="fa fa-twitter icon"></i></a>
                    </div>
                    <div class="team-footer">
                    <a class="btn" href="team-details.php?id=<?php echo $row['id'];?>">VIEW PROFILE</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- End Team Item -->
          </div>
          <?php } ?>
  
        </div>
      </div>
    </section>
  </main>
<?php include "footer.php"?>