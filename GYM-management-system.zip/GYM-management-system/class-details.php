<?php include "header.php"?>  
  <main class="main-content">
    <!--== Start Page Title Area ==-->
    <section class="page-title-area bg-img" data-bg-img="assets/img/photos/bg-page2.jpg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page-title-content content-style2">
              <h2 class="title"><span>BODY </span>BUILDING</h2>
              <div class="desc">
                <p class="ml-0">We provide special  classes very important to maintain our health luptas sit fugit, <br>for your fitness sed quia cuuntur magni dolores eos qui rat ione volupta</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End Page Title Area ==-->

    <!--== Start class Area ==-->
    <section class="class-details-area">
      <div class="container">
        <div class="row">
          <div class="col-lg-8">
            <?php
              include("dbcon.php");
              $id = $_GET['id'];
              $sel = mysqli_query($con,"SELECT * FROM `class` WHERE id='$id'");
              $row =mysqli_fetch_array($sel);
            ?>
            <div class="class-details-item">
              <div class="thumb">
                <img  src="admin/team/<?php echo $row['class_img'];?>"  alt=""> <!-- img side ma show karava mate  -->
              </div>
              <div class="content">
                <h2 class="title"> <?php echo $row['class_name'];?> </h2> <!-- BODY BUILDING CLASS -->
                <?php echo $row['Description'];?>
                </div>
              </div>

              <div class="class-info-schedule-area">
                <h2 class="title">Class schedule</h2>
                <p>Gym is very important to maintain our health luptas sit fugit, sed quia cuuntur magni dolores eos qui rat ione volupta pleasure rationally encounter consequences that are extremely pleasure rationally encounter</p>
                
                
                <table class="table">
                 
                  <thead>
                    <tr>
                      <th class="day">Day</th>
                      <th class="time">Time</th>
                      <th class="tnstructor">Instructor</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      include("dbcon.php");
                        $no=0;  
                        $select =mysqli_query($con,"SELECT * FROM `class_schedule`");
                        while ($row = mysqli_fetch_array($select)) { 
                        $no++;
                    ?>
                    <tr>
                      <th><?php echo $row['day'];?></th>
                      <th><?php echo $row['time'];?></th>
                      <th><?php echo $row['Instructor'];?></th>  
                    </tr>
                    <?php }?>   
                  </tbody>
                </table>
              </div>

            </div>
            <div class="team-area">

            </div>
          </div>
          <div class="col-sm-8 col-md-6 col-lg-4">
            <div class="sidebar-area class-sidebar-area inner-right-padding mt-md-90">
              <!-- <div class="widget-item">
                <div class="widget-title">
                  <h3 class="title">CATEGORIES</h3>
                </div>
                <div class="widget-body widget-categorie-body">
                  <div class="widget-categories2">
                    <ul>
                      <?php 
                        include("dbcon.php");
                        $no=0;  
                        $select =mysqli_query($con,"SELECT * FROM `class_category`");
                        while ($row = mysqli_fetch_array($select)) { 
                        $no++;
                      ?>
                        <li><a href="class_category.php?id=<?php echo $row['id']; ?>"> <?php echo $row['name'];?><span>View</span></a></li>   
                      <?php } ?>
                    </ul>
                  </div>
                </div>
              </div> -->
              <div class="widget-item">
                <div class="widget-title">
                  <h3 class="title">OPENING HOUR</h3> 
                </div>
                <div class="widget-body widget-hour-body p-0">
                  <div class="widget-hour">
                    <ul>
                      <li>Monday - Friday <i class="fa fa-long-arrow-right"></i> <span>7.00 am to 10.00pm</span></li>
                      <li>Saturday - Sunday <i class="fa fa-long-arrow-right"></i> <span>9.00 am to 8.00 pm</span></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--== End class Area ==-->
  </main>
<?php include "footer.php" ?>